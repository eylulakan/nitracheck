/*
  NitraCheck UI — ADIM16: RAM-FIRST YEREL KAYIT / TEK NVS BLOB

  ADIM16'da değişenler:
  - Ölçüm sonucu önce yalnızca RAM'e eklenir; ölçüm sırasında NVS/flash yazımı yapılmaz.
  - Yerel ölçümler tek bir sürüm + magic içeren sabit yapılı blob olarak cloudPrefs.putBytes()
    ile tek seferde yazılır; clear() ve kayıt başına putXXX() kaldırılmıştır.
  - Açılışta yeni blob okunur; yoksa mevcut eski key tabanlı format okunup RAM'e alınır ve
    yeni blob formatına bir kez migrate edilir.
  - Ölçüm sonrası ana ekran çizildikten sonra bloklamayan 2.5 saniyelik bekleme ile tek NVS
    yazımı yapılır; bu sırada ekran yeniden çizilmez.
  - BULUTA GÖNDER tek yönlüdür: cihazdaki bekleyen ölçümler Firebase'e gönderilir;
    Firebase kayıtları cihaz ölçüm hafızasına çekilmez.

  Dokunulmayanlar:
  - Gaussian spektral grafik (415–680 nm, F1–F8, tek beyaz LED eğrisi).
  - hesaplaPPM(), kalibrasyon ve NDSC-8 hesaplama mantığının genel akışı.
  (NOT: ndscSpectralScore() artık yeşil/kırmızı LED yerine AS7341 dahili
   beyaz LED'iyle alınan TEK spektrum üzerinden çalışıyor -- bkz. asağıdaki
   "PCF8574 harici yesil/kirmizi LED" bölümü.)
  - RGB panel flicker-fix, sonuç ekranı shell/value akışı ve %97 -> sonuç akışı.
  - Harita/firebaseOku mantığı ve diğer ekranlar.
*/

enum NitraScreen {
  SCREEN_MAIN = 0,
  SCREEN_MAP,
  SCREEN_CLOUD,
  SCREEN_SETTINGS,
  SCREEN_CALIBRATION_PASSWORD,
  SCREEN_CALIBRATION,
  SCREEN_CALIBRATION_MANUAL,
  SCREEN_CALIBRATION_NUMUNE,
  SCREEN_WIFI_LIST,
  SCREEN_WIFI_KEYBOARD,
  SCREEN_SETTINGS_DETAILS,
  SCREEN_GPS_INFO,
  SCREEN_DISPLAY_SETTINGS,
  SCREEN_TEAM_INFO
};


enum IconType {
  ICON_NONE,
  ICON_LOCATION,
  ICON_CLOUD,
  ICON_GEAR,
  ICON_DROP,
  ICON_CHECK,
  ICON_PRINTER
};

#include <Arduino.h>
#include <stdarg.h>  // kalLog() icin va_list (ekran uzeri log paneli)
#include <Wire.h>
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>
#include <LovyanGFX.hpp>
#include <lgfx/v1/lgfx_fonts.hpp>
#include <lgfx/v1/platforms/esp32s3/Panel_RGB.hpp>
#include <lgfx/v1/platforms/esp32s3/Bus_RGB.hpp>
#include <lgfx/v1/touch/Touch_GT911.hpp>
#include <Adafruit_AS7341.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_SHT4x.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <Preferences.h>
#include <nvs.h>
#include <nvs_flash.h>  // KAL-NVS TANI: putBytes()'in gizlediği gerçek esp_err_t kodunu görmek için

#define FIREBASE_DISABLE_ADDONS
#include <Firebase_ESP_Client.h>

// Turkce karakter destekli ozel fontlar (DejaVu Sans'tan uretildi,
// LovyanGFX GFXfont + EncodeRange formatinda). Ayni sketch klasorunde
// bulunmalidir: TRFont18.h, TRFont24.h, TRFont40.h
#include "TRFont18.h"
#include "TRFont24.h"
#include "TRFont40.h"
#include "TeknofestLogo.h"   // Fis basinda basilacak Teknofest roket logosu (1-bit bitmap)
#include "NitraCheckLogo.h"  // Fis basinda basilacak NitraCheck damla+onay logosu (1-bit bitmap)
#include "NitraCheckMainLogo.h"  // Ekran header'inda gosterilecek renkli NitraCheck logosu (PNG)
#include "TeknofestMainLogo.h"   // AYARLAR > TAKIM ekraninda gosterilecek renkli TEKNOFEST logosu (PNG)
#include "MilliTeknolojiLogo.h"  // AYARLAR > TAKIM ekraninda gosterilecek #MilliTeknolojiHamlesi logosu (PNG)
#include "ScreenIcons.h"         // Her ekranin baslik rozeti icin dairesel ikonlar + TAKIM logo dongusu (PNG)
#include "ScreenIconsV2.h"       // YENI: 166x70 dikdortgen, basligi PNG icine gomulu rozet ikonlari
#include "ButtonIcons.h"         // YENI: sol menu butonlari + geri oku + header WiFi/Bulut acik-kapali ikonlari (PNG)
#include "HeaderStatusIcons.h"   // YENI: ust bar sicaklik/nem/GPS acik-kapali ikonlari (PNG)

// =====================================================
// FIX3: UIRect struct'i dosyanin en basina tasindi.
// Arduino IDE, sketch icindeki tum fonksiyonlar icin otomatik
// prototip (forward declaration) uretip dosyanin basina ekler.
// uiRectContains(const UIRect&, ...) fonksiyonunun prototipi
// UIRect struct'i asagida (eski satir ~5947) tanimliyken uretilirse,
// "UIRect does not name a type" hatasi olusur. Cozum: struct'i
// otomatik prototip ekleme noktasindan once, yani en basa almak.
// =====================================================
struct UIRect {
  int16_t x, y, w, h;
};

// =====================================================
// FIX4: HeaderBadgeIcon struct'i da ayni sebeple (UIRect ile ayni
// Arduino otomatik-prototip sorunu) dosyanin en basina tasindi.
// headerBadgeIconForTitle() fonksiyonu "const HeaderBadgeIcon*"
// dondurdugu icin, struct asagida tanimliyken otomatik uretilen
// prototip "HeaderBadgeIcon does not name a type" hatasi veriyordu.
//
// ONEMLI: Bu struct, dosyadaki ILK fonksiyon tanimindan (asagidaki
// uiRectContains) ONCE olmak zorunda. Cunku Arduino, otomatik
// prototip blogunu dosyadaki ilk fonksiyonun hemen ONCESINE ekliyor;
// struct bu noktadan sonra tanimliysa hata tekrar eder.
// =====================================================
struct HeaderBadgeIcon {
  const uint8_t* png;
  uint32_t len;
  int w;
  int h;
};

// =====================================================
// FIX5: KalibrasyonBlob struct'i da ayni Arduino otomatik-prototip
// sorunu yuzunden dosyanin en basina tasindi (bkz. yukaridaki
// UIRect / HeaderBadgeIcon aciklamalari). Eskiden ~satir 2209'da
// tanimliydi; kalibrasyonBlobGecerliMi()/kalibrasyonBlobOku() gibi
// fonksiyonlar bunu parametre tipi olarak kullandigi icin, otomatik
// uretilen prototip struct tanimindan ONCE dosyanin basina
// eklendiginde "KalibrasyonBlob does not name a type" hatasi
// olusuyordu.
// =====================================================
#define NDSC_KANAL 8
#define KAL_NOKTA_SAYISI 11

struct KalibrasyonBlob {
  uint32_t magic;
  uint16_t version;
  uint16_t size;
  uint32_t generation;   // Her basarili kayitta +1 artar; hangi kopyanin daha guncel oldugunu belirler.
  float dark[NDSC_KANAL];
  float blank[NDSC_KANAL];
  float score[KAL_NOKTA_SAYISI];
  float hedefPPM[KAL_NOKTA_SAYISI];  // KAL-DUZELTME: eskiden hic saklanmiyordu.
                                      // "Numune ile kalibrasyon" (serbest deger)
                                      // akisinda hedefPPM, kalPts[] dizisinin
                                      // varsayilan (5/10/25/.../300 ppm) merdiveninden
                                      // FARKLI olabiliyor. Bu alan olmadan, guc
                                      // kesintisi/reset sonrasi score[] geri
                                      // yukleniyor ama hedefPPM sessizce varsayilan
                                      // merdivene donuyordu -- yani skor ile PPM
                                      // ESLESMESI BOZULUYORDU. version/size kontrolu
                                      // sayesinde bu alanin eklenmesi eski (v2) blob'lari
                                      // otomatik gecersiz sayar; ilk acilista yeniden
                                      // kalibrasyon istenecektir.
  uint8_t aktif[KAL_NOKTA_SAYISI];
  float s1Blank;  // KAL-FIX-UYUM: blank tupte YESIL LED'in kendi skoru (ham, duzeltilmemis).
  float s2Blank;  // KAL-FIX-UYUM: blank tupte KIRMIZI LED'in kendi skoru (ham, duzeltilmemis).
                  // blankBeyaz ortak (yesil+kirmizi ORTALAMASI) referans oldugu icin s1/s2
                  // hicbir zaman ayni olcekte cikmiyor -- iki renkli LED'in ham kanal profili
                  // farkli. Bu iki alan olmadan "uyum" kontrolu, olcum tamamen kararli olsa
                  // bile (cv~0.001) HER SEFERINDE bu sabit LED-rengi farkini "uyumsuzluk"
                  // sanip 0'a cakiyordu. ndscIkiRenkSkor() artik s1-s1Blank ile s2-s2Blank
                  // farkini karsilastiriyor, yani sadece GERCEK sapmayi yakaliyor.
};

static inline bool uiRectContains(const UIRect& r, int32_t px, int32_t py) {
  return px >= r.x && px < (r.x + r.w) &&
         py >= r.y && py < (r.y + r.h);
}

// ================================================================
// NitraCheck - UI ADIM 1 / POLISHED UI
//
// ONEMLI:
// - RGB timing / GT911 / AS7341 / WiFi / Firebase altyapisi
//   degistirilmedi.
// - Sadece UI katmani ve font cizimi duzenlendi.
// - Turkce karakterler icin sketch icine gomulu Clear Sans fontlari
//   kullaniliyor. Harici font dosyasi gerekmez.
// - 35.0 ppm sadece UI varsayilan gosterimidir; sensor olcumu degildir.
// ================================================================

// ── WiFi bilgilerini kendi agina gore doldur ──
#define WIFI_SSID     "akan_"
#define WIFI_PASSWORD "Sa:2742164406_."

#define FIREBASE_API_KEY       "AIzaSyAfZZcGEfo1B_AJH0wFbaAbmPEqiigj8oA"
#define FIREBASE_DATABASE_URL  "https://nitracheck-default-rtdb.europe-west1.firebasedatabase.app"
#define FIREBASE_ADMIN_EMAIL   "admin@nitracheck.com"
#define FIREBASE_ADMIN_PASSWORD "2164406"

// ─── HARİCİ ÖLÇÜM LEDLERİ / PCF8574 ─────────────────────────────
// PCF8574 adresi: A0=A1=A2=0 -> 0x20.
// P0 = YEŞİL LED, P1 = KIRMIZI LED.
// LED bağlantısı aktif-HIGH:
// PCF P0/P1 -> 220 ohm -> LED anot (+), LED katot (-) -> GND.
#define PCF8574_ADDR       0x20
#define PCF_GREEN_PIN      0
#define PCF_RED_PIN        1
// DEĞİŞİKLİK: ISD1820 PLAYE artık ayrı bir ESP32 GPIO'suna değil,
// PCF8574 I2C çoklayıcının P3 bacağına lehimlendi. Bu yüzden tetikleme
// digitalWrite() ile değil, pcf8574Yaz() ile (diğer LED'lerle aynı
// mantıkta) yapılıyor.
#define PCF_ISD1820_PIN    3

// ISD1820 PLAYL: HIGH tutulduğu sürece çalar, LOW'a dönünce anında
// durur. Süre artık sabit değil -- isd1820SesBaslat()/isd1820SesDurdur()
// ile gerçek ölçüm (yeşil+kırmızı LED) süresine dinamik olarak uyar.

uint8_t pcf8574State = 0x00;
bool pcf8574Hazir = false;

// ─── GPS MODÜLÜ — PROFESYONEL UART/NMEA YÖNETİMİ ────────────────
// NOT (ADIM18): GPIO19/GPIO20, ESP32-S3'te native USB (USB-OTG/CDC)
// donanımının SABİT D-/D+ pinleridir; "USB CDC On Boot" AÇIKKEN bu
// pinler her koşulda native USB'ye ayrılır (üzerine ne bağlarsak
// bağlayalım fark etmez). Bu yüzden GPS artık UART1-OUT (GPIO19/20)
// portundan ÇIKARILDI ve yazıcının eski yeri olan UART0-OUT
// (GPIO43/44) portuna taşındı. "USB CDC On Boot" bilerek TEKRAR
// DISABLED yapılmalı — aksi halde GPIO19/20 (şimdi yazıcının portu)
// yine native USB'ye kilitlenir.
// CrowPanel Advance 7" ESP32-S3, GPS için kullanılan port (UART0-OUT):
//   RX = GPIO44  <- GPS TX
//   TX = GPIO43  -> GPS RX
// GPS modüllerinin büyük çoğunluğu açılışta 9600 8N1 NMEA üretir.
// ÖNEMLİ: Bu UART0 donanımı çekirdek tarafından zaten `Serial0` (ve
// "USB CDC On Boot" KAPALIYKEN `Serial` ile birebir aynı nesne) olarak
// tanımlı; bu yüzden burada ayrı bir HardwareSerial nesnesi
// OLUŞTURULMUYOR, GpsSerial doğrudan Serial0'a yönlendiriliyor.
// BEDEL: "USB CDC On Boot" kapalıyken artık USB üzerinden Serial
// Monitor/debug logu görüntülenemez — bu port fiziksel olarak GPS'e
// ayrıldı. loop() içindeki eski "YAZICITEST" USB dinleyicisi de bu
// yüzden kaldırıldı (aksi halde GpsSerial ile aynı buffer'ı okuyup
// GPS baytlarını çalardı).

#define GPS_RX_PIN          44
#define GPS_TX_PIN          43
#define GPS_BAUD            9600
#define GPS_STARTUP_GRACE   30000UL   // İlk 30 s: "GPS YOK" gösterme.
#define GPS_DATA_TIMEOUT    5000UL    // NMEA kesilirse veri yok kabul et.
#define GPS_FIX_TIMEOUT     15000UL   // Son geçerli fix 15 s'den eskiyse geçersiz.
#define GPS_LINE_MAX        128

#define GpsSerial Serial0

// ─── TERMAL YAZICI — UART1-OUT (CrowPanel Advance 7" fiziksel UART1 portu) ──
// NOT (ADIM18): Yazıcının TTL (J2) hattı artık kartın eski GPS portu
// olan "UART1-OUT" konektörüne bağlanıyor. Bu port bağımsız bir
// HardwareSerial(1) nesnesiyle sürülüyor; Serial/Serial0/USB-CDC ile
// hiçbir ilişkisi yok, dolayısıyla hiçbir debug/Serial.print çıktısı
// buraya karışamaz — yazıcı ADIM17'deki gibi tamamen temiz kalır.
//   RX = GPIO19  <- Yazıcı TXD
//   TX = GPIO20  -> Yazıcı RXD
#define YAZICI_RX_PIN       19
#define YAZICI_TX_PIN       20

HardwareSerial YaziciSerial(1);
#define YAZICI_BAUD         9600
// YaziciSerial UART1 olarak HardwareSerial(1) kullanir.
// GPS ile ayni UART0/Serial0 kullanilmaz.


// gpsHazir = UART'tan geçerli NMEA akışı görülüyor.
// gpsKonumGecerli = GGA/RMC'den gerçek bir konum/fix doğrulandı.
bool gpsHazir = false;
bool gpsKonumGecerli = false;
bool gpsUartBaslatildi = false;

double gpsEnlem = 0.0;
double gpsBoylam = 0.0;

unsigned long gpsUartBaslangicMs = 0;
unsigned long gpsSonVeriMs = 0;
unsigned long gpsSonFixMs = 0;

// ─── SON BİLİNEN İYİ FIX (ölçüm anındaki kısa GPS dalgalanmalarına karşı) ──
// gpsKonumGecerli/gpsEnlem/gpsBoylam yalnızca ANLIK durumu tutar ve
// GPS_FIX_TIMEOUT (15 sn) sonunda sıfırlanır. Ölçüm butonuna basıldığı
// TAM anda uydu sinyali kısa süreliğine dalgalanırsa (özellikle iç
// mekanda) bu durum ölçümün TAMAMEN konumsuz kaydedilmesine ve fişte
// hem koordinatın hem QR kodun hiç basılmamasına yol açıyordu. Bu yüzden
// her gerçek GGA/RMC fix'inde ayrıca burada -- daha uzun bir gecerlilik
// süresiyle -- saklanıyor; ölçüm anında anlık fix yoksa bu son iyi fix
// yedek olarak kullanılır (bkz. yeniOlcumuRAMeEkle()).
double gpsSonIyiEnlem = 0.0;
double gpsSonIyiBoylam = 0.0;
unsigned long gpsSonIyiFixMs = 0;
#define GPS_SON_IYI_FIX_GECERLILIK_MS 120000UL  // 2 dakika

String gpsNmeaSatiri;

// NMEA koordinatını ondalık dereceye çevirir.
double gpsNmeaKoordinat(const char *alan, char yon) {
  if (!alan || !alan[0]) return 0.0;

  double v = atof(alan);
  if (v <= 0.0) return 0.0;

  int derece = (int)(v / 100.0);
  double dakika = v - (derece * 100.0);

  if (dakika < 0.0 || dakika >= 60.0) return 0.0;

  double sonuc = derece + dakika / 60.0;

  if (yon == 'S' || yon == 'W') sonuc = -sonuc;
  return sonuc;
}

// Virgülle ayrılmış NMEA alanını alır.
// NMEA checksum (*) varsa checksum bölümünü alanın dışında bırakır.
String gpsAlan(const String &satir, int index) {
  int bas = 0;

  for (int i = 0; i < index; i++) {
    int virgul = satir.indexOf(',', bas);
    if (virgul < 0) return "";
    bas = virgul + 1;
  }

  int son = satir.indexOf(',', bas);
  int yildiz = satir.indexOf('*', bas);

  if (son < 0 || (yildiz >= 0 && yildiz < son))
    son = yildiz;

  if (son < 0)
    son = satir.length();

  return satir.substring(bas, son);
}

// NMEA checksum kontrolü.
// '$' ile '*' arasındaki karakterlerin XOR'u checksum ile eşleşmelidir.
// '*' yoksa bazı modüllerin checksum'sız cümlelerini de kabul ederiz.
bool gpsNmeaChecksumGecerli(const String &satir) {
  int yildiz = satir.indexOf('*');

  if (yildiz < 0) {
    return true;
  }

  if (yildiz <= 1 || yildiz + 2 >= satir.length()) {
    return false;
  }

  uint8_t hesaplanan = 0;

  for (int i = 1; i < yildiz; i++) {
    hesaplanan ^= (uint8_t)satir[i];
  }

  String checksumMetni = satir.substring(yildiz + 1, yildiz + 3);
  char *son = nullptr;
  long beklenen = strtol(checksumMetni.c_str(), &son, 16);

  if (son == nullptr || *son != '\0')
    return false;

  return hesaplanan == (uint8_t)beklenen;
}

// NMEA cümlesinin gerçekten GGA/RMC olup olmadığını belirler.
bool gpsCumleTipi(const String &satir, const char *tip) {
  if (satir.length() < 7 || satir[0] != '$') return false;

  // Hem GPxxx hem GNxxx hem GLxxx vb. talker ID'lerini kabul et.
  return satir.indexOf(tip) >= 0;
}

// GGA ve RMC cümlelerinden gerçek GPS fix/konum bilgisini ayrıştırır.
void gpsNmeaSatiriIsle(const String &satir) {
  if (satir.length() < 10 || satir[0] != '$')
    return;

  if (!gpsNmeaChecksumGecerli(satir)) {
    Serial.println("[GPS] NMEA checksum hatali, cümle atlandi.");
    return;
  }

  // Her checksum'u doğru NMEA cümlesi UART akışının geldiğini kanıtlar.
  gpsHazir = true;
  gpsSonVeriMs = millis();

  // GGA:
  // 0 time
  // 1 latitude
  // 2 N/S
  // 3 longitude
  // 4 E/W
  // 5 fix quality (0=no fix, 1=GPS, 2=DGPS...)
  if (gpsCumleTipi(satir, "GGA")) {
    String fix = gpsAlan(satir, 6);
    String lat = gpsAlan(satir, 2);
    String ns  = gpsAlan(satir, 3);
    String lon = gpsAlan(satir, 4);
    String ew  = gpsAlan(satir, 5);

    if (fix.length() && fix.toInt() > 0 &&
        lat.length() && lon.length() &&
        ns.length() && ew.length()) {

      double enlem = gpsNmeaKoordinat(lat.c_str(), ns[0]);
      double boylam = gpsNmeaKoordinat(lon.c_str(), ew[0]);

      if (enlem >= -90.0 && enlem <= 90.0 &&
          boylam >= -180.0 && boylam <= 180.0 &&
          !(enlem == 0.0 && boylam == 0.0)) {

        gpsEnlem = enlem;
        gpsBoylam = boylam;
        gpsKonumGecerli = true;
        gpsSonFixMs = millis();

        gpsSonIyiEnlem = enlem;
        gpsSonIyiBoylam = boylam;
        gpsSonIyiFixMs = gpsSonFixMs;

        Serial.printf("[GPS] GGA FIX: %.6f, %.6f | kalite=%d\n",
                      gpsEnlem, gpsBoylam, fix.toInt());
      }
    }
  }

  // RMC:
  // 0 time
  // 1 status: A=valid, V=invalid
  // 2 latitude
  // 3 N/S
  // 4 longitude
  // 5 E/W
  else if (gpsCumleTipi(satir, "RMC")) {
    String durum = gpsAlan(satir, 2);
    String lat = gpsAlan(satir, 3);
    String ns  = gpsAlan(satir, 4);
    String lon = gpsAlan(satir, 5);
    String ew  = gpsAlan(satir, 6);

    if (durum == "A" &&
        lat.length() && lon.length() &&
        ns.length() && ew.length()) {

      double enlem = gpsNmeaKoordinat(lat.c_str(), ns[0]);
      double boylam = gpsNmeaKoordinat(lon.c_str(), ew[0]);

      if (enlem >= -90.0 && enlem <= 90.0 &&
          boylam >= -180.0 && boylam <= 180.0 &&
          !(enlem == 0.0 && boylam == 0.0)) {

        gpsEnlem = enlem;
        gpsBoylam = boylam;
        gpsKonumGecerli = true;
        gpsSonFixMs = millis();

        gpsSonIyiEnlem = enlem;
        gpsSonIyiBoylam = boylam;
        gpsSonIyiFixMs = gpsSonFixMs;

        Serial.printf("[GPS] RMC FIX: %.6f, %.6f\n",
                      gpsEnlem, gpsBoylam);
      }
    }
  }
}

void gpsGuncelle() {
  while (GpsSerial.available() > 0) {
    char c = (char)GpsSerial.read();

    // Yeni NMEA cümlesinin başlangıcı.
    if (c == '$') {
      gpsNmeaSatiri = "$";
      continue;
    }

    // Henüz '$' görmediysek gelen karakterler NMEA cümlesinin parçası değildir.
    if (gpsNmeaSatiri.length() == 0)
      continue;

    // NMEA satırı CR/LF ile biter.
    if (c == '\n' || c == '\r') {
      if (gpsNmeaSatiri.length() >= 7) {
        gpsNmeaSatiriIsle(gpsNmeaSatiri);
      }

      gpsNmeaSatiri = "";
      continue;
    }

    // Aşırı uzun/bozuk satırın String RAM'ini tüketmesini önle.
    if (gpsNmeaSatiri.length() < GPS_LINE_MAX - 1) {
      gpsNmeaSatiri += c;
    } else {
      Serial.println("[GPS] Asiri uzun NMEA cümlesi, buffer temizlendi.");
      gpsNmeaSatiri = "";
    }
  }

  unsigned long simdi = millis();

  // NMEA akışı kesilirse "hazir" durumunu düşür.
  if (gpsHazir && simdi - gpsSonVeriMs > GPS_DATA_TIMEOUT) {
    gpsHazir = false;
  }

  // Uzun süre yeni fix gelmediyse eski koordinatı kullanma.
  if (gpsKonumGecerli && simdi - gpsSonFixMs > GPS_FIX_TIMEOUT) {
    gpsKonumGecerli = false;
    Serial.println("[GPS] FIX zaman aşımına uğradı.");
  }
}

// GPS'in açılışta "YOK" diye yanlış raporlanmasını önleyen durum metni.
// Durumlar:
//  1) UART başlatılıyor
//  2) Açılış tolerans süresi içinde NMEA bekleniyor
//  3) NMEA geliyor fakat uydu fix yok
//  4) Gerçek fix var
//  5) Uzun süre hiç NMEA yok
const char* gpsDurumMetni() {
  if (gpsKonumGecerli)
    return "GPS FIX VAR";

  if (!gpsUartBaslatildi)
    return "GPS BAŞLATILIYOR";

  unsigned long gecen = millis() - gpsUartBaslangicMs;

  if (!gpsHazir && gecen < GPS_STARTUP_GRACE)
    return "GPS BAŞLATILIYOR";

  if (gpsHazir)
    return "GPS FIX BEKLENIYOR";

  return "GPS VERİ YOK";
}

// CrowPanel Advance 7" ESP32-S3, hardware V1.4
// Display: 800x480 RGB, SC7277
class LGFX : public lgfx::LGFX_Device {
  lgfx::Bus_RGB     _bus;
  lgfx::Panel_RGB   _panel;
  lgfx::Touch_GT911 _touch;

public:
  LGFX() {
    {
      auto cfg = _panel.config();
      cfg.memory_width  = 800;
      cfg.memory_height = 480;
      cfg.panel_width   = 800;
      cfg.panel_height  = 480;
      cfg.offset_x = 0;
      cfg.offset_y = 0;
      _panel.config(cfg);
    }

    {
      auto cfg = _panel.config_detail();
      cfg.use_psram = 1;   // PSRAM kullanımı: çerçeve tamponu (framebuffer) PSRAM'e
                            // yerleştirilir. Kurulu LovyanGFX sürümünde Panel_RGB
                            // config_detail_t içinde "double_buffer" alanı yok
                            // (derleme hatasına sebep olduğu için kaldırıldı).
                            // Titreme sorunu zaten WiFi.setSleep(false) ve
                            // freq_write=16MHz ile çözüldü.
      _panel.config_detail(cfg);
    }

    {
      auto cfg = _bus.config();
      cfg.panel = &_panel;

      cfg.pin_d0  = GPIO_NUM_21;
      cfg.pin_d1  = GPIO_NUM_47;
      cfg.pin_d2  = GPIO_NUM_48;
      cfg.pin_d3  = GPIO_NUM_45;
      cfg.pin_d4  = GPIO_NUM_38;

      cfg.pin_d5  = GPIO_NUM_9;
      cfg.pin_d6  = GPIO_NUM_10;
      cfg.pin_d7  = GPIO_NUM_11;
      cfg.pin_d8  = GPIO_NUM_12;
      cfg.pin_d9  = GPIO_NUM_13;
      cfg.pin_d10 = GPIO_NUM_14;

      cfg.pin_d11 = GPIO_NUM_7;
      cfg.pin_d12 = GPIO_NUM_17;
      cfg.pin_d13 = GPIO_NUM_18;
      cfg.pin_d14 = GPIO_NUM_3;
      cfg.pin_d15 = GPIO_NUM_46;

      cfg.pin_henable = GPIO_NUM_42;
      cfg.pin_vsync   = GPIO_NUM_41;
      cfg.pin_hsync   = GPIO_NUM_40;
      cfg.pin_pclk    = GPIO_NUM_39;

      cfg.freq_write = 16000000;

      cfg.hsync_polarity    = 0;
      cfg.hsync_front_porch = 8;
      cfg.hsync_pulse_width = 4;
      cfg.hsync_back_porch  = 8;

      cfg.vsync_polarity    = 0;
      cfg.vsync_front_porch = 8;
      cfg.vsync_pulse_width = 4;
      cfg.vsync_back_porch  = 8;

      cfg.pclk_idle_high = 1;

      _bus.config(cfg);
      _panel.setBus(&_bus);
    }

    {
      auto cfg = _touch.config();
      cfg.x_min = 0;
      cfg.x_max = 799;
      cfg.y_min = 0;
      cfg.y_max = 479;
      cfg.pin_int  = -1;
      cfg.pin_rst  = -1;
      cfg.bus_shared = true;
      cfg.offset_rotation = 0;
      cfg.i2c_port = I2C_NUM_0;
      cfg.pin_sda  = GPIO_NUM_15;
      cfg.pin_scl  = GPIO_NUM_16;
      cfg.freq     = 400000;
      cfg.i2c_addr = 0x5D;
      _touch.config(cfg);
      _panel.setTouch(&_touch);
    }

    setPanel(&_panel);
  }
};

LGFX display;

#define I2C_SDA_PIN 15
#define I2C_SCL_PIN 16
#define I2C_FREQ_HZ  100000UL
#define GT911_ADDR   0x5D
#define STC8_ADDR    0x30
#define AS7341_ADDR  0x39
#define SHT40_ADDR   0x44

// Tüm I2C cihazları aynı fiziksel SDA/SCL hattını kullanır.
// Mutex özellikle ileride ayrı FreeRTOS task'ları eklenirse bus erişimini
// atomik tutar. loopTask içindeki GT911 erişimi de sensör erişimleriyle
// aynı task üzerinde gerçekleştiği için ayrıca Wire.begin() çağrılmaz.
SemaphoreHandle_t i2cMutex = nullptr;
bool ortakI2CBaslatildiMi = false;

Adafruit_AS7341 as7341;
bool as7341Hazir = false;

// Serial Monitor kullanılamadığında bile AS7341'in tam olarak hangi
// adımda başarısız olduğunu ekran üzerinden görebilmek için tanı
// bilgisi (I2C tarama / begin() / ilk gerçek okuma sonucu).
bool as7341TaramaBulundu = false;   // 0x39 adresinde cihaz var mı (bus seviyesi)
bool as7341BeginSonucu   = false;   // as7341.begin() başarılı mı
bool as7341OkumaSonucu   = false;   // ilk readAllChannels() başarılı mı
// NOT: SHT40 daha once fiziksel olarak sokulmustu; simdi tekrar
// AS7341 ile AYNI ORTAK I2C hattina (SDA=15 SCL=16) eklendi. Kilitlenme
// riskini onlemek icin AS7341 ile birebir ayni desen kullanildi:
// once adres taramasi (i2cCihazVar), sonra mutex korumali begin(),
// sonra bir kez gercek okuma denemesi. as7341Hazir gibi sht40Hazir
// false ise HICBIR okuma fonksiyonu I2C hattina tekrar tekrar
// dokunmaz (bkz. ndscOkuOrtalama() basindaki ayni prensip).
Adafruit_SHT4x sht40 = Adafruit_SHT4x();
bool sht40Hazir = false;
bool sht40TaramaBulundu = false;   // 0x44 adresinde cihaz var mi (bus seviyesi)
bool sht40BeginSonucu   = false;   // sht40.begin() basarili mi
bool sht40OkumaSonucu   = false;   // ilk gercek okuma basarili mi
float sonSicaklikC = NAN;
float sonNemYuzde  = NAN;

// FIX3 ileri bildirimleri: Arduino otomatik prototip üretimine bağımlı kalma.
static void reverseGeocodeIstegi(double lat, double lon);
static bool reverseGeocodeCacheAl(double lat, double lon, String &adres);
static void bulutSenkronizasyonIstegi();

FirebaseData   fbdo;
FirebaseData   fbdoOku;
FirebaseAuth   fbAuth;
FirebaseConfig fbConfig;
bool firebaseHazir = false;
int haritaNoktaSayisi = 0;
int haritaToplamGecerli = 0;   // /measurements altında koordinatı geçerli TÜM kayıt sayısı
                                // (haritada aynı anda gösterilenden fazla olabilir)
unsigned long sonHaritaYenileme = 0;
#define HARITA_YENILEME_MS 300000UL

// Haritada AYNI ANDA gösterilecek azami nokta sayısı (ekran/okunabilirlik
// sınırı). Firebase'de bundan fazla geçerli koordinatlı kayıt varsa, en
// YENİ (timestamp'e göre) olanlar seçilir; böylece yeni eklenen bir ölçüm
// eski kayıtların gerisinde kalıp haritadan hiç görünmeden kaybolmaz.
// Firebase'den RAM'e alınacak ve haritada gösterilecek azami koordinat.
// 5, 50 ve 100 kayıt doğrudan desteklenir; 256 güvenli üst sınırdır.
#define HARITA_MAX_NOKTA 256

// Geoapify Static Maps gerçek harita ayarları.
// API anahtarını Geoapify hesabından buraya kendiniz ekleyin.
// NOT: Anahtarı sohbet mesajında paylaşmayın.
#define GEOAPIFY_API_KEY "2841615605754735a17599c1f11e1bcb"
#define GEOAPIFY_MAP_STYLE "osm-bright"

// Static harita ile koordinat hesabında AYNI sınırlar kullanılmalıdır.
#define MAP_LON_MIN 25.50
#define MAP_LAT_MIN 35.55
#define MAP_LON_MAX 45.50
#define MAP_LAT_MAX 42.95

// HARİTA ekranındaki panel/harita boyutları. drawSimplePage() içindeki
// panelW/panelH ile AYNI değerler burada da sabit olarak tutuluyor ki
// HARİTA butonuna basılır basılmaz (drawSimplePage'den ÖNCE) başlatılan
// animasyonlu indirme de aynı genişlik/yükseklikte PNG istesin.
#define HARITA_PANEL_W 764
#define HARITA_PANEL_H 382
#define HARITA_MAP_W (HARITA_PANEL_W - 4)
#define HARITA_MAP_H (HARITA_PANEL_H - 4)

static uint8_t* geoapifyHaritaPng = nullptr;
static size_t geoapifyHaritaPngLen = 0;
static bool geoapifyHaritaHazir = false;
static String geoapifyHaritaHata = "";

// HARİTA AĞ İŞİ ARKA PLAN GÖREVİ
// İnternet/HTTPS/Firebase işlemleri UI döngüsünü bloklamasın diye ayrı
// FreeRTOS task'ında çalıştırılır. Ekrana yalnızca ana UI görevi çizer.
static TaskHandle_t haritaAgTaskHandle = nullptr;
static volatile bool haritaAgCalisiyor = false;
static volatile bool haritaAgBitti = false;
static volatile bool haritaAgBasarili = false;
static volatile bool haritaAgFirebaseYapilacak = false;
static portMUX_TYPE haritaAgMux = portMUX_INITIALIZER_UNLOCKED;

// Firebase'den okunan gerçek ölçüm koordinatı.
// Desteklenen alan adları: latitude/lat ve longitude/lng/lon.
struct FirebaseHaritaNoktasi {
  double lat;
  double lon;
  float ppm;
  double timestamp;
  bool gecerli;
};
FirebaseHaritaNoktasi firebaseHaritaNoktalari[HARITA_MAX_NOKTA];
unsigned long sonHaritaButonDokunusu = 0;
#define HARITA_BUTON_DEBOUNCE_MS 500UL

// Harita risk siniflari (ppm). Gerektiginde proje standardina gore ayarlanabilir.
// 0 .. 50 ppm   : YESIL  = normal
// >50 .. 100 ppm: SARI   = yuksek
// >100 ppm      : KIRMIZI= tehlike
#define HARITA_NORMAL_MAX_PPM 25.0f   // 0-25 mg/L: düşük/normal
#define HARITA_YUKSEK_MAX_PPM 50.0f   // 25-50 mg/L: yükselmiş; >50 kırmızı

uint16_t haritaNoktaRengi(float ppm);

String sonFirebaseHata = "";
String sonNtpDurum = "";

// Ölçüm sırasında UI kilidi: true iken diğer tüm dokunuşlar yok sayılır.
bool olcumKilitli = false;

void firebaseBaslat() {
  fbConfig.api_key = FIREBASE_API_KEY;
  fbConfig.database_url = FIREBASE_DATABASE_URL;
  fbAuth.user.email    = FIREBASE_ADMIN_EMAIL;
  fbAuth.user.password = FIREBASE_ADMIN_PASSWORD;
  Firebase.reconnectWiFi(true);
  Firebase.begin(&fbConfig, &fbAuth);

  Serial.print("[Firebase] Token bekleniyor");
  unsigned long baslangic = millis();
  while (!Firebase.ready() && millis() - baslangic < 10000) {
    Serial.print(".");
    vTaskDelay(pdMS_TO_TICKS(200));
  }
  Serial.println();

  firebaseHazir = Firebase.ready();
  Serial.printf("[Firebase] Auth: %s\n",
                firebaseHazir ? "OK" : "BASARISIZ (token alinamadi, WiFi/API key/sifre kontrol et)");

  fbdoOku.setBSSLBufferSize(16384, 512);
}

// ============================================================================
// HARITA / FIREBASE KOORDINAT OKUMA
// Sadece aynı measurement kaydının kendi latitude + longitude alanları kullanılır.
// Recursive koordinat arama yoktur.
// ============================================================================
bool firebaseKayitKoordinati(FirebaseJson &kayit, double &lat, double &lon) {
  FirebaseJsonData dLat, dLon;
  bool latOK = false, lonOK = false;

  if (kayit.get(dLat, "/latitude") && dLat.success) {
    lat = dLat.to<double>(); latOK = isfinite(lat);
  } else if (kayit.get(dLat, "/lat") && dLat.success) {
    lat = dLat.to<double>(); latOK = isfinite(lat);
  }

  if (kayit.get(dLon, "/longitude") && dLon.success) {
    lon = dLon.to<double>(); lonOK = isfinite(lon);
  } else if (kayit.get(dLon, "/lon") && dLon.success) {
    lon = dLon.to<double>(); lonOK = isfinite(lon);
  } else if (kayit.get(dLon, "/lng") && dLon.success) {
    lon = dLon.to<double>(); lonOK = isfinite(lon);
  }

  return latOK && lonOK && lat >= 35.0 && lat <= 43.0 && lon >= 24.0 && lon <= 46.0;
}

void haritaNoktalariniTemizle() {
  for (int i = 0; i < HARITA_MAX_NOKTA; ++i) {
    firebaseHaritaNoktalari[i] = {0.0, 0.0, 0.0f, 0.0, false};
  }
  haritaNoktaSayisi = 0;
  haritaToplamGecerli = 0;
}

bool haritaKoordinatiGecerli(double lat, double lon) {
  return isfinite(lat) && isfinite(lon) &&
         lat >= MAP_LAT_MIN && lat <= MAP_LAT_MAX &&
         lon >= MAP_LON_MIN && lon <= MAP_LON_MAX;
}

void firebaseOku() {
  if (!firebaseHazir || WiFi.status() != WL_CONNECTED) {
    sonFirebaseHata = "WiFi veya Firebase auth hazir degil";
    return;
  }

  if (!Firebase.RTDB.getJSON(&fbdoOku, "/measurements")) {
    sonFirebaseHata = fbdoOku.errorReason();
    Serial.printf("[Firebase] Okuma hatasi: %s\n", sonFirebaseHata.c_str());
    return;
  }

  sonFirebaseHata = "";

  if (fbdoOku.dataType() == "null") {
    haritaNoktalariniTemizle();
    Serial.println("[Firebase] /measurements bos.");
    return;
  }

  static FirebaseHaritaNoktasi yeniListe[HARITA_MAX_NOKTA];
  int yeniAdet = 0;

  FirebaseJson &kok = fbdoOku.jsonObject();
  size_t adet = kok.iteratorBegin();

  for (size_t i = 0; i < adet && yeniAdet < HARITA_MAX_NOKTA; ++i) {
    int tip = 0;
    String anahtar, deger;
    kok.iteratorGet(i, tip, anahtar, deger);

    // Sadece gerçek ölçüm kayıtlarını işle.
    if (anahtar.length() == 0 || anahtar == "test_001") continue;
    if (deger.length() == 0 || deger.charAt(0) != '{') continue;

    // ÖNEMLİ:
    // ppm/latitude/longitude değerlerini child JSON'dan tekrar parse etmek
    // yerine doğrudan /measurements kök JSON ağacından okuyoruz.
    // Bu, FirebaseJson iterator çıktısındaki tür/format farklarından dolayı
    // ppm'nin NaN kalıp bütün noktaların mavi görünmesini engeller.
    FirebaseJsonData d;
    String taban = "/" + anahtar;

    double lat = NAN;
    double lon = NAN;
    float ppm = NAN;

    if (kok.get(d, taban + "/latitude") && d.success) lat = d.to<double>();
    else if (kok.get(d, taban + "/lat") && d.success) lat = d.to<double>();

    if (kok.get(d, taban + "/longitude") && d.success) lon = d.to<double>();
    else if (kok.get(d, taban + "/lon") && d.success) lon = d.to<double>();
    else if (kok.get(d, taban + "/lng") && d.success) lon = d.to<double>();

    // Paylaştığın Firebase kayıt yapısındaki gerçek alan:
    // /measurements/{device_id}/ppm
    if (kok.get(d, taban + "/ppm") && d.success) {
      ppm = d.to<float>();
    }

    // Geriye dönük uyumluluk için alternatif alanlar.
    if (!isfinite(ppm)) {
      const char* ppmAlanlari[] = {
        "/nitrate", "/nitratePpm", "/nitrate_ppm",
        "/nitrateMgL", "/nitrate_mg_l",
        "/nitrat", "/nitratPpm", "/nitrat_mg_l",
        "/concentration", "/concentrationPpm",
        "/concentration_mg_l", "/result",
        "/measurementValue", "/value", "/sonuc", "/deger"
      };

      for (size_t p = 0; p < sizeof(ppmAlanlari) / sizeof(ppmAlanlari[0]); ++p) {
        if (kok.get(d, taban + String(ppmAlanlari[p])) && d.success) {
          float aday = d.to<float>();
          if (isfinite(aday) && aday >= 0.0f) {
            ppm = aday;
            break;
          }
        }
      }
    }

    if (!isfinite(lat) || !isfinite(lon)) {
      Serial.printf("[HARITA] %s koordinat eksik/gecersiz.\n", anahtar.c_str());
      continue;
    }

    if (!haritaKoordinatiGecerli(lat, lon)) {
      Serial.printf("[HARITA] %s Türkiye harita sınırı dışında: %.6f, %.6f\n",
                    anahtar.c_str(), lat, lon);
      continue;
    }

    double zaman = 0.0;
    if (kok.get(d, taban + "/timestamp") && d.success) {
      zaman = d.to<double>();
    }

    if (isfinite(ppm)) {
      // UI_GREEN/UI_YELLOW/UI_RED renk sabitleri bu fonksiyonun
      // bulunduğu satırdan sonra tanımlı olabildiği için burada
      // doğrudan ppm eşikleriyle log rengi belirleniyor.
      const char* renkAdi =
        (ppm <= HARITA_NORMAL_MAX_PPM) ? "YESIL" :
        (ppm <= HARITA_YUKSEK_MAX_PPM) ? "SARI" :
                                         "KIRMIZI";

      Serial.printf("[HARITA] %s | ppm=%.3f | %s | %.6f, %.6f\n",
                    anahtar.c_str(), ppm, renkAdi, lat, lon);
    } else {
      Serial.printf("[HARITA] %s | ppm OKUNAMADI -> MAVI\n", anahtar.c_str());
    }

    yeniListe[yeniAdet] = {lat, lon, ppm, zaman, true};
    ++yeniAdet;
  }

  kok.iteratorEnd();

  haritaNoktalariniTemizle();

  for (int i = 0; i < yeniAdet; ++i) {
    firebaseHaritaNoktalari[i] = yeniListe[i];
  }

  haritaNoktaSayisi = yeniAdet;
  haritaToplamGecerli = yeniAdet;

  Serial.printf("[Firebase] Harita RAM dizisine %d koordinat alindi.\n", yeniAdet);
}
// Geoapify Static Maps görüntüsünü RAM'e bir kez indirir.
// area=rect parametresindeki koordinatlar ile nokta dönüşümünde kullanılan
// MAP_* sınırları aynıdır: kuzey-batı -> güney-doğu.
bool geoapifyHaritayiYukle(int w, int h) {
  if (geoapifyHaritaHazir && geoapifyHaritaPng && geoapifyHaritaPngLen > 0) return true;
  if (WiFi.status() != WL_CONNECTED) { geoapifyHaritaHata = "WiFi yok"; return false; }

  String key = GEOAPIFY_API_KEY;
  if (key.indexOf("BURAYA_") >= 0 || key.length() < 16) {
    geoapifyHaritaHata = "Geoapify API anahtari girilmedi";
    return false;
  }

  // Geoapify area sırası: rect:lon1,lat1,lon2,lat2.
  // Türkiye için NW=(minLon,maxLat), SE=(maxLon,minLat).
  String url = String("https://maps.geoapify.com/v1/staticmap?style=") + GEOAPIFY_MAP_STYLE +
               "&width=" + String(w) + "&height=" + String(h) +
               "&format=png&area=rect:" + String(MAP_LON_MIN, 5) + "," + String(MAP_LAT_MAX, 5) +
               "," + String(MAP_LON_MAX, 5) + "," + String(MAP_LAT_MIN, 5) +
               "&lang=tr&apiKey=" + key;

  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.setTimeout(30000);
  http.setUserAgent("NitraCheck-ESP32");
  if (!http.begin(client, url)) { geoapifyHaritaHata = "HTTPS baslatilamadi"; return false; }

  int code = http.GET();
  if (code != HTTP_CODE_OK) {
    geoapifyHaritaHata = String("Geoapify HTTP ") + code;
    http.end();
    return false;
  }

  int len = http.getSize();
  if (len <= 0 || len > 3 * 1024 * 1024) {
    geoapifyHaritaHata = "Gecersiz harita boyutu";
    http.end();
    return false;
  }

  uint8_t* yeni = (uint8_t*)ps_malloc((size_t)len);
  if (!yeni) yeni = (uint8_t*)malloc((size_t)len);
  if (!yeni) { geoapifyHaritaHata = "Harita RAM ayirma hatasi"; http.end(); return false; }

  WiFiClient* stream = http.getStreamPtr();
  size_t toplam = 0;
  unsigned long sonVeri = millis();
  while (toplam < (size_t)len && http.connected()) {
    size_t available = stream->available();
    if (available) {
      size_t okunacak = min(available, (size_t)len - toplam);
      int n = stream->readBytes(yeni + toplam, okunacak);
      if (n > 0) { toplam += (size_t)n; sonVeri = millis(); }
    } else {
      if (millis() - sonVeri > 30000) break;
      delay(2);
    }
  }
  http.end();

  if (toplam != (size_t)len) {
    free(yeni);
    geoapifyHaritaHata = "Harita indirme eksik";
    return false;
  }

  if (geoapifyHaritaPng) free(geoapifyHaritaPng);
  geoapifyHaritaPng = yeni;
  geoapifyHaritaPngLen = toplam;
  geoapifyHaritaHazir = true;
  geoapifyHaritaHata = "";
  Serial.printf("[HARITA] Geoapify PNG RAM'e alindi: %u byte\n", (unsigned)toplam);
  return true;
}

// Geoapify statik haritası Web Mercator tabanlıdır. Boylam doğrusal,
// enlem Mercator dönüşümü ile piksele çevrilir.
double haritaMercatorY(double lat) {
  const double r = lat * PI / 180.0;
  return log(tan(PI / 4.0 + r / 2.0));
}

bool haritaKoordinatindanPiksele(double lat, double lon,
                                 int x, int y, int w, int h,
                                 int &px, int &py) {
  if (!haritaKoordinatiGecerli(lat, lon)) return false;
  double nx = (lon - MAP_LON_MIN) / (MAP_LON_MAX - MAP_LON_MIN);
  double mTop = haritaMercatorY(MAP_LAT_MAX);
  double mBottom = haritaMercatorY(MAP_LAT_MIN);
  double ny = (mTop - haritaMercatorY(lat)) / (mTop - mBottom);
  px = x + (int)lround(nx * (w - 1));
  py = y + (int)lround(ny * (h - 1));
  return px >= x && px < x + w && py >= y && py < y + h;
}

// WiFi baglandiktan sonra calismasi gereken servisler (NTP saat senkronizasyonu
// + Firebase baslatma/okuma). Hem setup() icinde acilista, hem de Ayarlar
// sayfasindan calisma zamaninda yeni bir aga baglanildiginda cagrilir.
void wifiSonrasiServisleriBaslat() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[Servis] WiFi bagli degil, NTP/Firebase atlaniyor.");
    return;
  }

  Serial.println(WiFi.localIP());

  configTime(3 * 3600, 0, "pool.ntp.org", "time.google.com");

  Serial.print("[NTP] Saat senkronize ediliyor");
  time_t simdi = time(nullptr);
  unsigned long ntpBaslangic = millis();

  while (simdi < 8 * 3600 * 2 &&
         millis() - ntpBaslangic < 10000) {
    vTaskDelay(pdMS_TO_TICKS(200));
    Serial.print(".");
    simdi = time(nullptr);
  }
  Serial.println();

  bool ntpOk = (simdi >= 8 * 3600 * 2);

  struct tm zamanBilgisi;
  localtime_r(&simdi, &zamanBilgisi);

  char zamanMetni[32];
  strftime(zamanMetni, sizeof(zamanMetni),
           "%Y-%m-%d %H:%M:%S", &zamanBilgisi);

  sonNtpDurum = ntpOk
    ? String("NTP: OK (") + zamanMetni + ")"
    : "NTP: BASARISIZ (saat 1970'te kaldi)";

  Serial.printf("[NTP] Sonuc: %s\n", sonNtpDurum.c_str());

  // Firebase'i sifirdan baslat (yeni agda eski token/oturum gecersiz
  // olabileceği icin firebaseHazir'i de sifirla).
  firebaseHazir = false;
  firebaseBaslat();
  firebaseOku();
}


// ================================================================
// Forward declarations: buzzer kodu I2C yardımcı fonksiyonlarından önce geliyor.
bool ortakI2CHattiniBaslat();
bool i2cKilitle(TickType_t timeoutTicks = pdMS_TO_TICKS(100));
void i2cBirak();

// NitraCheck Buzzer — CrowPanel Advance 7
// ================================================================
// Advance 7'nin buzzer'ı doğrudan ESP32 GPIO'sundan sürülmüyor.
// STC8H1K28 yardımcı MCU'su üzerinden I2C 0x30 ile kontrol ediliyor.
// V1.3+ firmware:
//   246 = buzzer ON
//   247 = buzzer OFF
//
// Sesin perdesi donanımsal buzzer tarafından belirleniyor; "havalı"
// efektleri ritim/pattern ile oluşturuyoruz. Bu sayede ölçüm, başarı,
// hata, yazdırma ve dokunma gibi olayların her birinin farklı sesi var.

#define BUZZER_ON_CMD   246
#define BUZZER_OFF_CMD  247

void buzzerCmd(uint8_t cmd) {
  if (!ortakI2CHattiniBaslat()) return;
  if (!i2cKilitle(pdMS_TO_TICKS(100))) return;

  Wire.beginTransmission(STC8_ADDR);
  Wire.write(cmd);
  uint8_t err = Wire.endTransmission(true);

  i2cBirak();

  if (err != 0) {
    Serial.printf("[BUZZER] I2C hata: cmd=%u err=%u\n", cmd, err);
  }
}

void buzzerOn() {
  buzzerCmd(BUZZER_ON_CMD);
}

void buzzerOff() {
  buzzerCmd(BUZZER_OFF_CMD);
}

// NOT: Bu buzzer STC8H1K28 uzerinden sadece AC/KAPA (246/247) komutuyla
// suruluyor; ne perde (frekans) ne de ses seviyesi (genlik) yazilimdan
// degistirilebiliyor -- donanim sabit tek tonlu. Bu yuzden "melodik"
// hissi yalnizca RITIM (vurus sayisi, sure, bosluk) ile veriliyor;
// asagidaki desenler klasik tek-notali tik yerine cok-vuruslu, tempo
// degisen (accelerando/ritardando tarzi) motifler kullanir.

// Dokunma: hizli cift-vurus "tik-tik" -- tek duz tiklamadan daha canli.
void buzzerClick() {
  const uint16_t onMs[]  = {18, 22};
  const uint16_t gapMs[] = {16, 0};

  for (uint8_t i = 0; i < 2; i++) {
    buzzerOn();
    vTaskDelay(pdMS_TO_TICKS(onMs[i]));
    buzzerOff();
    if (gapMs[i]) vTaskDelay(pdMS_TO_TICKS(gapMs[i]));
  }
}

// Ölçüm başlarken: hızlanan (accelerando) dörtlü pulse -- bir "geri
// sayım/başlıyor" hissi versin diye vuruşlar arası boşluk giderek kısalır.
void buzzerMeasureStart() {
  const uint16_t onMs[]  = {50, 45, 40, 90};
  const uint16_t gapMs[] = {70, 50, 30, 0};

  for (uint8_t i = 0; i < 4; i++) {
    buzzerOn();
    vTaskDelay(pdMS_TO_TICKS(onMs[i]));
    buzzerOff();
    if (gapMs[i]) vTaskDelay(pdMS_TO_TICKS(gapMs[i]));
  }
}

// Başarılı ölçüm: "ta-ta-ta-taa" fanfare -- üç kısa vuruş sıkılaşan
// aralıklarla gelir, ardından uzun kapanış notası.
void buzzerSuccess() {
  const uint16_t onMs[]  = {45, 45, 55, 160};
  const uint16_t gapMs[] = {60, 45, 35, 0};

  for (uint8_t i = 0; i < 4; i++) {
    buzzerOn();
    vTaskDelay(pdMS_TO_TICKS(onMs[i]));
    buzzerOff();
    if (gapMs[i]) vTaskDelay(pdMS_TO_TICKS(gapMs[i]));
  }
}

// Hata/başarısız işlem: iki uzun uyarı + kısa üçüncü vuruş -- ciddiyeti
// korumak için hâlâ ağır/yavaş, ama düz çift bipten daha belirgin.
void buzzerError() {
  const uint16_t onMs[]  = {140, 140, 70};
  const uint16_t gapMs[] = {100, 120, 0};

  for (uint8_t i = 0; i < 3; i++) {
    buzzerOn();
    vTaskDelay(pdMS_TO_TICKS(onMs[i]));
    buzzerOff();
    if (gapMs[i]) vTaskDelay(pdMS_TO_TICKS(gapMs[i]));
  }
}

// Yazdırma tamamlandı: sönümlenen üçlü onay -- her vuruş bir öncekinden
// kısa, "biten iş" hissi veren yumuşak bir kapanış motifi.
void buzzerPrintDone() {
  const uint16_t onMs[]  = {70, 55, 35};
  const uint16_t gapMs[] = {55, 45, 0};

  for (uint8_t i = 0; i < 3; i++) {
    buzzerOn();
    vTaskDelay(pdMS_TO_TICKS(onMs[i]));
    buzzerOff();
    if (gapMs[i]) vTaskDelay(pdMS_TO_TICKS(gapMs[i]));
  }
}

// STC8H1K28 (I2C adres 0x30) ekran arka isik denetleyicisi.
// Donanimin gercek skalasi 0-244 arasidir ve YONU TERSTIR:
//   0   = maksimum parlaklik
//   244 = minimum parlaklik (ama acik)
//   245 = arka isik tamamen kapali
// Asagidaki fonksiyon, TTGO/ESP32 PWM'de alisik oldugumuz
// 0-255 (255=en parlak) skalasini kabul edip donanimin gercek
// skalasina cevirir. Cagrildigi her an parlaklik degisir; sadece
// aciliste degil, istenildigi zaman (menu, dokunmatik slider,
// zamanlayici v.b.) tekrar cagirabilirsin.
uint8_t uiBacklightLevel = 130;  // TTGO'da begendigin 0-255 degeri (varsayilan)

// KALICI I2C FIX:
// GT911 + STC8H1K28 + AS7341 aynı fiziksel SDA/SCL hattındadır (SHT40 söküldü).
// Bu projede ikinci TwoWire/I2C_NUM_1 kullanilmaz.
// Wire.begin() yalnizca bir kez cagrilir; daha sonra bus yeniden
// baslatilmaz. I2C islemleri mutex ile korunur.
bool i2cKilitle(TickType_t timeoutTicks) {
  if (i2cMutex == nullptr) return false;
  return xSemaphoreTake(i2cMutex, timeoutTicks) == pdTRUE;
}

void i2cBirak() {
  if (i2cMutex != nullptr) xSemaphoreGive(i2cMutex);
}

// Wire SADECE BİR KEZ başlatılır. Bu fonksiyondan sonra hiçbir yerde
// Wire.begin()/Wire1.begin()/TwoWire.begin() çağrılmayacaktır.
bool ortakI2CHattiniBaslat() {
  if (ortakI2CBaslatildiMi) return true;

  if (i2cMutex == nullptr) {
    i2cMutex = xSemaphoreCreateMutex();
    if (i2cMutex == nullptr) {
      Serial.println("[I2C] Mutex olusturulamadi!");
      return false;
    }
  }

  // Tek fiziksel bus: GPIO15=SDA, GPIO16=SCL, I2C_NUM_0/Wire.
  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN, I2C_FREQ_HZ);
  Wire.setTimeOut(50);
  ortakI2CBaslatildiMi = true;

  Serial.printf("[I2C] ORTAK BUS BASLATILDI: SDA=%d SCL=%d FREQ=%lu Hz\n",
                I2C_SDA_PIN, I2C_SCL_PIN, I2C_FREQ_HZ);
  return true;
}

// Ortak I2C hattı açılışta bir cihaz tarafından kısa süre LOW tutulursa
// Wire.begin() tek başına hattı her zaman toparlamaz. Kullanıcının
// "YENIDEN DENE" butonuna basınca düzelmesinin ana nedeni çoğu zaman
// bu ek süre ve boş I2C çevrimidir. Sensör denemelerinden önce hattı
// açık-drenaj olarak serbest bırakıp STOP benzeri 9 saat darbesi veriyoruz.
bool i2cHattiToparla() {
  if (!i2cKilitle(pdMS_TO_TICKS(300))) return false;

  Wire.end();

  pinMode(I2C_SDA_PIN, INPUT_PULLUP);
  pinMode(I2C_SCL_PIN, INPUT_PULLUP);
  delay(5);

  // SCL ile en fazla 9 saat darbesi: yarım kalmış bir slave aktarımını
  // serbest bırakmak için standart I2C recovery yaklaşımı.
  for (int i = 0; i < 9 && digitalRead(I2C_SDA_PIN) == LOW; ++i) {
    pinMode(I2C_SCL_PIN, OUTPUT_OPEN_DRAIN);
    digitalWrite(I2C_SCL_PIN, LOW);
    delayMicroseconds(8);
    digitalWrite(I2C_SCL_PIN, HIGH);
    delayMicroseconds(8);
    pinMode(I2C_SCL_PIN, INPUT_PULLUP);
    delayMicroseconds(8);
  }

  // STOP koşulu: SDA LOW -> SCL HIGH -> SDA HIGH.
  pinMode(I2C_SDA_PIN, OUTPUT_OPEN_DRAIN);
  digitalWrite(I2C_SDA_PIN, LOW);
  delayMicroseconds(8);
  pinMode(I2C_SCL_PIN, INPUT_PULLUP);
  delayMicroseconds(8);
  digitalWrite(I2C_SDA_PIN, HIGH);
  pinMode(I2C_SDA_PIN, INPUT_PULLUP);
  delay(5);

  Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN, I2C_FREQ_HZ);
  Wire.setTimeOut(100);

  bool hatSerbest = (digitalRead(I2C_SDA_PIN) == HIGH &&
                     digitalRead(I2C_SCL_PIN) == HIGH);
  i2cBirak();

  Serial.printf("[I2C] HAT TOPARLAMA: SDA=%s SCL=%s\n",
                digitalRead(I2C_SDA_PIN) ? "HIGH" : "LOW",
                digitalRead(I2C_SCL_PIN) ? "HIGH" : "LOW");
  return hatSerbest;
}

bool i2cCihazVar(uint8_t address) {
  if (!i2cKilitle(pdMS_TO_TICKS(200))) return false;

  Wire.beginTransmission(address);
  uint8_t err = Wire.endTransmission(true);

  i2cBirak();
  return err == 0;
}

void setBacklight(uint8_t level0to255) {
  if (!ortakI2CHattiniBaslat()) return;

  // Donanım ters skalayı kullanıyor:
  // 0 = maksimum, 244 = minimum, 245 = kapalı.
  uint16_t inverted = (uint16_t)(255 - level0to255) * 244 / 255;
  if (inverted > 244) inverted = 244;

  // STC8H1K28: önce 0x10 ile backlight'ı etkinleştir,
  // sonra parlaklık değerini gönder.
  if (!i2cKilitle(pdMS_TO_TICKS(100))) return;

  Wire.beginTransmission(STC8_ADDR);
  Wire.write((uint8_t)0x10);
  uint8_t e1 = Wire.endTransmission(true);

  i2cBirak();

  // I2C bus'ı mutex'i gereksiz yere 20 ms tutmasın.
  vTaskDelay(pdMS_TO_TICKS(20));

  if (!i2cKilitle(pdMS_TO_TICKS(100))) return;

  Wire.beginTransmission(STC8_ADDR);
  Wire.write((uint8_t)inverted);
  uint8_t e2 = Wire.endTransmission(true);

  i2cBirak();

  if (e1 != 0 || e2 != 0) {
    Serial.printf("[BACKLIGHT] I2C hata: enable=%u level=%u\n", e1, e2);
    return;
  }

  uiBacklightLevel = level0to255;
}

void backlightOn() {
  if (!ortakI2CHattiniBaslat()) return;
  vTaskDelay(pdMS_TO_TICKS(50));
  setBacklight(uiBacklightLevel);
}

// ── AYARLAR > EKRAN PARLAKLIĞI SÜRGÜSÜ (slider) ──────────────────
// Ayarlar sayfasındaki kullanılmayan "Cihaz ID / Firebase / Saat"
// etiket satırlarının yerine kondu. Sürükleyerek 0-255 (görsel
// olarak %0-%100) arası ekran parlaklığı ayarlanır.
const int BRIGHT_TRACK_X = 105;
const int BRIGHT_TRACK_Y = 210;
const int BRIGHT_TRACK_W = 590;   // Ayarlar ekraninin altinda tam genislik
const int BRIGHT_TRACK_H = 32;

// Sürükleme sırasında gerçekten bir değişiklik olduysa true olur;
// parmak kaldırıldığında NVS'e kaydedilip tekrar false yapılır. Böylece
// Ayarlar ekranındaki alakasız bir dokunuş (ör. GERİ butonu) NVS'e
// gereksiz yazım yaptırmaz.
bool parlaklikKaydiBekliyor = false;


// ================================================================
// EMBEDDED TURKISH FONT
// TRFont18 / TRFont24 / TRFont40 -> bkz. yukaridaki #include satirlari
// ve "Font helpers" bolumu.
// ================================================================
// ================================================================
// UI
// ================================================================

NitraScreen currentScreen = SCREEN_MAIN;
bool uiDrawn = false;
bool splashFinished = false;
unsigned long splashStart = 0;
bool previousTouch = false;

// ================================================================
// WIFI AYARLARI / TARAMA / KLAVYE
// ================================================================
#define WIFI_TARAMA_MAKS 15

String wifiTaramaSSID[WIFI_TARAMA_MAKS];
int    wifiTaramaRSSI[WIFI_TARAMA_MAKS];
bool   wifiTaramaAcik[WIFI_TARAMA_MAKS];
int    wifiTaramaSayisi = 0;
bool   wifiTaraniyor = false;
unsigned long wifiTaramaBaslangic = 0;

// Ekran üzerinde gösterilecek tanı bilgisi (Serial Monitor çalışmasa da
// "ağ bulunamadı" ekranında görünür, WiFi radyosunun gerçekten neden
// başarısız olduğunu anlamak için).
int  wifiTaniMod = -1;
int  wifiTaniDurum = -1;
int  wifiTaniSonKod = -99;
int  wifiTaniDeneme = 0;

// Son "bağlantı reddedildi" olayının gerçek IDF sebep kodu (ör. WPA3/
// eşleşmeme, kimlik doğrulama reddi, ağ bulunamadı vb.). WiFi.onEvent
// ile ARDUINO_EVENT_WIFI_STA_DISCONNECTED üzerinden dolduruluyor; bu
// sayede "ŞİFREYİ KONTROL EDİN" ekranı yerine gerçek sebep görülebilir.
volatile uint8_t sonWifiKopmaSebebi = 0;

void wifiOlayIsleyici(WiFiEvent_t event, WiFiEventInfo_t info) {
  if (event == ARDUINO_EVENT_WIFI_STA_DISCONNECTED) {
    sonWifiKopmaSebebi = info.wifi_sta_disconnected.reason;
  }
}

// IDF WiFi kopma sebep kodunu kısa, anlaşılır bir Türkçe metne çevirir.
// Tam liste için esp_wifi_types.h / wifi_err_reason_t bakılabilir.
const char* wifiKopmaSebebiMetni(uint8_t reason) {
  switch (reason) {
    case 2:   return "Kimlik dogrulama reddedildi";
    case 15:  return "4-way handshake basarisiz (sifre yanlis olabilir)";
    case 201: return "Ag bulunamadi (SSID yok / 5GHz olabilir)";
    case 202: return "Baglanti reddedildi";
    case 203: return "Kimlik dogrulama basarisiz";
    case 204: return "Kimlik dogrulama zaman asimi";
    case 205: return "AP kimlik dogrulama modu desteklenmiyor (WPA3?)";
    case 8:   return "AP tarafindan disari atildi (MAC filtre olabilir)";
    default:  return "Bilinmeyen sebep";
  }
}

String wifiSecilenSSID = "";
String wifiSifreGirisi = "";
bool   wifiSifreGoster = false;
bool   wifiBaglaniyor = false;
bool   wifiBaglantiHatasi = false;
int    wifiListeKaydirma = 0;

bool wifiKlavyeSayiModu = false;
bool wifiKlavyeShift = false;

Preferences wifiPrefs;
Preferences cloudPrefs;
Preferences uiPrefs;   // Ekran parlaklığı gibi arayüz tercihleri icin

// ================================================================
// BULUT SENKRONIZASYONU - cihaz hafızası + Firebase iki yönlü eşitleme
// ================================================================
// KAL-NVS TANI: 20 -> 10. Bu blob ("cloud" namespace, local_blob anahtari)
// kalibrasyon blobuyla AYNI paylasilan "nvs" partisyonunda ve her olcumden
// sonra bastan yaziliyor; 20 kayitlik hali ~1808 byte (~58 NVS girisi)
// tutuyordu ve tekrar tekrar yazilip silinerek partisyonu parcaliyordu.
// 10 kayit, boyutu ~904 byte'a (~29 girise) indirir.
#define YEREL_OLCUM_MAX 10

struct YerelOlcum {
  String id;
  float ppm;
  double lat;
  double lon;
  uint32_t zaman;
  bool gecerli;
  bool bulutaGonderildi;
};

YerelOlcum yerelOlcumler[YEREL_OLCUM_MAX];
int yerelOlcumSayisi = 0;

String sonBulutDurumu = "Hazır";
int firebaseToplamKayit = 0;
bool bulutSenkronizasyonu = false;

// ─── YAZDIRMA İÇİN SON ÖLÇÜM BİLGİSİ ────────────────────────────
// yeniOlcumuRAMeEkle() içinde doldurulur; fişte kullanılır.
String sonOlcumId = "";
double sonOlcumLat = 0.0;
double sonOlcumLon = 0.0;
uint32_t sonOlcumZaman = 0;
String cihazIdMetni = "";

// ----------------------------------------------------------------
// ADIM16: Yerel ölçümlerin tek NVS blob formatı.
// String doğrudan serileştirilmez; ID sabit uzunluklu char dizisidir.
// ----------------------------------------------------------------
#define YEREL_OLCUM_BLOB_KEY "local_blob"
#define YEREL_OLCUM_BLOB_MAGIC 0x4E434C31UL  // "NCL1"
#define YEREL_OLCUM_BLOB_VERSION 1
#define YEREL_OLCUM_ID_MAX 64

struct __attribute__((packed)) YerelOlcumBlobKayit {
  char id[YEREL_OLCUM_ID_MAX];
  float ppm;
  double lat;
  double lon;
  uint32_t zaman;
  uint8_t gecerli;
  uint8_t bulutaGonderildi;
};

struct __attribute__((packed)) YerelOlcumBlob {
  uint32_t magic;
  uint16_t version;
  uint16_t kayitSayisi;
  YerelOlcumBlobKayit kayitlar[YEREL_OLCUM_MAX];
};

static_assert(sizeof(YerelOlcumBlob) < 1984,
              "YerelOlcumBlob NVS tek-blob limitini asmamali");

void yerelOlcumleriTemizle() {
  for (int i = 0; i < YEREL_OLCUM_MAX; i++) {
    yerelOlcumler[i].id = "";
    yerelOlcumler[i].ppm = 0;
    yerelOlcumler[i].lat = 0;
    yerelOlcumler[i].lon = 0;
    yerelOlcumler[i].zaman = 0;
    yerelOlcumler[i].gecerli = false;
    yerelOlcumler[i].bulutaGonderildi = false;
  }
  yerelOlcumSayisi = 0;
}

void yerelOlcumKaydet() {
  // ADIM16: clear() + kayıt başına putXXX() YOK.
  // Tüm yerel ölçüm durumu tek putBytes() çağrısıyla yazılır.
  YerelOlcumBlob blob = {};
  blob.magic = YEREL_OLCUM_BLOB_MAGIC;
  blob.version = YEREL_OLCUM_BLOB_VERSION;

  uint16_t adet = (uint16_t)min(yerelOlcumSayisi, YEREL_OLCUM_MAX);
  blob.kayitSayisi = adet;

  for (uint16_t i = 0; i < adet; i++) {
    const YerelOlcum &r = yerelOlcumler[i];
    YerelOlcumBlobKayit &d = blob.kayitlar[i];

    // String'i güvenli ve sabit boyutlu char alanına kopyala.
    strncpy(d.id, r.id.c_str(), YEREL_OLCUM_ID_MAX - 1);
    d.id[YEREL_OLCUM_ID_MAX - 1] = '\0';

    d.ppm = r.ppm;
    d.lat = r.lat;
    d.lon = r.lon;
    d.zaman = r.zaman;
    d.gecerli = r.gecerli ? 1 : 0;
    d.bulutaGonderildi = r.bulutaGonderildi ? 1 : 0;
  }

  size_t yazilan = cloudPrefs.putBytes(YEREL_OLCUM_BLOB_KEY,
                                       &blob, sizeof(blob));

  if (yazilan != sizeof(blob)) {
    Serial.printf("[NVS] Yerel blob yazma HATASI: %u/%u byte\n",
                  (unsigned)yazilan, (unsigned)sizeof(blob));
  } else {
    Serial.printf("[NVS] Yerel blob tek commit ile yazildi: %u byte, %u kayit\n",
                  (unsigned)sizeof(blob), (unsigned)blob.kayitSayisi);
  }
}

// Eski ADIM15 formatını okur:
// count, r0id/r0ppm/r0lat/r0lon/r0time/r0sent, ...
// Başarılıysa RAM'e doldurur. Yeni blob yazımı bu fonksiyonda yapılmaz.
bool yerelOlcumEskiFormatYukle() {
  if (!cloudPrefs.isKey("count")) {
    yerelOlcumleriTemizle();
    return false;
  }

  yerelOlcumleriTemizle();

  int adet = (int)cloudPrefs.getUInt("count", 0);
  if (adet < 0) adet = 0;
  if (adet > YEREL_OLCUM_MAX) adet = YEREL_OLCUM_MAX;

  for (int i = 0; i < adet; i++) {
    String k = "r" + String(i);
    String id = cloudPrefs.getString((k + "id").c_str(), "");

    if (id.length() == 0) continue;

    float ppm = cloudPrefs.getFloat((k + "ppm").c_str(), NAN);
    double lat = cloudPrefs.getDouble((k + "lat").c_str(), NAN);
    double lon = cloudPrefs.getDouble((k + "lon").c_str(), NAN);

    // Eski NVS kaydında bozuk/NaN/Inf sayısal veri varsa bu kaydı alma.
    // 0,0 GPS fix yok anlamına geldiği için geçerlidir; gerçek koordinat varsa
    // coğrafi sınırlar içinde olmalıdır.
    bool konumSifir = (lat == 0.0 && lon == 0.0);
    bool konumGecerli = konumSifir ||
      (lat >= -90.0 && lat <= 90.0 && lon >= -180.0 && lon <= 180.0);
    if (!isfinite(ppm) || ppm < 0.0f || !isfinite(lat) || !isfinite(lon) || !konumGecerli) {
      Serial.printf("[NVS] Eski kayit %d sayisal olarak gecersiz, atlandi.\n", i);
      continue;
    }

    yerelOlcumler[yerelOlcumSayisi].id = id;
    yerelOlcumler[yerelOlcumSayisi].ppm = ppm;
    yerelOlcumler[yerelOlcumSayisi].lat = lat;
    yerelOlcumler[yerelOlcumSayisi].lon = lon;
    yerelOlcumler[yerelOlcumSayisi].zaman =
      cloudPrefs.getUInt((k + "time").c_str(), 0);
    yerelOlcumler[yerelOlcumSayisi].gecerli = true;
    yerelOlcumler[yerelOlcumSayisi].bulutaGonderildi =
      cloudPrefs.getBool((k + "sent").c_str(), false);

    yerelOlcumSayisi++;
  }

  Serial.printf("[NVS] Eski format yuklendi: %d kayit.\n", yerelOlcumSayisi);
  return true;
}

// KAL-NVS TANI: ADIM15 -> ADIM16 gecisinde eski format anahtarlari
// (count, r0id, r0ppm, r0lat, r0lon, r0time, r0sent, r1id, ... r19sent)
// hicbir zaman silinmiyordu. Bu ~121 anahtar, ADIM16'dan once her
// olcumde tek tek yazilip siliniyordu ve NVS'nin "cloud" namespace'inde
// kalici olarak yer kaplamaya devam ediyor -- partisyon fragmentasyonunun
// en buyuk tarihsel kaynagi muhtemelen budur. Bir kez calisip
// "eskiTemizV1" bayragiyla isaretlenir; sonraki acilislarda tekrar
// calismaz (gereksiz remove/commit dongusu olmasin diye).
void eskiOlcumAnahtarlariniTemizle() {
  if (cloudPrefs.getBool("eskiTemizV1", false)) return;

  bool birseySilindi = false;
  if (cloudPrefs.isKey("count")) {
    cloudPrefs.remove("count");
    birseySilindi = true;
  }

  // ADIM15'te YEREL_OLCUM_MAX 20 idi; mevcut deger daha kucuk olsa bile
  // guvenli tarafta kalmak icin sabit 20'ye kadar taranir.
  const int ESKI_MAX = 20;
  const char *alanlar[] = {"id", "ppm", "lat", "lon", "time", "sent"};
  for (int i = 0; i < ESKI_MAX; i++) {
    String k = "r" + String(i);
    for (int a = 0; a < 6; a++) {
      String anahtar = k + alanlar[a];
      if (cloudPrefs.isKey(anahtar.c_str())) {
        cloudPrefs.remove(anahtar.c_str());
        birseySilindi = true;
      }
    }
  }

  cloudPrefs.putBool("eskiTemizV1", true);
  Serial.printf("[NVS] Eski ADIM15 anahtarlari temizlendi (silinen: %s)\n",
                birseySilindi ? "EVET" : "hayir/zaten yoktu");
}

void yerelOlcumYukle() {
  yerelOlcumleriTemizle();

  size_t blobUzunlugu = cloudPrefs.getBytesLength(YEREL_OLCUM_BLOB_KEY);
  bool yeniBlobGecerli = false;

  if (blobUzunlugu == sizeof(YerelOlcumBlob)) {
    YerelOlcumBlob blob = {};
    size_t okunan = cloudPrefs.getBytes(YEREL_OLCUM_BLOB_KEY,
                                        &blob, sizeof(blob));

    if (okunan == sizeof(blob) &&
        blob.magic == YEREL_OLCUM_BLOB_MAGIC &&
        blob.version == YEREL_OLCUM_BLOB_VERSION &&
        blob.kayitSayisi <= YEREL_OLCUM_MAX) {

      for (uint16_t i = 0; i < blob.kayitSayisi; i++) {
        const YerelOlcumBlobKayit &d = blob.kayitlar[i];
        if (d.id[0] == '\0') continue;

        bool konumSifir = (d.lat == 0.0 && d.lon == 0.0);
        bool konumGecerli = konumSifir ||
          (d.lat >= -90.0 && d.lat <= 90.0 && d.lon >= -180.0 && d.lon <= 180.0);
        if (!isfinite(d.ppm) || d.ppm < 0.0f ||
            !isfinite(d.lat) || !isfinite(d.lon) || !konumGecerli) {
          Serial.printf("[NVS] Blob kaydi %u sayisal olarak gecersiz, atlandi.\n", (unsigned)i);
          continue;
        }

        yerelOlcumler[yerelOlcumSayisi].id = String(d.id);
        yerelOlcumler[yerelOlcumSayisi].ppm = d.ppm;
        yerelOlcumler[yerelOlcumSayisi].lat = d.lat;
        yerelOlcumler[yerelOlcumSayisi].lon = d.lon;
        yerelOlcumler[yerelOlcumSayisi].zaman = d.zaman;
        yerelOlcumler[yerelOlcumSayisi].gecerli = d.gecerli != 0;
        yerelOlcumler[yerelOlcumSayisi].bulutaGonderildi =
          d.bulutaGonderildi != 0;
        yerelOlcumSayisi++;
      }

      yeniBlobGecerli = true;
      Serial.printf("[NVS] Yeni blob yuklendi: %d kayit.\n",
                    yerelOlcumSayisi);
    } else {
      Serial.println("[NVS] Blob bulundu ancak magic/version/uzunluk gecersiz; eski formata bakiliyor.");
    }
  }

  if (!yeniBlobGecerli) {
    // Yeni blob yoksa veya geçersizse mevcut ADIM15 key formatını oku.
    bool eskiFormatVardi = yerelOlcumEskiFormatYukle();

    // Migrasyon yalnızca açılışta yapılır. Ölçüm sırasında clear/put* yoktur.
    // Eski format olmasa bile bir kez boş/geçerli blob oluşturulur.
    (void)eskiFormatVardi;
    yerelOlcumKaydet();
  }

  // KAL-NVS TANI: yeni blob zaten gecerliyse dahi (yani gecmiste bir kez
  // migrasyon zaten yapilmissa) eski anahtarlar hala NVS'te kalmis
  // olabilir; bu yuzden cagri kosula bagli degil, HER ACILISTA yapilir
  // (fonksiyon kendi icinde "eskiTemizV1" bayragiyla tek seferlik calisir).
  eskiOlcumAnahtarlariniTemizle();

  Serial.printf("[Bulut] Yerel hafizada %d olcum bulundu.\n", yerelOlcumSayisi);
}
int yerelOlcumIndexBul(const String &id) {
  for (int i = 0; i < yerelOlcumSayisi; i++) {
    if (yerelOlcumler[i].gecerli && yerelOlcumler[i].id == id)
      return i;
  }
  return -1;
}

// Senkronizasyon sirasinda hangi kayitlarin Firebase'de gercekten
// var oldugunu isaretlemek icin kullanilir (index yerelOlcumler[] ile
// esler). true olanlar buluttaki kayitlarla eslesmis demektir.
bool bulutIcindeVarMi[YEREL_OLCUM_MAX];

// Firebase'de olmayan yerel kayitlar SILINMEZ.
// Senkronizasyonda Firebase'in gercek durumu esas alinir.

void yerelOlcumEkle(const String &id, float ppm, double lat, double lon,
                    uint32_t zaman, bool gonderildi) {
  if (id.length() == 0) return;

  int mevcut = yerelOlcumIndexBul(id);
  if (mevcut >= 0) {
    yerelOlcumler[mevcut].ppm = ppm;
    yerelOlcumler[mevcut].lat = lat;
    yerelOlcumler[mevcut].lon = lon;
    yerelOlcumler[mevcut].zaman = zaman;
    yerelOlcumler[mevcut].bulutaGonderildi |= gonderildi;
    return;
  }

  if (yerelOlcumSayisi >= YEREL_OLCUM_MAX) {
    // AKILLI DUSURME: Once buluta zaten GONDERILMIS kayitlar arasindan en
    // eskisini bul ve onu dusur; gonderilmemis kayitlara DOKUNMA. Boylece
    // kuyruk kucultulmus olsa bile (20->10), henuz buluta ulasmamis bir
    // olcum -- hala gonderilmis bir kayit varken -- asla sessizce kaybolmaz.
    int dusurulecek = -1;
    for (int i = 0; i < yerelOlcumSayisi; i++) {
      if (yerelOlcumler[i].bulutaGonderildi) { dusurulecek = i; break; }
    }

    if (dusurulecek < 0) {
      // Son care: kuyruktaki HICBIR kayit henuz gonderilmemis. Sabit
      // boyutlu tampon dolu oldugu icin yine de en eskisini dusurmek
      // zorundayiz, ama bunu acikca logluyoruz ki fark edilsin.
      dusurulecek = 0;
      Serial.println("[Bulut] UYARI: kuyruk dolu ve HICBIR kayit gonderilmemis; "
                     "en eski (gonderilmemis) kayit dusuruluyor.");
    }

    for (int i = dusurulecek + 1; i < yerelOlcumSayisi; i++)
      yerelOlcumler[i - 1] = yerelOlcumler[i];
    yerelOlcumSayisi--;
  }

  YerelOlcum &r = yerelOlcumler[yerelOlcumSayisi++];
  r.id = id;
  r.ppm = ppm;
  r.lat = lat;
  r.lon = lon;
  r.zaman = zaman;
  r.gecerli = true;
  r.bulutaGonderildi = gonderildi;
}

void yeniOlcumuRAMeEkle(float ppm) {
  if (!isfinite(ppm)) return;

  time_t simdi = time(nullptr);
  uint32_t zaman = (simdi > 100000) ? (uint32_t)simdi : (uint32_t)millis();

  // Bu cihaz için benzersiz ve Firebase anahtarında güvenli ID.
  String id = "device_" + String((uint32_t)ESP.getEfuseMac(), HEX) +
              "_" + String(zaman) + "_" + String((uint32_t)millis());

  // ADIM16: Ölçüm bitiminde yalnızca RAM'e ekle.
  // NVS/flash yazımı burada kesinlikle yapılmaz.
  // GPS fix'i geçerliyse ölçüm anındaki gerçek konumu kullan.
  //
  // ADIM19-FIX: Ölçüm, birkaç saniye süren bloklayan bir işlem olduğu
  // ve bu süre boyunca gpsGuncelle() (dolayısıyla GPS UART okuma) hiç
  // çalışmadığı için, "ÖLÇÜMÜ BAŞLAT" butonuna basıldığı TAM anda uydu
  // sinyali kısa süreliğine (özellikle iç mekanda) dalgalanmışsa
  // gpsKonumGecerli o an false donuyor ve tüm ölçüm -- ekranda az önce/
  // az sonra "GPS VAR" görünse bile -- konumsuz (0,0) kaydediliyordu.
  // Bu da fiş yazdırılırken hem koordinat satırının hem QR kodun hiç
  // basılmamasına yol açıyordu. Çözüm: anlık fix yoksa, GPS_SON_IYI_FIX_
  // GECERLILIK_MS içinde alınmış son gerçek fix'i yedek olarak kullan.
  double kayitLat, kayitLon;
  bool sonIyiFixKullanildi = false;

  if (gpsKonumGecerli) {
    kayitLat = gpsEnlem;
    kayitLon = gpsBoylam;
  } else if (gpsSonIyiFixMs != 0 &&
             millis() - gpsSonIyiFixMs <= GPS_SON_IYI_FIX_GECERLILIK_MS) {
    kayitLat = gpsSonIyiEnlem;
    kayitLon = gpsSonIyiBoylam;
    sonIyiFixKullanildi = true;
  } else {
    // Gercekten uzun suredir hic fix yoksa sahte koordinat YAZILMIYOR,
    // 0,0 olarak birakiliyor (firebaseYerelOlcumleriGonder icindeki
    // Turkiye sinir kontrolu bu durumda latitude/longitude alanlarini
    // Firebase'e hic gondermiyor).
    kayitLat = 0.0;
    kayitLon = 0.0;
  }

  yerelOlcumEkle(id, ppm, kayitLat, kayitLon, zaman, false);

  // Fiş yazdırma ekranı en son ölçümün kimlik/konum bilgisine buradan ulaşır.
  sonOlcumId = id;
  sonOlcumLat = kayitLat;
  sonOlcumLon = kayitLon;
  sonOlcumZaman = zaman;

  if (sonIyiFixKullanildi) {
    Serial.println("[Bulut] UYARI: Olcum aninda anlik GPS fix yoktu, son iyi fix yedek olarak kullanildi.");
  } else if (!gpsKonumGecerli) {
    Serial.println("[Bulut] UYARI: GPS fix yok, olcum konumsuz kaydedildi.");
  }

  Serial.printf("[Bulut] Yeni olcum RAM'e eklendi: %s | %.2f ppm\n",
                id.c_str(), ppm);
}


bool firebaseKaydiOku(FirebaseJson &kayit, float &ppm, double &lat,
                      double &lon, uint32_t &zaman) {
  FirebaseJsonData d;
  ppm = 0;
  lat = 0;
  lon = 0;
  zaman = 0;

  if (kayit.get(d, "/ppm") && d.success) ppm = d.to<float>();
  else if (kayit.get(d, "/nitrate") && d.success) ppm = d.to<float>();
  else if (kayit.get(d, "/value") && d.success) ppm = d.to<float>();

  if (kayit.get(d, "/latitude") && d.success) lat = d.to<double>();
  else if (kayit.get(d, "/lat") && d.success) lat = d.to<double>();

  if (kayit.get(d, "/longitude") && d.success) lon = d.to<double>();
  else if (kayit.get(d, "/lng") && d.success) lon = d.to<double>();
  else if (kayit.get(d, "/lon") && d.success) lon = d.to<double>();

  if (kayit.get(d, "/timestamp") && d.success) zaman = d.to<uint32_t>();
  else if (kayit.get(d, "/time") && d.success) zaman = d.to<uint32_t>();

  return true;
}


// ================================================================
// FIREBASE <-> CİHAZ SENKRONİZASYONU — ID TABANLI
// ================================================================
//
// Kural:
// 1) Eşleşmenin tek anahtarı Firebase child ID'sidir.
// 2) Firebase'de bulunan ID cihazda da varsa KESİNLİKLE yeni kayıt açılmaz.
// 3) Firebase'de olmayan cihaz ID'si tekrar Firebase'e gönderilir.
// 4) Firebase'de olup cihazda olmayan kayıt, hafıza boşluğu varsa indirilir.
// 5) Firebase'den okuma başarısızsa hiçbir yerel kayıt değiştirilmez.
// 6) Senkronizasyon Firebase'deki eski kayıtları koordinat/ppm ile tahmin
//    ederek eşleştirmez. Sadece ID == ID kabul edilir.
//

#define BULUT_ID_MAKS 128
String bulutIDler[BULUT_ID_MAKS];
int bulutIDSayisi = 0;
int bulutEslesenSayisi = 0;
int bulutYeniCihazaIndirilen = 0;
int bulutYeniGonderilen = 0;

bool firebaseIDVarMi(const String &id) {
  if (id.length() == 0) return false;
  for (int i = 0; i < bulutIDSayisi; i++) {
    if (bulutIDler[i] == id) return true;
  }
  return false;
}

bool firebaseBulutKayitlariniHafizayaAl() {
  if (!Firebase.RTDB.getJSON(&fbdoOku, "/measurements")) {
    sonBulutDurumu = "Firebase okuma hatasi";
    Serial.printf("[SYNC] Firebase OKUMA HATASI: %s\n",
                  fbdoOku.errorReason().c_str());
    return false;
  }

  // Bu senkronizasyon turunun Firebase ID listesi.
  bulutIDSayisi = 0;
  bulutEslesenSayisi = 0;
  bulutYeniCihazaIndirilen = 0;
  firebaseToplamKayit = 0;

  for (int i = 0; i < YEREL_OLCUM_MAX; i++)
    bulutIcindeVarMi[i] = false;

  if (fbdoOku.dataType() == "null") {
    Serial.println("[SYNC] /measurements BOS.");
    return true;
  }

  FirebaseJson &kok = fbdoOku.jsonObject();
  size_t adet = kok.iteratorBegin();

  for (size_t i = 0; i < adet; i++) {
    int tip = 0;
    String anahtar, deger;
    kok.iteratorGet(i, tip, anahtar, deger);

    if (anahtar.length() == 0) continue;

    // Firebase'deki child ID'yi kaydet.
    if (bulutIDSayisi < BULUT_ID_MAKS)
      bulutIDler[bulutIDSayisi++] = anahtar;

    FirebaseJson kayit;
    bool jsonGecerli = false;

    if (deger.length() > 0 &&
        (deger.charAt(0) == '{' || deger.charAt(0) == '[')) {
      jsonGecerli = kayit.setJsonData(deger);
    }

    float ppm = NAN;
    double lat = 0;
    double lon = 0;
    uint32_t zaman = 0;

    if (jsonGecerli)
      firebaseKaydiOku(kayit, ppm, lat, lon, zaman);

    // Sadece gerçek ölçüm yapısı olan kayıtları say.
    if (jsonGecerli && isfinite(ppm))
      firebaseToplamKayit++;

    // ============================================================
    // KRİTİK: EŞLEŞME SADECE ID İLE.
    // ============================================================
    int idx = yerelOlcumIndexBul(anahtar);

    if (idx >= 0) {
      bulutIcindeVarMi[idx] = true;
      bulutEslesenSayisi++;

      // Firebase'deki kayıt cihazdaki aynı ID'nin güncel kopyasıdır.
      if (isfinite(ppm))
        yerelOlcumler[idx].ppm = ppm;

      if (lat >= 35.0 && lat <= 43.0 &&
          lon >= 24.0 && lon <= 46.0) {
        yerelOlcumler[idx].lat = lat;
        yerelOlcumler[idx].lon = lon;
      }

      if (zaman != 0)
        yerelOlcumler[idx].zaman = zaman;

      yerelOlcumler[idx].bulutaGonderildi = true;

      Serial.printf("[SYNC] ESLESTI ID: %s\n", anahtar.c_str());
      continue;
    }

    // Firebase'de var, cihazda yok.
    // Hafıza doluysa mevcut cihaz kayıtlarını EVICT ETME!
    // Böylece 9/20 gibi yerel kayıt sayısı senkronizasyon yüzünden
    // kaybolmaz. Boş yer varsa cloud kaydı eklenir.
    if (yerelOlcumSayisi < YEREL_OLCUM_MAX &&
        jsonGecerli && isfinite(ppm)) {

      yerelOlcumEkle(anahtar, ppm, lat, lon, zaman, true);

      int yeniIdx = yerelOlcumIndexBul(anahtar);
      if (yeniIdx >= 0)
        bulutIcindeVarMi[yeniIdx] = true;

      bulutYeniCihazaIndirilen++;

      Serial.printf("[SYNC] FIREBASE -> CIHAZ ID: %s | %.2f ppm\n",
                    anahtar.c_str(), ppm);
    } else if (yerelOlcumSayisi >= YEREL_OLCUM_MAX) {
      Serial.printf("[SYNC] CIHAZ HAFIZASI DOLU, ID ALINMADI: %s\n",
                    anahtar.c_str());
    }
  }

  kok.iteratorEnd();

  Serial.printf(
    "[SYNC] Firebase kayit=%d | Firebase ID=%d | "
    "ID eslesen=%d | Cihaza yeni=%d | Cihaz=%d/%d\n",
    firebaseToplamKayit,
    bulutIDSayisi,
    bulutEslesenSayisi,
    bulutYeniCihazaIndirilen,
    yerelOlcumSayisi,
    YEREL_OLCUM_MAX
  );

  return true;
}

bool firebaseYerelOlcumleriGonder() {
  bool hepsiOK = true;
  int gonderilecek = 0;
  int basarili = 0;

  for (int i = 0; i < yerelOlcumSayisi; i++) {
    YerelOlcum &r = yerelOlcumler[i];

    if (!r.gecerli || r.id.length() == 0)
      continue;

    // SADECE Firebase'de aynı child ID varsa mevcut kabul et.
    if (firebaseIDVarMi(r.id)) {
      r.bulutaGonderildi = true;
      bulutIcindeVarMi[i] = true;

      Serial.printf("[SYNC] BULUTTA ZATEN VAR: %s\n", r.id.c_str());
      continue;
    }

    // Firebase'de bu ID yok -> kesinlikle gönder.
    gonderilecek++;

    FirebaseJson json;
    json.set("id", r.id);
    json.set("ppm", r.ppm);
    json.set("timestamp", (int)r.zaman);
    json.set("device", "NitraCheck");

    if (r.lat >= 35.0 && r.lat <= 43.0 &&
        r.lon >= 24.0 && r.lon <= 46.0) {
      json.set("latitude", r.lat);
      json.set("longitude", r.lon);
    }

    String yol = "/measurements/" + r.id;

    Serial.printf("[SYNC] CIHAZ -> FIREBASE GONDER: %s | %.2f ppm\n",
                  r.id.c_str(), r.ppm);

    if (Firebase.RTDB.setJSON(&fbdo, yol.c_str(), &json)) {
      r.bulutaGonderildi = true;
      bulutIcindeVarMi[i] = true;
      basarili++;
      bulutYeniGonderilen++;

      // Aynı senkronizasyon içinde tekrar gönderilmesini önle.
      if (!firebaseIDVarMi(r.id) && bulutIDSayisi < BULUT_ID_MAKS)
        bulutIDler[bulutIDSayisi++] = r.id;

      Serial.printf("[SYNC] GONDERILDI: %s\n", r.id.c_str());
    } else {
      r.bulutaGonderildi = false;
      hepsiOK = false;

      Serial.printf("[SYNC] GONDERILEMEDI: %s | %s\n",
                    r.id.c_str(), fbdo.errorReason().c_str());
    }
  }

  Serial.printf(
    "[SYNC] Cihaz->Firebase: bekleyen=%d | basarili=%d | "
    "basarisiz=%d\n",
    gonderilecek,
    basarili,
    gonderilecek - basarili
  );

  return hepsiOK;
}

// FIX3 ileri bildirim: bulut işlevi UI çizimi yerine loop() üzerinden yenileme ister.
static volatile bool bulutUIYenilemeIste = false;

static void bulutSenkronizeEtArkaPlanIslem() {
  // BULUTA GÖNDER artık TEK YÖNLÜDÜR:
  // Cihazdaki bekleyen ölçümler -> Firebase.
  // Firebase'deki kayıtlar cihaz RAM/NVS hafızasına çekilmez.
  if (bulutSenkronizasyonu) return;

  bulutSenkronizasyonu = true;
  olcumKilitli = true;
  sonBulutDurumu = "Firebase'e gönderiliyor...";
  bulutUIYenilemeIste = true;

  // WiFi yoksa doğrudan çık.
  if (WiFi.status() != WL_CONNECTED) {
    sonBulutDurumu = "WiFi bagli degil";
    Serial.println("[SYNC] GONDERME IPTAL: WiFi bagli degil.");
    bulutSenkronizasyonu = false;
    olcumKilitli = false;
    bulutUIYenilemeIste = true;
    return;
  }

  // Firebase token daha önce hazır değilse yeniden başlatmayı dene.
  if (!firebaseHazir || !Firebase.ready()) {
    Serial.println("[SYNC] Firebase hazir degil, yeniden baglanti deneniyor...");
    sonBulutDurumu = "Firebase baglantisi yenileniyor...";
    bulutUIYenilemeIste = true;

    Firebase.begin(&fbConfig, &fbAuth);
    Firebase.reconnectWiFi(true);

    unsigned long baslangic = millis();
    while (!Firebase.ready() && millis() - baslangic < 5000UL) {
      vTaskDelay(pdMS_TO_TICKS(100));
    }

    firebaseHazir = Firebase.ready();

    if (!firebaseHazir) {
      sonBulutDurumu = "Firebase baglantisi yok";
      Serial.println("[SYNC] Firebase AUTH HATASI: token hazir degil.");
      Serial.println("[SYNC] API key, database URL, e-posta/sifre ve RTDB Rules kontrol edilmeli.");
      bulutSenkronizasyonu = false;
      olcumKilitli = false;
      bulutUIYenilemeIste = true;
      return;
    }
  }

  Serial.println("========== FIREBASE SADECE GONDER ==========");

  bulutYeniGonderilen = 0;
  firebaseToplamKayit = 0;

  // DİKKAT:
  // firebaseBulutKayitlariniHafizayaAl() BİLEREK ÇAĞRILMIYOR.
  // Böylece buluttaki eski/yeni kayıtlar cihaz hafızasına indirilmez.
  //
  // Yerel RAM/NVS yalnızca cihazın kendi ölçümlerini bekleyen gönderim
  // kuyruğu olarak kullanılır.
  bool okGonder = firebaseYerelOlcumleriGonder();

  // Sadece cihazdaki "buluta gönderildi" bayraklarını kalıcılaştır.
  // Firebase'den cihaz hafızasına hiçbir kayıt yazılmaz.
  yerelOlcumKaydet();

  int gonderilmemis = 0;
  for (int i = 0; i < yerelOlcumSayisi; i++) {
    if (yerelOlcumler[i].gecerli &&
        !yerelOlcumler[i].bulutaGonderildi) {
      gonderilmemis++;
    }
  }

  if (gonderilmemis == 0 && okGonder) {
    sonBulutDurumu = "Buluta gonderme tamamlandi";
  } else if (gonderilmemis > 0) {
    sonBulutDurumu =
      String(gonderilmemis) + " kayit gonderilemedi";
  } else {
    sonBulutDurumu = "Gonderme tamamlandi";
  }

  Serial.printf(
    "[SYNC] BITTI -> Cihaz=%d/%d | YeniCloud=%d | Bekleyen=%d\n",
    yerelOlcumSayisi,
    YEREL_OLCUM_MAX,
    bulutYeniGonderilen,
    gonderilmemis
  );
  Serial.println("============================================");

  bulutSenkronizasyonu = false;
  olcumKilitli = false;
  bulutUIYenilemeIste = true;
}

// 35.0 sadece ilk acilista 'olcum yapilmadi' placeholder'idir.
// Gercek AS7341/NDSC sonucu basarili olcumden sonra bu degiskene yazilir.
float uiLastNitrate = 0.0f;
bool uiHasMeasurement = false;

// ================================================================
// NDSC-8 ÖLÇÜM HESAPLAMASI — cokdil.ino kaynağından BİREBİR alındı.
// LED sırası, bekleme süreleri, medyan/absorbans/regresyon formülleri
// DEĞİŞTİRİLMEDİ. Sadece LED pinleri (yukarıda) ve bu dosyada olmayan
// web sunucusuna handleClient() çağrısı (yield() ile) uyarlandı.
// ================================================================
uint16_t kanalDegerleri[12];

#define NDSC_KANAL 8

// Son başarılı ölçümün gerçek AS7341 F1-F8 kanal değerleri.
// Tek ışık kaynağı (PCF8574 harici yesil/kirmizi LED) ile alınır; grafik
// artık sahte matematiksel dalga kullanmaz.
float sonSpektrumBeyaz[NDSC_KANAL] = {0};
bool sonSpektrumHazir = false;

// ADIM16: Ölçüm sonucu RAM'e hemen eklenir. NVS yazımı, ana ekran
// çizildikten sonra bloklamayan bir zamanlayıcı ile tek sefer yapılır.
bool pendingLocalSave = false;
unsigned long pendingLocalSaveAt = 0;

#define NDSC_ORNEK 20
#define NDSC_EPS   1.0f
#define NDSC_SHAPE_BETA 0.10f     // Önceden belirlenmiş spektral şekil katsayısı
#define NDSC_SAT_ESIK 65000u      // AS7341 16-bit sayimda doyuma yaklasma esigi
#define NDSC_MIN_GECERLI_ORAN 0.6f  // istenen ornek sayisinin en az %60'i gecerli olmali
// KAL-FIX: CV ve "en kotu tekil sapma" hesaplarinda kanalin ISE YARAR
// (gurultu tabaninin belirgin uzerinde) sayilmasi icin gereken minimum
// ham sayim. Eskiden bu esik 1.0f idi; 16-bit bir sensorde 1-3 sayimlik
// kanallarda +-1 sayimlik normal donanim gurultusu bile ORANSAL olarak
// %50-100 "sapma" gibi gorunuyor, bu da guven skorunu (tekrarCarpani)
// her seferinde 0'a cakiyordu (spk/sat/uyum iyi olsa bile). 50 sayim,
// AS7341 icin makul bir gurultu tabani -- gercek optik degisikligi hala
// yakalar ama tekil-sayim kuantalama gurultusunu guven skorundan disarida
// birakir.
#define NDSC_KANAL_GURULTU_TABANI 50.0f
#define NDSC_GUVENLI_ESIK 25.0f   // UI: 0-25 guvenli
#define NDSC_DIKKAT_ESIK 50.0f    // UI: 25-50 dikkat, >50 tehlikeli

// ── GÜVEN SKORU (Ölçüm Güveni) AĞIRLIKLARI ──
// PPM hesaplamasını (sonNDSCScore / hesaplaPPM) HİÇ ETKİLEMEZ; sadece
// ndscIkiRenkSkor() içindeki "kalite" (sonOptikKalite) çıktısını besler.
// Bu eşikler saha verisi (bilinen standart numunelerle tekrar tekrar
// ölçüm) ile ayarlanmalı; şu an mühendislik tahminidir.
#define NDSC_AGIRLIK_UYUM     0.10f  // yeşil-skoru ile kırmızı-skorunun birbirine yakınlığı
#define NDSC_AGIRLIK_SPEKTRAL 0.60f  // mevcut ndscSpectralScore() içindeki kanal/greenBand cezası (baskın bileşen)
#define NDSC_AGIRLIK_SATURASYON 0.15f // doygunluğa yaklaşan örneklerin oranı
#define NDSC_CV_KOTU_ESIK   0.25f   // ortalama varyasyon katsayısı >=%25 -> tekrar "bozulma göstergesi" 1.0 (GEÇİCİ/geniş tutuldu, saha verisiyle daraltılacak)
#define NDSC_UYUM_KOTU_ESIK 2.5f   // yeşil/kırmızı skor farkı, bu degere ulasinca -> uyum puani 0
                                     // (07.09.2026 saha verisiyle guncellendi: kalibrasyon skor araligi
                                     // henuz tam kalibre edilmediginden (5..300 ppm noktalari eksik)
                                     // "payda" NDSC_EPS'e (1.0) dusuyor ve gercek/gecerli olcumlerde bile
                                     // fark 0.44-1.80 araliginda cikabiliyor; eski esik (0.40) bunlarin
                                     // TAMAMINI haksiz yere uyum=0'a cakip KALITE'yi ~88'e sabitliyordu.
                                     // Daha comert yeni esikte gecerli olcumler (fark<~1.0) kismi/yuksek
                                     // uyum puani alir, gercekten kotu bir olcum (fark>2.5) hala 0'a duser.
                                     // Tam kalibrasyon tamamlanip kal_ScoreMax-kal_ScoreMin gercek bir
                                     // araliga oturunca bu esik saha verisiyle tekrar daraltilmali.
#define NDSC_MAXSAPMA_KOTU_ESIK 0.30f // TEK bir örneğin medyandan >=%30 sapması -> tekrar "bozulma göstergesi" 1.0
                                       // (numune çekmecesi ölçüm sırasında açılırsa bu tetiklenir; ortalama
                                       // CV'den bağımsız çalışır çünkü tek kötü örneği bile yakalar)
#define NDSC_TEKRAR_USTEL 3.0f        // tekrar çarpanının küp eğrisi: küçük gürültüde skora dokunmaz,
                                       // ama bozulma göstergesi 1'e yaklaştıkça sert şekilde çöker

// ndscIkiRenkOlc() içinde doldurulur, ndscIkiRenkSkor() içinde okunur.
float g_ndscCVOrtalama = 0.0f;       // yeşil+kırmızı ortalama varyasyon katsayısı
float g_ndscSatOraniOrtalama = 0.0f; // yeşil+kırmızı ortalama doygunluk oranı (0-1)
float g_ndscMaxSapmaOrtalama = 0.0f; // yeşil+kırmızı en kötü TEKİL örnek sapması (ör. numune çekmecesi
                                      // ölçüm ORTASINDA açılırsa sadece birkaç örnek bozulur; ORTALAMA
                                      // varyasyon (CV) bunu sulandırır, bu metrik sulandırmaz).

const float NDSC_LAMBDA[NDSC_KANAL] = {415,445,480,515,555,590,630,680};

float blankBeyaz[NDSC_KANAL] = {0};
float darkSpectrum[NDSC_KANAL] = {0};
bool ndscBlankHazir = false;

float sonAbsBeyaz[NDSC_KANAL] = {0};
float sonNDSCScore = 0.0f;
float sonOptikKalite = 0.0f;
float sonucPPM = 0.0f;
String durumMetin = "";

// index 0 = BLANK (0 ppm), index 1..10 = 10 standart ölçüm noktası.
#define KAL_NOKTA_SAYISI 11
struct KalPt { float score; float hedefPPM; bool aktif; };
KalPt kalPts[KAL_NOKTA_SAYISI] = {
  {0, 0,   true},
  {0, 5,   false},
  {0, 10,  false},
  {0, 25,  false},
  {0, 50,  false},
  {0, 75,  false},
  {0, 100, false},
  {0, 150, false},
  {0, 200, false},
  {0, 250, false},
  {0, 300, false}
};

// ─── Kalibrasyon ekranı şifre koruması ─────────────────────────
// Not: Şifre kaynak koda gömülü olduğu için gerçek bir güvenlik
// önlemi değildir, sadece kalibrasyonun kazara/yetkisiz dokunuşla
// bozulmasını engeller.
// ─── TEST KALİBRASYONU (KUTU/LED YOKKEN AKIŞI DOĞRULAMAK İÇİN) ──
// Fiziksel kutu/LED donanımı henüz takılı değilken PPM hesaplama,
// "Kalibrasyon: GEÇERLİ" durumu ve ölçüm ekranının uçtan uca çalışıp
// çalışmadığını görmek için sahte (fakat kod yolunu gerçekten
// çalıştıran) bir kalibrasyon verisi enjekte eder.
// NOT: Buradaki PPM sayıları GERÇEK DEĞİLDİR, sadece akış testi içindir.
// Gerçek kutu/LED'ler bağlanınca KALİBRASYON ekranından normal şekilde
// "BLANK ÖLÇ" + standartları ölçmen yeterli: ndscBlankOlc() bu test
// verisinin tamamını otomatik sıfırlar, ayrıca güvenlik için bu
// tanımı 0 yapabilirsin.
#define TEST_KALIBRASYON_AKTIF 0

#define KALIBRASYON_SIFRE "12345"
#define KALIBRASYON_SIFRE_UZUNLUK 5
String kalibrasyonSifreGirisi = "";
bool   kalibrasyonSifreHatali = false;

// PPM = kal_b * NDSC_score + kal_d
float kal_b = 0.08f;
float kal_d = 0.0f;
float kal_blank_f5 = 0.0f;

float kal_R2   = -1.0f;
float kal_RMSE = -1.0f;
float kal_MAE  = -1.0f;
float kal_Bias = 0.0f;
float kal_ScoreMin = 0.0f;
float kal_ScoreMax = 0.0f;
int   kal_n    = 0;
bool  kalibrasyonGecerli = false;
// KAL-FIX-UYUM: blank tupteki yesil/kirmizi LED'in KENDI (duzeltilmemis)
// skorlari. ndscIkiRenkSkor() icindeki "uyum" (agreement) kontrolu, bu iki
// deger cikartilarak s1/s2'nin kendi bazlarina gore SAPMASINI karsilastirir
// -- boylece ortak (ortalama) blank referansindan kaynaklanan sabit
// yesil/kirmizi ofseti "uyumsuzluk" sanilmaz.
float kal_s1Blank = 0.0f;
float kal_s2Blank = 0.0f;

// ─── ADIM17: KALİBRASYON YEDEĞİ + MANUEL GERİ YÜKLEME ─────────────
// Kalibrasyon ayrı bir NVS namespace'inde TEK BLOB olarak saklanır.
// Böylece program güncellense bile NVS silinmediği sürece kalibrasyon
// otomatik geri gelir. Flash/NVS tamamen silinirse aynı değerler ekrandan
// DARK + BLANK + 5..300 ppm skorları olarak manuel girilebilir.
#define KAL_BLOB_MAGIC   0x4E434B31UL   // "NCK1"
#define KAL_BLOB_VERSION 6               // v2: cift kopya + generation sayaci (guc kesintisine karsi)
                                          // v3: hedefPPM[] eklendi (KAL-DUZELTME, bkz. struct tanimi)
                                          // v4: s1Blank/s2Blank eklendi (KAL-FIX-UYUM, bkz. struct tanimi)
                                          // v5: kirmizi skoru 630nm Gaussian banda gecti (KAL-FIX-KIRMIZI-BANT)
                                          // v6: kirmizi artik SADECE F7 (tek kanal, komsu bantlar kapali) --
                                          //     KAL-FIX-KIRMIZI-TEK-KANAL. s2'nin ÖLÇEĞİ yine degisti, eski
                                          //     (v5) kalibrasyon verileri ARTIK GECERSIZ. TAM YENIDEN
                                          //     KALIBRASYON (DARK+BLANK+tum ppm noktalari) sarttir.
// NOT: KalibrasyonBlob struct'i artik dosyanin basinda tanimli (bkz. FIX5).

bool kalibrasyonYedektenYuklendi = false;
// Ekranda gösterilecek NVS tanı bilgisi (Serial güvenilmezse diye).
uint32_t kalTaniGen = 0;
char kalTaniSlot[8] = "-";
bool kalTaniBlobABuldu = false;
bool kalTaniBlobBBuldu = false;

// ─── EKRAN ÜZERİ KALİBRASYON LOG PANELİ (Serial güvenilir değilse) ─────
// Serial USB her zaman bağlı/izlenebilir olmuyor. Kalibrasyonla ilgili
// tüm [KAL-NVS]/[Kal-NDSC8]/[BLANK]/[MANUEL-KAL] mesajları artık HEM
// Serial'e HEM de bu küçük dairesel arabelleğe yazılıyor; arabellek
// kalLogEkraniGoster() ile tam ekran olarak okunabiliyor (dokununca kapanır).
#define KAL_LOG_SATIR 12
#define KAL_LOG_UZUNLUK 100
char kalLogSatirlari[KAL_LOG_SATIR][KAL_LOG_UZUNLUK];
int  kalLogDoluSayisi = 0;

void kalLog(const char *fmt, ...) {
  char buf[KAL_LOG_UZUNLUK];
  va_list args;
  va_start(args, fmt);
  vsnprintf(buf, sizeof(buf), fmt, args);
  va_end(args);

  Serial.println(buf);  // Serial calisiyorsa hala orada da gorunur.

  // Dairesel arabellek: en eski satır yukarı kayar, yeni satır en alta eklenir.
  for (int i = 0; i < KAL_LOG_SATIR - 1; i++) {
    strncpy(kalLogSatirlari[i], kalLogSatirlari[i + 1], KAL_LOG_UZUNLUK);
  }
  strncpy(kalLogSatirlari[KAL_LOG_SATIR - 1], buf, KAL_LOG_UZUNLUK - 1);
  kalLogSatirlari[KAL_LOG_SATIR - 1][KAL_LOG_UZUNLUK - 1] = '\0';
  if (kalLogDoluSayisi < KAL_LOG_SATIR) kalLogDoluSayisi++;
}

// (kalLogEkraniGoster() burada değil, drawLeftText/renk/font tanımlarından
// SONRA tanımlı -- bkz. aşağıda "EKRAN ÜZERİ KALİBRASYON LOG EKRANI" bölümü.
// Fonksiyon display/FONT_SMALL/UI_* sembollerini kullandığı için onlardan
// önce tanımlanırsa "declared in this scope değil" derleme hatası verir.)

// Manuel giriş: 4 sayfa
// 0 = DARK F1..F8, 1 = BLANK F1..F8,
// 2 = 5..75 ppm, 3 = 100..300 ppm
int manualKalPage = 0;
int manualKalSelected = -1;
String manualKalInput[26]; // 8 DARK + 8 BLANK + 10 standart score

// ─── NUMUNE İLE KALİBRASYON ────────────────────────────────────────
// Sabit 5/10/25/50/75/100/150/200/250/300 ppm standartları yerine,
// elde bulunan BİLİNEN DEĞERLİ bir numuneyi ölçüp o değeri (ör. 113.2
// ppm) klavyeden girerek kalibrasyon yapmayı sağlar. "BLANK ÖLÇ" zaten
// ndscBlankOlc() içinde tüm eski noktaları sıfırladığı için, bu ekranda
// da kalibrasyon her zaman BLANK ile "sıfırdan" başlar. Blank dahil en
// az 3 ölçüm (blank + 2 numune) kalibrasyonu GEÇERLİ yapar; kalPts[1..10]
// dolu olduğu için en fazla 10 numune girilebilir.
#define NUMUNE_KAL_MAX_ADET (KAL_NOKTA_SAYISI - 1)  // 10
int    numuneKalAdim = 0;          // 0 = liste/ölçüm ekranı, 1 = değer giriş (klavye) ekranı
int    numuneKalBekleyenIdx = -1;  // ölçüldü ama ppm'i henüz girilmemiş kalPts indeksi
String numuneKalGirisMetni = "";   // klavye ile girilen ppm metni
String numuneKalHataMetni = "";    // ekranda gösterilecek son hata/uyarı mesajı

// ---------- Renk paleti ----------
constexpr uint16_t rgb565(uint8_t r, uint8_t g, uint8_t b) {
  return (uint16_t)(((r & 0xF8) << 8) |
                    ((g & 0xFC) << 3) |
                    (b >> 3));
}

uint16_t UI_BG       = rgb565(8, 16, 35);    // koyu lacivert ana zemin
uint16_t UI_HEADER   = rgb565(12, 24, 48);   // koyu lacivert üst bar
uint16_t UI_PANEL    = rgb565(16, 30, 58);
uint16_t UI_PANEL2   = rgb565(10, 21, 43);
uint16_t UI_PANEL3   = rgb565(24, 42, 76);
uint16_t UI_CYAN     = rgb565(35, 85, 180);  // istek üzerine lacivert/koyu mavi (eski: 0,175,210)
const uint16_t UI_WHITE    = rgb565(245, 249, 255);
const uint16_t UI_MUTED    = rgb565(184, 188, 196);
const uint16_t UI_GREEN    = rgb565(72, 224, 112);
const uint16_t UI_BLUE     = rgb565(70, 145, 255);
uint16_t UI_ORANGE   = rgb565(255, 184, 52);
const uint16_t UI_RED      = rgb565(255, 82, 92);
const uint16_t UI_YELLOW   = rgb565(255, 215, 0);
const uint16_t UI_PINK     = rgb565(255, 105, 180);
const uint16_t UI_LINE     = rgb565(78, 84, 94);

// Harita noktası renk sınıflandırması: renk sabitleri tanımlandıktan sonra.
uint16_t haritaNoktaRengi(float ppm) {
  // Mavi yalnızca nitrat değeri gerçekten bulunamayan kayıtlar içindir.
  if (!isfinite(ppm)) return UI_BLUE;
  if (ppm <= HARITA_NORMAL_MAX_PPM) return UI_GREEN;
  if (ppm <= HARITA_YUKSEK_MAX_PPM) return UI_YELLOW;
  return UI_RED;
}

// ---------- Font helpers ----------
// ONEMLI: LovyanGFX'in yerlesik fonts::DejaVu18/24/40 fontlari SADECE
// ASCII (0x20-0x7E) karakterlerini icerir; Ü, Ç, Ö, İ, Ş, Ğ, ı, ş, ğ gibi
// Turkce karakterler bu fontlarda YOKTUR ve ekranda bos kutu olarak
// gorunur. Bunun yerine, ayni DejaVu Sans yazi tipinden turetilmis ve
// Turkce karakterleri de iceren TRFont18/24/40 (bkz. TRFont*.h) kullanilir.
// Harici SD / LittleFS gerekmez, dosyalar sketch icine gomulu PROGMEM
// veri olarak derlenir.
const lgfx::v1::IFont* FONT_SMALL  = &TRFont18;
const lgfx::v1::IFont* FONT_MEDIUM = &TRFont24;
const lgfx::v1::IFont* FONT_BIG    = &TRFont40;

void fontSmall() {
  display.setFont(FONT_SMALL);
  display.setTextSize(1);
}

void fontButton() {
  display.setFont(FONT_MEDIUM);
  display.setTextSize(1);
}

void fontBig() {
  display.setFont(FONT_BIG);
  display.setTextSize(1);
}

void drawCenteredText(const char* text, int x, int y,
                      const lgfx::v1::IFont* font,
                      uint16_t color, uint16_t bg = UI_PANEL) {
  display.setFont(font);
  display.setTextSize(1);
  display.setTextColor(color, bg);
  display.setTextDatum(textdatum_t::top_center);
  display.drawString(text, x, y);
  display.setTextDatum(textdatum_t::top_left);
}

void drawLeftText(const char* text, int x, int y,
                  const lgfx::v1::IFont* font,
                  uint16_t color, uint16_t bg = UI_PANEL) {
  display.setFont(font);
  display.setTextSize(1);
  display.setTextColor(color, bg);
  display.setTextDatum(textdatum_t::top_left);
  display.drawString(text, x, y);
}

// ─── EKRAN ÜZERİ KALİBRASYON LOG EKRANI ────────────────────────────
// kalLog() (yukarıda tanımlı) mesajları bir dairesel arabelleğe topluyor;
// bu fonksiyon o arabelleği tam ekran gösterir. FONT_SMALL/FONT_MEDIUM/
// UI_*/drawLeftText/display'e bağlı olduğu için BUNLARDAN SONRA
// tanımlanmalı (bkz. dosyanın başındaki kalLog() yorumu).
void kalLogEkraniGoster() {
  setBacklight(255);
  display.setFont(FONT_SMALL);
  display.setTextSize(1);
  display.fillScreen(UI_BG);
  drawLeftText("KALIBRASYON LOG", 20, 14, FONT_MEDIUM, UI_WHITE, UI_BG);

  int y = 50;
  int basSira = (kalLogDoluSayisi < KAL_LOG_SATIR) ? (KAL_LOG_SATIR - kalLogDoluSayisi) : 0;
  for (int i = basSira; i < KAL_LOG_SATIR; i++) {
    drawLeftText(kalLogSatirlari[i], 20, y, FONT_SMALL, UI_WHITE, UI_BG);
    y += 24;
  }
  if (kalLogDoluSayisi == 0) {
    drawLeftText("(henuz log yok)", 20, y, FONT_SMALL, UI_MUTED, UI_BG);
  }
  drawLeftText("(devam etmek icin ekrana dokun)", 20, 460, FONT_SMALL, UI_MUTED, UI_BG);

  // BULUNAN HATA: "LOG" butonuna basarken parmak ekrandan henüz
  // KALKMADAN bu fonksiyon çağrılıyordu; aşağıdaki bekleme döngüsü
  // parmağın kalkmasını beklemeden direkt dokunma kontrolüne
  // başladığı için, LOG butonuna basan AYNI dokunuş "kapatma
  // dokunuşu" sayılıp ekran anında kapanıyordu (açılır gibi olup
  // hemen kapanma şikayetinin sebebi buydu). Önce parmağın
  // gerçekten kalktığından emin olunuyor, ardından yeni bir
  // dokunuş bekleniyor.
  int32_t txBirak, tyBirak;
  unsigned long birakBaslangic = millis();
  while (display.getTouch(&txBirak, &tyBirak) && millis() - birakBaslangic < 2000) {
    delay(10);
  }

  unsigned long baslangic = millis();
  int32_t tx, ty;
  while (millis() - baslangic < 20000) {
    if (display.getTouch(&tx, &ty)) break;
    delay(20);
  }
}

// Sadece kücük slider alanını yeniden çizer (tüm Ayarlar sayfasını
// değil) — sürükleme sırasında akıcı kalması için.
void drawBrightnessSlider() {
  int trackX = BRIGHT_TRACK_X, trackY = BRIGHT_TRACK_Y;
  int trackW = BRIGHT_TRACK_W, trackH = BRIGHT_TRACK_H;

  // Etiket + üstündeki alan dahil bölgeyi panel rengiyle temizle.
  display.fillRoundRect(trackX - 8, trackY - 30, trackW + 16, trackH + 46, 10, UI_PANEL);

  int percent = (int)(((long)uiBacklightLevel * 100L) / 255L);
  char lbl[24];
  snprintf(lbl, sizeof(lbl), "PARLAKLIK  %%%d", percent);
  drawLeftText(lbl, trackX, trackY - 24, FONT_SMALL, UI_WHITE, UI_PANEL);

  // Kanal (track).
  display.fillRoundRect(trackX, trackY, trackW, trackH, trackH / 2, UI_PANEL2);
  display.drawRoundRect(trackX, trackY, trackW, trackH, trackH / 2, UI_LINE);

  // Dolu kısım.
  int fillW = (int)(((long)trackW * uiBacklightLevel) / 255L);
  if (fillW < trackH) fillW = trackH;
  if (fillW > trackW) fillW = trackW;
  display.fillRoundRect(trackX, trackY, fillW, trackH, trackH / 2, UI_CYAN);

  // Sürgü topuzu (handle).
  int handleCx = trackX + fillW - trackH / 2;
  if (handleCx < trackX + trackH / 2) handleCx = trackX + trackH / 2;
  if (handleCx > trackX + trackW - trackH / 2) handleCx = trackX + trackW - trackH / 2;
  int handleCy = trackY + trackH / 2;
  display.fillCircle(handleCx, handleCy, trackH / 2 + 5, UI_WHITE);
  display.fillCircle(handleCx, handleCy, trackH / 2 + 1, UI_CYAN);
}

// Sürükleme sırasında her karede çağrılır (loop() içinden). Slider
// alanının dışındaki dokunuşları yok sayar. I2C'yi gereksiz yere
// spam'lememek için art arda gelen çağrılarda küçük bir zaman
// aralığı (throttle) uygulanır.
void uiHandleBrightnessSliderDrag(int32_t tx, int32_t ty) {
  if (currentScreen != SCREEN_DISPLAY_SETTINGS) return;

  // Dikeyde biraz tolerans: parmak tam kanalın üstünde olmasa bile
  // yakalasın.
  if (ty < BRIGHT_TRACK_Y - 16 || ty > BRIGHT_TRACK_Y + BRIGHT_TRACK_H + 16) return;
  if (tx < BRIGHT_TRACK_X - 10 || tx > BRIGHT_TRACK_X + BRIGHT_TRACK_W + 10) return;

  int rel = (int)tx - BRIGHT_TRACK_X;
  if (rel < 0) rel = 0;
  if (rel > BRIGHT_TRACK_W) rel = BRIGHT_TRACK_W;

  int level = (int)(((long)rel * 255L) / BRIGHT_TRACK_W);
  if (level < 0) level = 0;
  if (level > 255) level = 255;

  static unsigned long sonUygulamaMs = 0;
  if ((uint8_t)level != uiBacklightLevel && millis() - sonUygulamaMs >= 30) {
    sonUygulamaMs = millis();
    setBacklight((uint8_t)level);
    drawBrightnessSlider();
    parlaklikKaydiBekliyor = true;
  }
}

// Öne çıkan sayısal SONUÇ değeri için: normal FONT_BIG'den daha büyük
// (ölçek parametresiyle) ve kalın görünümlü metin. TRFont40 gömülü
// bitmap font ailesinin ayrı bir "bold" varyantı yok; bu yüzden kalınlık,
// aynı glifin merkez etrafında birkaç piksel kaydırılarak (faux-bold)
// üst üste çizilmesiyle elde ediliyor. İlk çizim arka planı opak
// doldurur, geri kalanı şeffaf modda üstüne binerek sadece gövdeyi
// kalınlaştırır (arka planı tekrar tekrar doldurup titremeye yol açmaz).
void drawCenteredValueBold(const char* text, int x, int y,
                           const lgfx::v1::IFont* font,
                           uint16_t color, uint16_t bg = UI_PANEL,
                           float scale = 1.18f) {
  display.setFont(font);
  display.setTextSize(scale);
  display.setTextDatum(textdatum_t::top_center);

  display.setTextColor(color, bg);
  display.drawString(text, x, y);

  display.setTextColor(color);
  display.drawString(text, x - 1, y);
  display.drawString(text, x + 1, y);
  display.drawString(text, x, y - 1);
  display.drawString(text, x, y + 1);

  display.setTextSize(1);
  display.setTextDatum(textdatum_t::top_left);
}

void drawStatusDot(int x, int y, uint16_t color) {
  display.fillCircle(x, y, 5, color);
  display.drawCircle(x, y, 8, color);
}

// ─── BAŞLIK ROZETİ: EKRAN İKONU ───────────────────────────────────
// ÖLÇÜM / HARİTA / BULUT / AYARLAR ... başlıklarının üstündeki alan
// artık 3 renkli dönen çember DEĞİL; doğrudan o ekrana ait dairesel
// ikonu büyük boyutta gösteren sade bir rozet.
const int HB_BADGE_CX = 400;
const int HB_BADGE_CY = 34;
// İSTEK ÜZERİNE: çember/daire kavramı tamamen kaldırıldı. Rozet artık
// dikdörtgen bir alan; ikon bu dikdörtgene sığdırılıyor (en-boy oranı
// bozulmadan). HB_BADGE_W/H, rozetin görünmez "temizlenen" alanının
// boyutudur -- ikon bunun biraz içinde, kenarlarda pay bırakarak çizilir.
// YENİ İKON SETİ: kaynak ikonlar tam 166x70px (en-boy oranı ~2.37) ve
// kendi rozet/kapsül görünümünü (kenarlık, parlaklık, başlık yazısı)
// PNG'nin içinde zaten barındırıyor. Bu yüzden HB_BADGE_W/H artık bu
// orana yakın seçildi; ikon neredeyse kutunun tamamını dolduracak.
const int HB_BADGE_W  = 180;  // rozet alanı genişliği (dikdörtgen, ~166+pay)
const int HB_BADGE_H  = 76;   // rozet alanı yüksekliği (dikdörtgen, ~70+pay)

// ─── BAŞLIK ROZETİ İKONU: her ekranın kendi ikonu ─────────────────
// İSTEK ÜZERİNE: rozetin ortasındaki yazı (ÖLÇÜM/HARİTA/BULUT/...)
// kaldırıldı; yerine o ekrana ait dairesel ikon (ScreenIcons.h) çizilir.
// NOT: HeaderBadgeIcon struct'ı artık dosyanın en başında tanımlı
// (bkz. FIX4) — Arduino'nun otomatik ürettiği fonksiyon prototipleri
// bu noktadan önce geldiği için struct burada DEĞİL, en başta olmalı.// title stringine göre uygun ikonu döndürür; eşleşme yoksa nullptr
// döner (bu durumda çağıran taraf eski metin tabanlı çizime düşer).
static const HeaderBadgeIcon* headerBadgeIconForTitle(const char* title) {
  // YENİ (166x70) ikon seti: her ikonun başlığı (ÖLÇÜM/HARİTA/...) artık
  // PNG'nin İÇİNE gömülü geliyor -- bu yüzden aşağıda drawHeaderTitleBadgeFrame()
  // içindeki ayrı metin çizim/mask kodu kaldırıldı (bkz. o fonksiyon).
  static const HeaderBadgeIcon ICON_TABLE[] = {
    { ICON_OLCUM_V2_PNG,               ICON_OLCUM_V2_PNG_LEN,               ICON_OLCUM_V2_W,               ICON_OLCUM_V2_H },
    { ICON_HARITA_V2_PNG,              ICON_HARITA_V2_PNG_LEN,              ICON_HARITA_V2_W,              ICON_HARITA_V2_H },
    { ICON_BULUT_V2_PNG,               ICON_BULUT_V2_PNG_LEN,               ICON_BULUT_V2_W,               ICON_BULUT_V2_H },
    { ICON_AYARLAR_V2_PNG,             ICON_AYARLAR_V2_PNG_LEN,             ICON_AYARLAR_V2_W,             ICON_AYARLAR_V2_H },
    { ICON_WIFI_V2_PNG,                ICON_WIFI_V2_PNG_LEN,                ICON_WIFI_V2_W,                ICON_WIFI_V2_H },
    { ICON_KALIBRASYON_V2_PNG,         ICON_KALIBRASYON_V2_PNG_LEN,         ICON_KALIBRASYON_V2_W,         ICON_KALIBRASYON_V2_H },
    { ICON_KALIBRASYON_SIFRESI_V2_PNG, ICON_KALIBRASYON_SIFRESI_V2_PNG_LEN, ICON_KALIBRASYON_SIFRESI_V2_W, ICON_KALIBRASYON_SIFRESI_V2_H },
    { ICON_MANUEL_KALIBRASYON_V2_PNG,  ICON_MANUEL_KALIBRASYON_V2_PNG_LEN,  ICON_MANUEL_KALIBRASYON_V2_W,  ICON_MANUEL_KALIBRASYON_V2_H },
    { ICON_GPS_V2_PNG,                 ICON_GPS_V2_PNG_LEN,                 ICON_GPS_V2_W,                 ICON_GPS_V2_H },
    { ICON_DURUM_V2_PNG,               ICON_DURUM_V2_PNG_LEN,               ICON_DURUM_V2_W,               ICON_DURUM_V2_H },
    { ICON_TAKIM_V2_PNG,               ICON_TAKIM_V2_PNG_LEN,               ICON_TAKIM_V2_W,               ICON_TAKIM_V2_H },
    { ICON_EKRAN_V2_PNG,               ICON_EKRAN_V2_PNG_LEN,               ICON_EKRAN_V2_W,               ICON_EKRAN_V2_H },
  };

  if (strcmp(title, "ÖLÇÜM") == 0)                    return &ICON_TABLE[0];
  if (strcmp(title, "HARİTA") == 0)                   return &ICON_TABLE[1];
  if (strcmp(title, "BULUT") == 0)                    return &ICON_TABLE[2];
  if (strcmp(title, "AYARLAR") == 0)                  return &ICON_TABLE[3];
  if (strncmp(title, "WİFİ", 6) == 0)                 return &ICON_TABLE[4]; // WİFİ AĞLARI / BAĞLANTISI / ŞİFRESİ
  if (strcmp(title, "KALİBRASYON ŞİFRESİ") == 0)      return &ICON_TABLE[6];
  if (strcmp(title, "MANUEL KALİBRASYON") == 0)       return &ICON_TABLE[7];
  if (strcmp(title, "KALİBRASYON") == 0)              return &ICON_TABLE[5];
  if (strcmp(title, "GPS") == 0)                      return &ICON_TABLE[8];
  if (strcmp(title, "DURUM") == 0)                    return &ICON_TABLE[9];
  if (strcmp(title, "TAKIM") == 0)                    return &ICON_TABLE[10];
  if (strcmp(title, "EKRAN") == 0)                    return &ICON_TABLE[11];
  return nullptr;
}

void drawHeaderTitleBadgeFrame(const char* title) {
  // İSTEK ÜZERİNE: 3 renkli dönen halka VE çember/daire mantığı tamamen
  // kaldırıldı. Rozet artık sade dikdörtgen bir alan; ortasında sadece o
  // ekranın (artık dikdörtgen tasarlanan) ikonu, en-boy oranı korunarak
  // alana sığdığı kadar BÜYÜK gösteriliyor.
  const uint16_t titleColor = UI_WHITE; // yalnızca aşağıdaki metin yedeği için

  // Rozet alanını (eski halka/metin kalıntıları dahil) temizle.
  const int badgeClearX = HB_BADGE_CX - HB_BADGE_W / 2;
  const int badgeClearY = HB_BADGE_CY - HB_BADGE_H / 2;
  const int badgeClearW = HB_BADGE_W;
  const int badgeClearH = HB_BADGE_H;
  display.fillRect(badgeClearX, badgeClearY, badgeClearW, badgeClearH, UI_HEADER);

  // İSTEK ÜZERİNE: rozetin ortasındaki metin (ÖLÇÜM/HARİTA/BULUT/...)
  // tamamen kaldırıldı; onun yerine o ekrana ait dikdörtgen ikon çizilir.
  // Ekran GERÇEKTEN değiştiğinde (önceki çağrıdaki başlıktan farklıysa)
  // ikon, küçükten büyüğe doğru kısa bir "büyüyerek beliren" (pop-in)
  // animasyonla sahneye girer; başlık DEĞİŞMEDİYSE ikon sabit kalır.
  const HeaderBadgeIcon* icon = headerBadgeIconForTitle(title);

  // Rozet alanının kenarlarında pay bırakmak için ikon, HB_BADGE_W/H'nin
  // %94'ü kadar bir kutuya, EN-BOY ORANI KORUNARAK sığdırılır (dikdörtgen
  // ikonlar bu sayede yamulmadan, olduğu oranda büyür/küçülür). Yeni ikon
  // seti zaten kendi kapsül/kenarlık tasarımını içerdiği için oran yüksek
  // tutuldu -- eskisi gibi ekstra büyük boşluk bırakmaya gerek yok.
  const float FIT_RATIO = 0.94f;
  const int iconMaxW = (int)(HB_BADGE_W * FIT_RATIO);
  const int iconMaxH = (int)(HB_BADGE_H * FIT_RATIO);

  static char sonRozetBasligi[32] = "";
  bool baslikDegisti = (strcmp(sonRozetBasligi, title) != 0);
  if (baslikDegisti) {
    strncpy(sonRozetBasligi, title, sizeof(sonRozetBasligi) - 1);
    sonRozetBasligi[sizeof(sonRozetBasligi) - 1] = '\0';
  }

  if (icon != nullptr) {
    // İkonun kendi en-boy oranını koruyarak iconMaxW x iconMaxH kutusuna
    // sığdıran ortak ölçek: hangi boyut daha kısıtlayıcıysa o kullanılır.
    float sclFitW = (float)iconMaxW / (float)icon->w;
    float sclFitH = (float)iconMaxH / (float)icon->h;
    float sclFit = (sclFitW < sclFitH) ? sclFitW : sclFitH;
    int finalW = (int)(icon->w * sclFit);
    int finalH = (int)(icon->h * sclFit);

    if (baslikDegisti) {
      // Büyüyerek beliren (pop-in) geçiş animasyonu -- yalnızca ekran
      // gerçekten değiştiğinde bir kez oynar.
      static const float ADIMLAR[] = { 0.30f, 0.50f, 0.68f, 0.84f, 1.0f };
      for (float s : ADIMLAR) {
        display.fillRect(badgeClearX, badgeClearY, badgeClearW, badgeClearH, UI_HEADER);
        float scl = sclFit * s;
        int w = (int)(icon->w * scl);
        int h = (int)(icon->h * scl);
        if (w < 4) w = 4;
        if (h < 4) h = 4;
        display.drawPng(icon->png, icon->len,
                         HB_BADGE_CX - w / 2, HB_BADGE_CY - h / 2,
                         0, 0, 0, 0, scl, scl);
        display.clearClipRect();
        vTaskDelay(pdMS_TO_TICKS(30));
      }
    } else {
      display.drawPng(icon->png, icon->len,
                       HB_BADGE_CX - finalW / 2, HB_BADGE_CY - finalH / 2,
                       0, 0, 0, 0, sclFit, sclFit);
      display.clearClipRect();
    }
    return;
  }

  // GÜVENLİK AĞI: eşleşen ikon yoksa (beklenmedik/az kullanılan bir
  // başlık gelirse) eski metin tabanlı çizime düş, ekran asla boş kalmaz.
  const bool manualTitle = (strcmp(title, "MANUEL KALİBRASYON") == 0);
  const bool passwordTitle = (strcmp(title, "KALİBRASYON ŞİFRESİ") == 0);

  if (passwordTitle) {
    drawCenteredText("KALİBRASYON", HB_BADGE_CX, HB_BADGE_CY - 18,
                     FONT_SMALL, titleColor, UI_HEADER);
    drawCenteredText("ŞİFRESİ", HB_BADGE_CX, HB_BADGE_CY + 2,
                     FONT_SMALL, titleColor, UI_HEADER);
  } else if (manualTitle) {
    drawCenteredText("MANUEL", HB_BADGE_CX, HB_BADGE_CY - 18,
                     FONT_SMALL, titleColor, UI_HEADER);
    drawCenteredText("KALİBRASYON", HB_BADGE_CX, HB_BADGE_CY + 2,
                     FONT_SMALL, titleColor, UI_HEADER);
  } else {
    display.setFont(FONT_MEDIUM);
    display.setTextSize(1);
    int titleW = display.textWidth(title);
    const int titleMaskPad = 4;
    int titleMaskX = HB_BADGE_CX - titleW / 2 - titleMaskPad;
    int titleMaskW = titleW + titleMaskPad * 2;
    display.fillRect(titleMaskX, HB_BADGE_CY - 12, titleMaskW, 25, UI_HEADER);
    drawCenteredText(title, HB_BADGE_CX, HB_BADGE_CY - 9,
                     FONT_MEDIUM, titleColor, UI_HEADER);
  }
}

// HEADER_STATUS_ICON_PX: ikonların header'da görüneceği kare boyut.
// WiFi (cx≈592) ile Bulut (cx≈622) merkezleri arasında 30px var; bu
// yüzden 26px seçildi -- komşu ikonla ve sağındaki tarih/saat metniyle
// çakışmadan net görünür. Gerekirse büyütülebilir (aşağıdaki 592/622
// konumlarıyla birlikte ince ayar yapılabilir).
const int HEADER_STATUS_ICON_PX = 26;

void drawHeader(const char* title) {
  display.fillRect(0, 0, 800, 72, UI_HEADER);
  // İstek üzerine üstteki mavi çizgi 3 px aşağı çekildi (69 -> 72).
  display.fillRect(0, 72, 800, 3, UI_CYAN);

  // YENİ LOGO: damla ikonu + "NitraCheck" yazısı + "NDSC-8" etiketi artık
  // TEK PARÇA bir görsel (NitraCheckMainLogo.h, alfa kanallı/şeffaf zeminli
  // PNG). Bu yüzden ayrıca "NitraCheck" metni drawString() ile ÇİZİLMİYOR;
  // isim zaten logonun içinde. Header 72 px yüksekliğinde; logo dikeyde
  // ortalanmış.
  const int logoX = 14;
  const int logoY = (72 - NITRACHECK_MAIN_LOGO_H) / 2;

  // drawPng() burada TÜM parametreleriyle (turkeyMapPng'deki calisan
  // cagriyla birebir ayni bicimde) cagriliyor -- varsayilan parametre
  // degerlerine guvenmek yerine acikca 0,0,0,0,1.0,1.0 veriliyor.
  // Logo şeffaf zeminli olduğu için header'ın kendi rengi (UI_HEADER)
  // arka planda görünmeye devam eder, ayrı bir zemin dikdörtgenine gerek yok.
  bool logoOk = display.drawPng(nitraCheckMainLogoPng, nitraCheckMainLogoPngLen,
                                 logoX, logoY, 0, 0, 0, 0, 1.0f, 1.0f);
  if (!logoOk) {
    Serial.println("[HEADER] UYARI: nitraCheckMainLogoPng cizilemedi (drawPng false dondu)");
  }

  // ÖNEMLİ: drawPng() dahili olarak görüntü sınırlarına bir "clip"
  // (kırpma) alanı bırakabiliyor. Bu temizlenmezse, hemen ardından
  // gelen drawString() çağrıları o dar alanla sınırlı kalıp Türkçe
  // çok-baytlı (UTF-8) karakterlerin (Ü, Ç, İ, Ş, Ğ gibi) glifleri
  // yarım/eksik/görünmez çizilebiliyor. Metne geçmeden önce kırpmayı
  // tüm ekrana geri açıyoruz.
  display.clearClipRect();

  // "GÜÇLÜ SU ANALİZ SİSTEMİ" alt yazısı üst bardan kaldırıldı (kullanıcı
  // isteği: bazı ekranlarda arka planda kalıntı gibi görünüyordu; logo
  // zaten NitraCheck ismini içeriyor).

  // Sayfa başlığı: gerçek merkezde TEK ve TAM ÇEMBER + sırayla parlayıp
  // sönen ("vuuuv vuuuv") nefes alma animasyonu. Çizim mantığı
  // drawHeaderTitleBadgeFrame() içine taşındı ki loop() içinden periyodik
  // olarak (yalnızca bu küçük rozet alanı) yeniden çağrılabilsin.
  drawHeaderTitleBadgeFrame(title);

  // WiFi / Bulut: yazı yerine yalnızca modern durum sembolleri.
  // YENİ: elle çizilen yay/bulut yerine gerçek PNG ikonlar (açık/kapalı
  // iki ayrı görsel) -- header'daki NitraCheck logosuyla aynı yöntemle
  // (drawPng, gerçek alfa) çizilir.
  // NOT: WiFi/Bulut/tarih sağ üstteki Türk bayrağına yer açmak için sola
  // kaydırıldı (588->535, 618->565); tarih de 635->590'a çekildi. TRFont18
  // gercek xAdvance degerleri toplanarak "GG.AA.YYYY SS:DD" formatinin
  // textSize=1'de tam 156px surdugu hesaplandi; 590+156=746, bayrak 760'ta
  // basliyor (14px pay), bayrak 760+26=786'da bitiyor (ekran kenarina 14px
  // pay). Hicbir eleman digeriyle çakışmıyor.
  bool wifiOK = (WiFi.status() == WL_CONNECTED);
  drawHeaderStatusIconPng(wifiOK ? wifiAcikIconPng : wifiKapaliIconPng,
                          wifiOK ? wifiAcikIconPngLen : wifiKapaliIconPngLen,
                          WIFI_ACIK_ICON_W, WIFI_ACIK_ICON_H,
                          535, 24, HEADER_STATUS_ICON_PX);
  drawHeaderStatusIconPng(firebaseHazir ? bulutBagliIconPng : bulutBagliDegilIconPng,
                          firebaseHazir ? bulutBagliIconPngLen : bulutBagliDegilIconPngLen,
                          BULUT_BAGLI_ICON_W, BULUT_BAGLI_ICON_H,
                          565, 24, HEADER_STATUS_ICON_PX);

  // Sağ üst köşe: Türk bayrağı. Sabit boyut (26x18), açık/kapalı ayrımı
  // yok; WiFi/Bulut ile aynı dikey hizada (cy=24).
  drawHeaderStatusIconPng(turkBayragiIconPng, turkBayragiIconPngLen,
                          TURK_BAYRAGI_ICON_W, TURK_BAYRAGI_ICON_H,
                          773, 24, TURK_BAYRAGI_ICON_W);

  time_t now = time(nullptr);
  struct tm tmNow;
  localtime_r(&now, &tmNow);

  char dtBuf[24] = "--.--.---- --:--";
  if (now > 100000) {
    strftime(dtBuf, sizeof(dtBuf), "%d.%m.%Y %H:%M", &tmNow);
  }

  drawLeftText(dtBuf, 590, 12, FONT_SMALL, UI_WHITE, UI_HEADER);

  // "GÜÇLÜ SU ANALİZ SİSTEMİ" satırının sağına, sadece sembollerle
  // sıcaklık / nem / GPS özeti. force=true: drawHeader() zaten üstteki
  // 800x72'lik alanı komple silip yeniden çizdiği için, değer değişmemiş
  // olsa bile bu alt satırın mutlaka (yeniden) çizilmesi gerekir.
  drawHeaderStatusIcons(true);

  // Ölçüm ekranında rozetin altındaki ince dönüş oku, cihazın aktif
  // olduğunu anlatan hafif bir hareket iması verir.
  if (strcmp(title, "ÖLÇÜM") == 0) {
    drawMeasurementBadgeMotion();
  }
}

// ── Üst bar sağ alt satır: sıcaklık / nem / GPS — SADECE SEMBOL ──
// "GÜÇLÜ SU ANALİZ SİSTEMİ" alt başlığı ile aynı satır (y=48) üzerinde,
// en sağa dayalı şekilde üç grup gösterilir. Kelime etiketi YOK; her
// değer kendi ikonuyla temsil edilir: termometre->sıcaklık,
// damla->nem, konum iğnesi(pin)->GPS koordinatı.
void drawMiniThermometer(int cx, int cy, uint16_t color) {
  // YENİ TASARIM: çift katmanlı gövde (soluk dış hale + parlak iç gövde),
  // hazne (bulb) içinde küçük bir "cıva" vurgusu ve gövdede ince taksimat
  // çizgileri ile daha "cam termometre" hissi veren, düzleştirilmiş
  // ikon. Eskisi tek renk dolgu düz şekillerden oluşuyordu.
  uint16_t glow = blendColor565(UI_HEADER, color, 55);
  uint16_t soft = blendColor565(UI_HEADER, color, 130);

  // Dış hale (hafif parıltı hissi).
  display.fillRoundRect(cx - 4, cy - 11, 8, 17, 4, glow);
  display.fillCircle(cx, cy + 6, 6, glow);

  // Ana cam gövde.
  display.fillRoundRect(cx - 3, cy - 10, 6, 15, 3, soft);
  display.fillCircle(cx, cy + 6, 5, soft);

  // İçindeki dolu "cıva" sütunu, gövdeden bir tık dar/kısa bırakılarak
  // cam kenarı izlenimi veriyor.
  display.fillRoundRect(cx - 2, cy - 4, 4, 9, 2, color);
  display.fillCircle(cx, cy + 6, 3, color);

  // İnce taksimat çizgileri (üç kısa çizgi), termometreye gerçekçilik katar.
  uint16_t tick = blendColor565(UI_HEADER, UI_WHITE, 60);
  display.drawFastHLine(cx + 4, cy - 7, 2, tick);
  display.drawFastHLine(cx + 4, cy - 3, 2, tick);
  display.drawFastHLine(cx + 4, cy + 1, 2, tick);
}

void drawMiniDrop(int cx, int cy, uint16_t color) {
  // YENİ TASARIM: yumuşak dış hale + parlak damla gövdesi + üstte küçük
  // beyaz bir "ışık yansıması" noktası. Eskisi düz tek renk damlaydı.
  uint16_t glow = blendColor565(UI_HEADER, color, 55);
  uint16_t soft = blendColor565(UI_HEADER, color, 130);

  // Dış hale.
  display.fillCircle(cx, cy + 4, 6, glow);
  display.fillTriangle(cx, cy - 10, cx - 6, cy + 3, cx + 6, cy + 3, glow);

  // Ana damla gövdesi.
  display.fillCircle(cx, cy + 4, 5, soft);
  display.fillTriangle(cx, cy - 9, cx - 5, cy + 3, cx + 5, cy + 3, soft);
  display.fillCircle(cx, cy + 4, 4, color);
  display.fillTriangle(cx, cy - 7, cx - 4, cy + 2, cx + 4, cy + 2, color);

  // Üstte küçük parlama noktası, damlaya cam/su hissi verir.
  display.fillCircle(cx - 2, cy + 2, 1, UI_WHITE);
}

void drawMiniPin(int cx, int cy, uint16_t color) {
  // Bir tık büyütüldü.
  display.drawCircle(cx, cy - 4, 5, color);
  display.fillCircle(cx, cy - 4, 2, color);
  display.drawLine(cx - 4, cy + 1, cx, cy + 9, color);
  display.drawLine(cx + 4, cy + 1, cx, cy + 9, color);
}

// Header'daki WiFi / Bulut durum ikonları artık elle çizilen yay/bulut
// şekilleri değil; gerçek PNG (açık/kapalı iki ayrı görsel, kendi
// rengi gömülü -- yeşil/kırmızı ayrımı artık görselin kendisinde).
void drawHeaderStatusIconPng(const uint8_t* png, uint32_t len, int srcW, int srcH,
                              int cx, int cy, int hedefPx) {
  float scl = (float)hedefPx / (float)srcW;
  int dispW = (int)(srcW * scl);
  int dispH = (int)(srcH * scl);
  display.drawPng(png, len, cx - dispW / 2, cy - dispH / 2, 0, 0, 0, 0, scl, scl);
}

// "ÖLÇÜM" ekranında, WiFi ikonunun HEMEN SOLUNDA -- İSTEK ÜZERİNE artık
// rozetin altında/uzağında değil, WiFi/Bulut ikonlarıyla aynı satırda,
// onların bir parçasıymış gibi -- 5 saniyede bir dolup boşalan küçük
// bir DENEY (TEST) TÜPÜ animasyonu.
//
// Döngü tamamen millis() tabanlı olduğu için "static" bir açı/durum
// değişkeni gerekmiyor: her 5000 ms'de bir tüp baştan boş başlar ve
// yeniden dolar.
void drawMeasurementBadgeMotion() {
  const int cx = 510;   // WiFi ikonunun (588) hemen solu
  const int cy = 26;    // WiFi/Bulut ikonlarıyla aynı dikey hizada

  const int tubeW = 12;
  const int tubeH = 26;
  const int tubeX = cx - tubeW / 2;
  const int tubeY = cy - tubeH / 2;
  const int r = 5;

  // Önceki karenin TAM ikon alanını (tüp gövdesi + ağız çizgisi dahil)
  // temizle; aksi halde eski dolum seviyesinden izler kalır.
  display.fillRect(tubeX - 6, tubeY - 6, tubeW + 12, tubeH + 12, UI_HEADER);

  // 5 saniyelik döngüde 0.0 (boş) -> 1.0 (tam dolu) arası oran.
  unsigned long cyclePos = millis() % 5000UL;
  float frac = (float)cyclePos / 5000.0f;

  uint16_t glassColor = blendColor565(UI_HEADER, UI_WHITE, 55);
  // Dolum ilerledikçe sıvı rengi camgöbeğinden mora doğru akar; tüp
  // her döngüde farklı bir renk tonuyla dolar gibi görünür.
  uint16_t liquidColor = blendColor565(rgb565(0, 200, 255), rgb565(150, 90, 255),
                                        (uint8_t)(frac * 255));

  // Sıvı, cam kenarından 2px içeride, alttan yukarı doğru dolar.
  const int innerPad = 2;
  int innerX = tubeX + innerPad;
  int innerW = tubeW - innerPad * 2;
  int innerTopY = tubeY + innerPad;
  int innerH = tubeH - innerPad * 2;

  int liquidH = (int)(innerH * frac);
  if (liquidH > 0) {
    int liquidY = innerTopY + innerH - liquidH;
    int liqR = (liquidH < 4) ? liquidH / 2 : 3;
    display.fillRoundRect(innerX, liquidY, innerW, liquidH, liqR, liquidColor);

    // Sıvı yüzeyinde ince parlak bir çizgi; "yeni dolan su" hissi verir.
    display.drawFastHLine(innerX, liquidY, innerW,
                          blendColor565(liquidColor, UI_WHITE, 90));
  }

  // Cam tüpün dış hattı (sıvının üstüne çizilir, tüpü her zaman belirgin tutar).
  display.drawRoundRect(tubeX, tubeY, tubeW, tubeH, r, glassColor);

  // Tüpün ağzı: gövdeden bir tık taşan ince üst çizgi.
  display.drawFastHLine(tubeX - 2, tubeY - 2, tubeW + 4, glassColor);

  // Camda ince bir ışık yansıması; tüpe cam/parlak his katar.
  display.drawFastVLine(tubeX + 3, tubeY + 4, tubeH - 8,
                        blendColor565(UI_HEADER, UI_WHITE, 35));
}

// force=true: değer değişmemiş olsa bile mutlaka (yeniden) çizer -- bu,
// header'ın tamamı silinip yeniden çizildiği (drawHeader) durumlar için
// gereklidir, aksi halde arka plan boş kalır. force=false: sadece
// sıcaklık/nem/GPS değerlerinden biri GERÇEKTEN değiştiyse çizer; hiçbir
// şey değişmediyse dokunmadan çıkar. Bu ikinci mod, loop() içinde her
// birkaç saniyede bir "boşuna" temizle+yeniden-çiz yapılıp RGB panelde
// gözle görülür bir titreme/flap oluşmasını önlemek için eklendi.
void drawHeaderStatusIcons(bool force) {
  const int rowY = 49;
  const int iconCy = rowY + 7;
  const int rightEdge = 780;
  const int groupGap = 14;
  const int iconTextGap = 6;
  // ESKİ (elle çizilen küçük ikonlar) 12px genişliğindeydi (iconHalfW=6).
  // YENİ PNG ikonlar (sıcaklık/nem/GPS) HEADER_STATUS_ICON_PX (26px)
  // boyutunda çizildiği için yarı genişlik buna göre güncellendi; aksi
  // halde metinle ikon üst üste biner/komşu gruba çok yakın düşerdi.
  const int iconHalfW = HEADER_STATUS_ICON_PX / 2;

  // Önce, hiçbir şey çizmeden, sadece bu "karede" gösterilecek metinleri
  // hesapla. Böylece gerçekten bir değişiklik olup olmadığına -- ekrana
  // dokunmadan önce -- karar verebiliyoruz.
  char gpsTxt[24];
  if (gpsKonumGecerli) snprintf(gpsTxt, sizeof(gpsTxt), "%.2f,%.2f", gpsEnlem, gpsBoylam);
  else snprintf(gpsTxt, sizeof(gpsTxt), "--");

  char nemTxt[16];
  bool nemVar = sht40Hazir && isfinite(sonNemYuzde);
  if (nemVar) snprintf(nemTxt, sizeof(nemTxt), "%.0f%%", sonNemYuzde);
  else snprintf(nemTxt, sizeof(nemTxt), "--");

  char sicNumTxt[12];
  bool sicVar = sht40Hazir && isfinite(sonSicaklikC);
  if (sicVar) snprintf(sicNumTxt, sizeof(sicNumTxt), "%.1f", sonSicaklikC);
  else snprintf(sicNumTxt, sizeof(sicNumTxt), "--");

  // Son çizilen kareyle karşılaştır; hiçbir şey değişmediyse (ve force
  // istenmediyse) ekrana hiç dokunma -- titremenin asıl kaynağı buydu.
  static char lastGpsTxt[24] = "";
  static char lastNemTxt[16] = "";
  static char lastSicTxt[12] = "";
  static bool lastGpsValid = false;
  bool changed = (strcmp(gpsTxt, lastGpsTxt) != 0) ||
                 (strcmp(nemTxt, lastNemTxt) != 0) ||
                 (strcmp(sicNumTxt, lastSicTxt) != 0) ||
                 (gpsKonumGecerli != lastGpsValid);
  if (!force && !changed) return;

  strcpy(lastGpsTxt, gpsTxt);
  strcpy(lastNemTxt, nemTxt);
  strcpy(lastSicTxt, sicNumTxt);
  lastGpsValid = gpsKonumGecerli;

  // Sıcaklık/nem arkasında görünen eski piksel kalıntılarını tamamen temizle.
  // Rozetin sağından başlayıp sadece alt durum satırını kapsar.
  display.fillRect(450, 40, 350, 32, UI_HEADER);

  display.setFont(FONT_SMALL);
  display.setTextSize(0.88f);
  display.setTextDatum(textdatum_t::top_left);

  // GPS — en sağda
  uint16_t gpsColor = gpsKonumGecerli ? UI_RED : UI_MUTED;
  int gpsTextW = display.textWidth(gpsTxt);
  int gpsTextX = rightEdge - gpsTextW;
  display.setTextColor(gpsColor, UI_HEADER);
  display.drawString(gpsTxt, gpsTextX, rowY);
  int gpsIconCx = gpsTextX - iconTextGap - iconHalfW;
  // YENİ: elle çizilen pin yerine gerçek PNG ikon (açık/kapalı), header'daki
  // WiFi/Bulut ikonlarıyla aynı yöntemle (drawHeaderStatusIconPng).
  drawHeaderStatusIconPng(gpsKonumGecerli ? konumAcikIconPng : konumKapaliIconPng,
                          gpsKonumGecerli ? konumAcikIconPngLen : konumKapaliIconPngLen,
                          KONUM_ICON_W, KONUM_ICON_H,
                          gpsIconCx, iconCy, HEADER_STATUS_ICON_PX);

  // Nem
  int nemGroupRight = gpsIconCx - iconHalfW - groupGap;
  uint16_t nemColor = nemVar ? UI_CYAN : UI_MUTED;
  int nemTextW = display.textWidth(nemTxt);
  int nemTextX = nemGroupRight - nemTextW;
  display.setTextColor(nemColor, UI_HEADER);
  display.drawString(nemTxt, nemTextX, rowY);
  int nemIconCx = nemTextX - iconTextGap - iconHalfW;
  // YENİ: elle çizilen damla yerine gerçek PNG ikon (açık/kapalı).
  drawHeaderStatusIconPng(nemVar ? nemAcikIconPng : nemKapaliIconPng,
                          nemVar ? nemAcikIconPngLen : nemKapaliIconPngLen,
                          NEM_ICON_W, NEM_ICON_H,
                          nemIconCx, iconCy, HEADER_STATUS_ICON_PX);

  // Sıcaklık
  // NOT: Özel Türkçe fontumuzda (TRFont18) "°" (derece) karakterinin
  // karşılığı yok; bu yüzden "%.1f°C" doğrudan yazdırılınca ekranda
  // bozuk bir "|" gibi görünüyordu. Çözüm: sayıyı ve "C" harfini normal
  // metin olarak yazıp, derece işaretini KÜÇÜK BİR ÇEMBER olarak elle
  // çiziyoruz -- fonttan tamamen bağımsız, her zaman doğru görünür.
  int sicGroupRight = nemIconCx - iconHalfW - groupGap;
  uint16_t sicColor = sicVar ? UI_ORANGE : UI_MUTED;

  const int degR = 3;    // elle çizilen derece işaretinin yarıçapı
  const int degGap = 3;  // sayı ile derece işareti arası boşluk
  const int cGap = 2;    // derece işareti ile "C" arası boşluk

  int numW = display.textWidth(sicNumTxt);
  int cW = sicVar ? display.textWidth("C") : 0;
  int extraW = sicVar ? (degGap + degR * 2 + cGap + cW) : 0;
  int sicTextX = sicGroupRight - numW - extraW;

  display.setTextColor(sicColor, UI_HEADER);
  display.drawString(sicNumTxt, sicTextX, rowY);

  if (sicVar) {
    // Derece işareti rakamların üst hizasına yakın, küçük bir üst simge
    // gibi konumlandırılır.
    int degCx = sicTextX + numW + degGap + degR;
    int degCy = rowY + 3;
    display.drawCircle(degCx, degCy, degR, sicColor);
    display.drawString("C", degCx + degR + cGap, rowY);
  }

  int sicIconCx = sicTextX - iconTextGap - iconHalfW;
  // YENİ: elle çizilen termometre yerine gerçek PNG ikon (açık/kapalı).
  drawHeaderStatusIconPng(sicVar ? sicaklikAcikIconPng : sicaklikKapaliIconPng,
                          sicVar ? sicaklikAcikIconPngLen : sicaklikKapaliIconPngLen,
                          SICAKLIK_ICON_W, SICAKLIK_ICON_H,
                          sicIconCx, iconCy, HEADER_STATUS_ICON_PX);

  display.setTextSize(1);
  display.setTextDatum(textdatum_t::top_left);
}

void drawIcon(IconType icon, int cx, int cy, uint16_t color) {
  // Ana ekrandaki ikonlar için daha modern, temiz ve okunaklı çizimler.
  // Sadece görsel çizim değiştirildi; buton koordinatları ve dokunmatik alanlar aynı.
  if (icon == ICON_LOCATION) {
    // Modern harita pini: dolu gövde + koyu merkez noktası + küçük vurgu halkası.
    display.fillCircle(cx, cy - 4, 8, color);
    display.fillTriangle(cx - 7, cy - 1, cx + 7, cy - 1, cx, cy + 11, color);
    display.fillCircle(cx, cy - 4, 3, UI_PANEL2);
    display.drawCircle(cx, cy - 4, 9, UI_WHITE);
  }
  else if (icon == ICON_CLOUD) {
    // Daha yuvarlak, modern bulut + veri aktarım oku.
    display.fillCircle(cx - 7, cy + 2, 6, color);
    display.fillCircle(cx,     cy - 2, 8, color);
    display.fillCircle(cx + 8, cy + 2, 6, color);
    display.fillRoundRect(cx - 13, cy + 1, 27, 9, 4, color);
    // Küçük veri aktarım oku: bulutun ne yaptığını daha anlaşılır kılar.
    display.drawLine(cx, cy + 1, cx, cy + 8, UI_PANEL2);
    display.drawLine(cx - 3, cy + 5, cx, cy + 8, UI_PANEL2);
    display.drawLine(cx + 3, cy + 5, cx, cy + 8, UI_PANEL2);
  }
  else if (icon == ICON_GEAR) {
    // Daha dolu ve okunaklı ayar çarkı.
    for (int a = 0; a < 360; a += 45) {
      float r = a * 0.0174532925f;
      int x1 = cx + (int)(7 * cosf(r));
      int y1 = cy + (int)(7 * sinf(r));
      int x2 = cx + (int)(11 * cosf(r));
      int y2 = cy + (int)(11 * sinf(r));
      display.drawLine(x1, y1, x2, y2, color);
      display.drawLine(x1 + 1, y1, x2 + 1, y2, color);
    }
    display.fillCircle(cx, cy, 7, color);
    display.fillCircle(cx, cy, 3, UI_PANEL2);
    display.drawCircle(cx, cy, 8, UI_WHITE);
  }
  else if (icon == ICON_DROP) {
    // Ölçüm damlası: parlak vurgulu, daha belirgin siluet.
    display.fillCircle(cx, cy + 4, 7, color);
    display.fillTriangle(cx, cy - 11, cx - 7, cy + 4, cx + 7, cy + 4, color);
    display.fillCircle(cx - 2, cy + 1, 2, UI_WHITE);
  }
  else if (icon == ICON_CHECK) {
    // Kalın ve daha görünür onay işareti.
    display.drawLine(cx - 7, cy,     cx - 2, cy + 6, color);
    display.drawLine(cx - 6, cy,     cx - 1, cy + 6, color);
    display.drawLine(cx - 2, cy + 6, cx + 9, cy - 7, color);
    display.drawLine(cx - 1, cy + 6, cx + 10, cy - 7, color);
  }
  else if (icon == ICON_PRINTER) {
    // Modern termal yazıcı: renkli gövde, beyaz kağıt ve durum LED'i.
    display.fillRoundRect(cx - 11, cy - 4, 22, 13, 3, color);
    display.fillRoundRect(cx - 8, cy - 11, 16, 8, 2, UI_WHITE);
    display.fillRoundRect(cx - 7, cy + 7, 14, 7, 1, UI_WHITE);
    display.fillRect(cx - 4, cy - 9, 8, 1, UI_MUTED);
    display.fillCircle(cx + 6, cy, 1, UI_GREEN);
    display.drawLine(cx - 4, cy + 10, cx + 4, cy + 10, UI_MUTED);
  }
}
uint16_t iconColor(IconType icon) {
  if (icon == ICON_LOCATION) return UI_RED;      // Harita -> kirmizi
  if (icon == ICON_CLOUD)    return UI_WHITE;    // Bulut  -> beyaz
  if (icon == ICON_GEAR)     return UI_ORANGE;   // Ayarlar -> turuncu
  if (icon == ICON_DROP)     return UI_PINK;     // Olcum (damla) -> pembe
  if (icon == ICON_PRINTER)  return UI_CYAN;      // Yazdır -> camgöbeği
  return UI_WHITE;
}

// Sol menü butonları (Yazdır/Harita/Buluta Gönder/Ayarlar) için YENİ:
// elle çizilen basit vektör ikonlar yerine gerçek PNG ikonlar. Kaynak
// görseller 40x40, gerçek alfa kanallı (şeffaf zeminli) -- header'daki
// NitraCheck logosuyla aynı yöntemle (drawPng, gerçek alfa) çizilir.
// MENU_ICON_HEDEF_PX: ikonun ekranda görüneceği kare boyut. Buton
// yüksekliği 34px olduğundan ve ikon x+24 merkezli ~52px'lik bir alana
// sığması gerektiğinden 30px seçildi (eski vektör ikonlardan biraz
// daha büyük ve net, ama komşu yazıyla çakışmıyor).
const int MENU_ICON_HEDEF_PX = 30;

// İlgili IconType için PNG varlığı varsa (cx,cy) merkezli olarak çizer
// ve true döner; yoksa hiçbir şey yapmaz ve false döner (çağıran taraf
// bu durumda eski drawIcon() vektör çizimine düşebilir).
bool drawMenuIconPng(IconType icon, int cx, int cy) {
  const uint8_t* png = nullptr;
  uint32_t len = 0;
  int srcW = 0, srcH = 0;

  if (icon == ICON_PRINTER)       { png = printerIconPng;      len = printerIconPngLen;      srcW = PRINTER_ICON_W;      srcH = PRINTER_ICON_H; }
  else if (icon == ICON_LOCATION) { png = haritaIconPng;       len = haritaIconPngLen;       srcW = HARITA_ICON_W;       srcH = HARITA_ICON_H; }
  else if (icon == ICON_CLOUD)    { png = bulutGonderIconPng;  len = bulutGonderIconPngLen;  srcW = BULUT_GONDER_ICON_W; srcH = BULUT_GONDER_ICON_H; }
  else if (icon == ICON_GEAR)     { png = ayarlarIconPng;      len = ayarlarIconPngLen;      srcW = AYARLAR_ICON_W;      srcH = AYARLAR_ICON_H; }

  if (png == nullptr) return false;

  float scl = (float)MENU_ICON_HEDEF_PX / (float)srcW;
  int dispW = (int)(srcW * scl);
  int dispH = (int)(srcH * scl);
  display.drawPng(png, len, cx - dispW / 2, cy - dispH / 2, 0, 0, 0, 0, scl, scl);
  return true;
}

void drawButton(int x, int y, int w, int h, const char* label,
                uint16_t accent, IconType icon = ICON_NONE,
                bool filled = false) {
  uint16_t fill = filled ? accent : UI_PANEL2;

  display.fillRoundRect(x, y, w, h, 9, fill);
  display.drawRoundRect(x, y, w, h, 9, accent);

  if (icon != ICON_NONE) {
    uint16_t ic = iconColor(icon);
    drawIcon(icon, x + 25, y + h / 2, ic);
  }

  display.setFont(FONT_SMALL);
  display.setTextSize(1);
  display.setTextColor(filled ? UI_BG : UI_WHITE, fill);
  display.setTextDatum(textdatum_t::middle_center);

  int center = icon == ICON_NONE ? x + w/2 : x + (w + 38)/2;
  display.drawString(label, center, y + h/2);

  display.setTextDatum(textdatum_t::top_left);
}

// ============================================================
// MODERN ÖLÇÜMÜ BAŞLAT BUTONU
// Mevcut dokunmatik alanın koordinatlarını değiştirmez.
// ============================================================
static uint16_t blendColor565(uint16_t c1, uint16_t c2, uint8_t amount) {
  uint8_t r1 = (c1 >> 11) & 0x1F;
  uint8_t g1 = (c1 >> 5)  & 0x3F;
  uint8_t b1 = c1 & 0x1F;
  uint8_t r2 = (c2 >> 11) & 0x1F;
  uint8_t g2 = (c2 >> 5)  & 0x3F;
  uint8_t b2 = c2 & 0x1F;

  uint8_t r = r1 + (((int)r2 - r1) * amount) / 255;
  uint8_t g = g1 + (((int)g2 - g1) * amount) / 255;
  uint8_t b = b1 + (((int)b2 - b1) * amount) / 255;
  return (uint16_t)((r << 11) | (g << 5) | b);
}


// ============================================================
// FUTURİSTİK SOL MENÜ BUTONU
// Mevcut ikonları korur; sadece buton gövdesini modernleştirir.
// ============================================================
void drawFuturisticMenuButton(int x, int y, int w, int h,
                              const char* label, IconType icon,
                              uint16_t accent = UI_CYAN,
                              bool locked = false) {
  // Büyük "ÖLÇÜMÜ BAŞLAT" butonuyla aynı tasarım ailesi;
  // yalnızca sol menü için daha kompakt.
  //
  // locked=true: ölçüm sürerken buton dokunulamaz durumdadır. ESKİDEN bu
  // durumda drawLockedSideButtons() tamamen farklı/eski düz drawButton()
  // fonksiyonunu çağırıyordu; bu yüzden "ölçüm ekranında butonlar eskiye
  // dönüyor" görüntüsü oluşuyordu. Artık aynı camsı/gradyanlı tasarım
  // korunuyor, sadece renk paleti soluklaştırılıyor.
  const int radius = 10;

  // Tema rengi doğrudan buton gövdesine uygulanır.
  // Eski sürümde aşağıdaki sabit RGB565 değerleri her zaman MAVİ idi.
  const uint16_t glowColor   = locked ? rgb565(55, 62, 72) : blendColor565(accent, UI_BG, 70);
  const uint16_t borderColor = locked ? rgb565(92, 98, 108) : accent;
  const uint16_t baseFill    = locked ? rgb565(32, 38, 48) : blendColor565(accent, UI_PANEL2, 150);
  const uint16_t topColor    = locked ? rgb565(68, 76, 90) : blendColor565(accent, UI_WHITE, 42);
  const uint16_t bottomColor = locked ? rgb565(22, 26, 34) : blendColor565(accent, UI_BG, 170);
  const uint16_t glassColor  = locked ? rgb565(94, 102, 114) : blendColor565(accent, UI_WHITE, 75);
  const uint16_t glassLine   = locked ? rgb565(118, 126, 138) : blendColor565(accent, UI_WHITE, 110);
  const uint16_t textColor   = locked ? UI_MUTED : UI_WHITE;

  // İnce dış parlama
  display.drawRoundRect(x - 1, y - 1, w + 2, h + 2, radius + 1, glowColor);
  display.drawRoundRect(x, y, w, h, radius, borderColor);

  // ÖLÇÜMÜ BAŞLAT ile tamamen aynı renk ailesi ve parlaklık
  display.fillRoundRect(x, y, w, h, radius, baseFill);

  for (int iy = 2; iy < h - 2; ++iy) {
    uint8_t amount = (uint8_t)((iy * 255L) / (h - 1));
    uint16_t c = blendColor565(topColor, bottomColor, amount);

    int inset = 2;
    if (iy < radius) {
      int d = radius - iy;
      inset += (d * d) / (radius * 2);
    } else if (iy > h - radius - 1) {
      int d = iy - (h - radius - 1);
      inset += (d * d) / (radius * 2);
    }

    int lineW = w - inset * 2;
    if (lineW > 0) {
      display.drawFastHLine(x + inset, y + iy, lineW, c);
    }
  }

  // ÖLÇÜMÜ BAŞLAT ile aynı parlak cam çerçeve.
  // İkon sonrası pipe ve köşe teknolojik çizgileri YOK.
  display.drawRoundRect(x, y, w, h, radius, glassColor);
  display.drawLine(x + radius, y + 2, x + w - radius, y + 2, glassLine);

  // YENİ: gerçek PNG ikon varsa onu çiz (Yazdır/Harita/Buluta Gönder/
  // Ayarlar artık PNG); yoksa eski elle-çizilmiş vektör ikona düş.
  // NOT: PNG ikonların kendi rengi gömülü olduğundan "locked" (kilitli/
  // soluk) durumda renk değiştirilemiyor; bu görsel fark küçük ve kabul
  // edilebilir (buton çerçevesi/zemini zaten soluklaşarak kilidi belli ediyor).
  if (!drawMenuIconPng(icon, x + 24, y + h / 2)) {
    uint16_t ic = locked ? UI_MUTED : iconColor(icon);
    drawIcon(icon, x + 24, y + h / 2, ic);
  }

  // Yazı, ikon için solda yer bırakılarak optik olarak ortalanır.
  display.setFont(FONT_SMALL);
  display.setTextSize(0.96f);
  display.setTextColor(textColor);
  display.setTextDatum(textdatum_t::middle_center);
  display.drawString(label, x + 52 + (w - 52) / 2, y + h / 2);

  display.setTextDatum(textdatum_t::top_left);
  display.setTextSize(1);
}

void drawOlcumuBaslatButonu(int x, int y, int w, int h) {
  const int radius = 16;

  // İnce dış parlama ve çerçeve - aktif tema rengini kullanır.
  const uint16_t accent = UI_CYAN;
  display.drawRoundRect(x - 2, y - 2, w + 4, h + 4, radius + 2, blendColor565(accent, UI_BG, 70));
  display.drawRoundRect(x - 1, y - 1, w + 2, h + 2, radius + 1, accent);

  // Alt temel katman
  display.fillRoundRect(x, y, w, h, radius, blendColor565(accent, UI_PANEL2, 150));

  // Yukarıdan aşağıya aktif tema renginden üretilen gradient
  const uint16_t topColor    = blendColor565(accent, UI_WHITE, 42);
  const uint16_t bottomColor = blendColor565(accent, UI_BG, 170);

  for (int iy = 2; iy < h - 2; ++iy) {
    uint8_t amount = (uint8_t)((iy * 255L) / (h - 1));
    uint16_t c = blendColor565(topColor, bottomColor, amount);

    int inset = 3;
    if (iy < radius) {
      int d = radius - iy;
      inset += (d * d) / (radius * 2);
    } else if (iy > h - radius - 1) {
      int d = iy - (h - radius - 1);
      inset += (d * d) / (radius * 2);
    }

    int lineW = w - (inset * 2);
    if (lineW > 0) display.drawFastHLine(x + inset, y + iy, lineW, c);
  }

  // Cam etkisi veren ince üst vurgusu
  display.drawRoundRect(x, y, w, h, radius, blendColor565(accent, UI_WHITE, 55));
  display.drawLine(x + radius, y + 2, x + w - radius, y + 2, blendColor565(accent, UI_WHITE, 85));

  // ▶ Play ikonu
  const int iconX = x + 100;
  const int iconY = y + (h / 2);

  // Hafif gölge ve ana ikon
  display.fillTriangle(iconX - 8, iconY - 13,
                       iconX - 8, iconY + 13,
                       iconX + 14, iconY + 1, 0x18C3);
  display.fillTriangle(iconX - 9, iconY - 14,
                       iconX - 9, iconY + 14,
                       iconX + 15, iconY, UI_WHITE);

  // Başlık
  display.setFont(FONT_MEDIUM);
  display.setTextSize(1.02f);
  display.setTextColor(UI_WHITE);
  display.setTextDatum(textdatum_t::middle_center);
  display.drawString("Ölçümü Başlat", x + (w / 2) + 30, y + (h / 2));
  display.setTextDatum(textdatum_t::top_left);
  display.setTextSize(1);
}

void drawStatusPill(int x, int y, int w, const char* label,
                    uint16_t color) {
  display.fillRoundRect(x, y, w, 34, 10, UI_PANEL2);
  display.drawRoundRect(x, y, w, 34, 10, color);
  display.fillCircle(x + 16, y + 17, 5, color);

  // Uzun durum metinleri kutudan taşmasın.
  // Metni kullanılabilir genişliğe göre otomatik küçült.
  display.setFont(FONT_SMALL);
  display.setTextColor(UI_WHITE, UI_PANEL2);
  display.setTextDatum(textdatum_t::middle_center);

  float statusScale = 1.0f;
  const int availableW = w - 44;
  display.setTextSize(statusScale);
  int16_t statusW = display.textWidth(label);
  if (statusW > availableW && statusW > 0) {
    statusScale = (float)availableW / (float)statusW;
    if (statusScale < 0.68f) statusScale = 0.68f;
  }
  display.setTextSize(statusScale);
  display.drawString(label, x + 29 + availableW / 2, y + 17);

  display.setTextDatum(textdatum_t::top_left);
  display.setTextSize(1);
}

// Spektral grafik yardımcıları.
// Bu grafik ANALİTİK hesaplamayı değiştirmez; yalnızca gerçek F1-F8
// ölçümlerini görsel olarak daha düzgün bir spektral eğriye dönüştürür.
// Gaussian kernel smoothing kullanılır; yeni ölçüm verisi uydurulmaz.
// Dalga boyu -> RGB: 380-780nm görünür ışık spektrumunun SÜREKLİ
// (basamaksız) yaklaşık renk eşlemesi. Klasik "wavelength to RGB"
// (Dan Bruton) formülüne dayanır; her nm için ayrı ayrı hesaplanır,
// bu yüzden komşu pikseller arasında ani renk sıçraması olmaz — gerçek
// bir prizmanın ayrıştırdığı ışık gibi ince, sürekli tonlama.
// Kırmızı uçta (620-680nm) insan gözünün uzun dalga boyu duyarlılığını
// taklit eden yumuşak bir koyulaşma (falloff) uygulanır: 620nm'de canlı
// kırmızı, 680nm'ye doğru koyu bordoya kadar kararır.
uint16_t spectrumWavelengthColor(float nm) {
  float r = 0.0f, g = 0.0f, b = 0.0f;

  if (nm < 440.0f) {
    r = -(nm - 440.0f) / (440.0f - 380.0f);
    g = 0.0f;
    b = 1.0f;
  } else if (nm < 490.0f) {
    r = 0.0f;
    g = (nm - 440.0f) / (490.0f - 440.0f);
    b = 1.0f;
  } else if (nm < 510.0f) {
    r = 0.0f;
    g = 1.0f;
    b = -(nm - 510.0f) / (510.0f - 490.0f);
  } else if (nm < 580.0f) {
    r = (nm - 510.0f) / (580.0f - 510.0f);
    g = 1.0f;
    b = 0.0f;
  } else if (nm < 645.0f) {
    r = 1.0f;
    g = -(nm - 645.0f) / (645.0f - 580.0f);
    b = 0.0f;
  } else {
    r = 1.0f;
    g = 0.0f;
    b = 0.0f;
  }

  if (r < 0.0f) r = 0.0f; else if (r > 1.0f) r = 1.0f;
  if (g < 0.0f) g = 0.0f; else if (g > 1.0f) g = 1.0f;
  if (b < 0.0f) b = 0.0f; else if (b > 1.0f) b = 1.0f;

  // Kırmızı uçta yumuşak koyulaşma: 620nm'de tam parlaklık (1.0),
  // 680nm'de ~%35 parlaklık (koyu bordo kırmızı) — "en koyudan en
  // açığa" istenen ince geçiş burada oluşuyor.
  float falloff = 1.0f;
  if (nm > 620.0f) {
    float t = (nm - 620.0f) / (680.0f - 620.0f);
    if (t > 1.0f) t = 1.0f;
    falloff = 1.0f - 0.65f * t;
  }

  const float gamma = 0.85f;
  uint8_t R = (uint8_t)(powf(r * falloff, gamma) * 255.0f);
  uint8_t G = (uint8_t)(powf(g * falloff, gamma) * 255.0f);
  uint8_t B = (uint8_t)(powf(b * falloff, gamma) * 255.0f);

  return rgb565(R, G, B);
}

float gaussianSpectralAt(const float* values,
                         const float* wavelengths,
                         int count,
                         float x,
                         float sigma) {
  float weighted = 0.0f;
  float weightSum = 0.0f;

  for (int i = 0; i < count; i++) {
    float d = (x - wavelengths[i]) / sigma;
    float wgt = expf(-0.5f * d * d);
    weighted += values[i] * wgt;
    weightSum += wgt;
  }

  return (weightSum > 0.0001f) ? (weighted / weightSum) : 0.0f;
}

void drawSpectrumGraph(int x, int y, int w, int h) {
  // Mevcut NitraCheck spektral görünüm korunur:
  // gerçek F1-F8 verisi Gaussian smoothing ile sürekli eğriye dönüştürülür.
  display.fillRoundRect(x, y, w, h, 11, UI_PANEL2);
  display.drawRoundRect(x, y, w, h, 11, UI_LINE);

  // Küçük başlık; grafik alanından gereksiz yer çalmaz.
  display.setFont(FONT_SMALL);
  display.setTextSize(0.76f);
  display.setTextColor(UI_WHITE, UI_PANEL2);
  display.setTextDatum(textdatum_t::top_left);
  display.drawString("AS7341 SPEKTRAL ANALİZ", x + 16, y + 7);

  const float lambda[NDSC_KANAL] =
    {415, 445, 480, 515, 555, 590, 630, 680};

  // Akademik eksenler için sol ve alt boşluk ayrılır.
  // Alt boşluk daraltıldı: "Dalga Boyu (nm)" alt satırı kaldırıldığı için
  // artık yalnızca eksen çentiği + sayı satırına yetecek kadar yer ayrılır,
  // kalan alan çizim alanına (gh) eklenir.
  int gx = x + 44;
  int gy = y + 27;
  int gw = w - 54;
  int gh = h - 47;

  if (!sonSpektrumHazir) {
    display.drawLine(gx, gy + gh, gx + gw, gy + gh, UI_LINE);
    display.drawLine(gx, gy, gx, gy + gh, UI_LINE);
    drawCenteredText("ÖLÇÜM BEKLENİYOR",
                     x + w / 2, y + h / 2,
                     FONT_SMALL, UI_MUTED, UI_PANEL2);
    return;
  }

  // GERÇEK AS7341 verisi: dark referansı çıkarılır.
  float beyazVals[NDSC_KANAL];
  float maxV = 1.0f;

  for (int i = 0; i < NDSC_KANAL; i++) {
    beyazVals[i] = sonSpektrumBeyaz[i] - darkSpectrum[i];
    if (beyazVals[i] < 0) beyazVals[i] = 0;
    if (beyazVals[i] > maxV) maxV = beyazVals[i];
  }

  float graphMax = maxV * 1.12f;
  if (graphMax < 1.0f) graphMax = 1.0f;

  // "Akademik" ölçek: 0, 25, 50, 75, 100 % yerine gerçek
  // dark-düzeltilmiş kanal şiddeti ölçeği (a.u.) kullanılır.
  display.setFont(FONT_SMALL);
  display.setTextSize(0.48f);
  display.setTextColor(UI_MUTED, UI_PANEL2);

  for (int gyLine = 0; gyLine <= 4; gyLine++) {
    int yy = gy + (gh * gyLine) / 4;
    uint16_t gridColor = (gyLine == 4) ? UI_LINE : rgb565(55, 60, 68);
    display.drawLine(gx, yy, gx + gw, yy, gridColor);

    float yValue = graphMax * (1.0f - ((float)gyLine / 4.0f));
    char yLabel[18];
    if (yValue >= 10000.0f)
      snprintf(yLabel, sizeof(yLabel), "%.0fk", yValue / 1000.0f);
    else
      snprintf(yLabel, sizeof(yLabel), "%.0f", yValue);

    display.setTextDatum(textdatum_t::middle_right);
    display.drawString(yLabel, gx - 7, yy);
  }

  // Ana eksenler.
  display.drawLine(gx, gy, gx, gy + gh, UI_MUTED);
  display.drawLine(gx, gy + gh, gx + gw, gy + gh, UI_MUTED);

  // X ekseninde gerçek AS7341 kanal merkezleri.
  for (int i = 0; i < NDSC_KANAL; i++) {
    int xx = gx + (int)(((lambda[i] - 415.0f) / 265.0f) * gw);
    display.drawLine(xx, gy + gh, xx, gy + gh + 4, UI_MUTED);

    char xLabel[8];
    snprintf(xLabel, sizeof(xLabel), "%.0f", lambda[i]);
    display.setTextDatum(textdatum_t::top_center);
    display.drawString(xLabel, xx, gy + gh + 6);
  }

  // Birim etiketi beyaz ve doğrudan grafiğin x ekseni üzerinde, sağ uçta gösterilir.
  display.setTextSize(0.58f);
  display.setTextColor(UI_WHITE, UI_PANEL2);
  display.setTextDatum(textdatum_t::middle_right);
  display.drawString("nm", gx + gw - 4, gy + gh - 10);
  display.setTextSize(1);

  // Y ekseni başlığını döndürmeden, teknik ve okunabilir biçimde sol üstte veririz.
  display.setTextDatum(textdatum_t::top_left);
  display.drawString("Sinyal Şiddeti (a.u.)", gx + 2, gy + 2);

  // Mevcut güzel NitraCheck grafiği korunur:
  // Gaussian smoothing + spektral renk dolgusu + beyaz kontur.
  const float sigma = 22.0f;
  int prevX = gx;
  int prevYB = gy + gh;

  for (int px = 0; px <= gw; px++) {
    float nm = 415.0f + (265.0f * (float)px / (float)gw);

    float bv = gaussianSpectralAt(beyazVals, lambda, NDSC_KANAL,
                                  nm, sigma);

    int cx = gx + px;
    int yb = gy + gh - (int)((bv / graphMax) * (gh - 12));
    if (yb < gy + 10) yb = gy + 10;
    if (yb > gy + gh) yb = gy + gh;

    uint16_t specColor = spectrumWavelengthColor(nm);
    display.drawFastVLine(cx, yb, (gy + gh) - yb + 1, specColor);

    if (px > 0) {
      display.drawLine(prevX, prevYB, cx, yb, UI_WHITE);
    }

    prevX = cx;
    prevYB = yb;
  }

  display.setTextSize(1);
  display.setTextDatum(textdatum_t::top_left);
}

void drawValue(float value, int x, int y, uint16_t bg) {
  char buf[20];
  snprintf(buf, sizeof(buf), "%.1f", value);
  drawLeftText(buf, x, y, FONT_BIG, UI_WHITE, bg);
}

const char* nitrateDurumEtiketi(float ppm) {
  if (ppm < NDSC_GUVENLI_ESIK) return "GÜVENLİ";
  if (ppm < NDSC_DIKKAT_ESIK) return "DİKKAT";
  return "YÜKSEK NİTRAT";
}

uint16_t nitrateDurumRengi(float ppm) {
  if (ppm < NDSC_GUVENLI_ESIK) return UI_GREEN;
  if (ppm < NDSC_DIKKAT_ESIK) return UI_ORANGE;
  return UI_RED;
}

// sonOptikKalite (0-100) icin renk esikleri: yuksek kalite yesil,
// orta kalite turuncu, dusuk kalite (sonuca supheyle bakilmali) kirmizi.
uint16_t guvenSkoruRengi(float kalite) {
  if (kalite >= 80.0f) return UI_GREEN;
  if (kalite >= 50.0f) return UI_ORANGE;
  return UI_RED;
}

// SONUÇ kartındaki durum rozeti ile menü butonları arasındaki dar
// boşluğa (y≈284-306, ~20px) tek satır "Güven Skoru: NN/100" yazar.
// FONT_SMALL bu aralığa tam sığmadığı için (drawStatusPill'deki
// autofit mantığına benzer şekilde) 0.8 ölçekle küçültülüp
// middle_center hizalamayla dikeyde ortalanır.
void drawGuvenSkoru(int cx, int cy, float kalite, bool varMi) {
  char buf[24];
  uint16_t renk;
  if (varMi) {
    snprintf(buf, sizeof(buf), "Güven Skoru: %.0f/100", kalite);
    renk = guvenSkoruRengi(kalite);
  } else {
    snprintf(buf, sizeof(buf), "Güven Skoru: --");
    renk = UI_LINE;
  }
  display.setFont(FONT_SMALL);
  display.setTextColor(renk, UI_PANEL);
  display.setTextDatum(textdatum_t::middle_center);
  display.setTextSize(0.8f);
  display.drawString(buf, cx, cy);
  display.setTextDatum(textdatum_t::top_left);
  display.setTextSize(1);
}

// Köşeleri kesik (oktagon) kart: önce dolu dikdörtgen çizilir, sonra 4
// köşe üçgeni arka plan rengiyle "kesilir", en son kenarlık 8 kenarlı
// bir çizgi zinciri olarak çizilir. LovyanGFX'te doğrudan kesik köşeli
// dikdörtgen çizen bir fonksiyon olmadığı için bu teknik kullanılıyor.
void drawChamferKart(int x, int y, int w, int h, int kesik,
                     uint16_t fill, uint16_t border, uint16_t bg) {
  display.fillRect(x, y, w, h, fill);
  display.fillTriangle(x, y, x + kesik, y, x, y + kesik, bg);
  display.fillTriangle(x + w - kesik, y, x + w, y, x + w, y + kesik, bg);
  display.fillTriangle(x, y + h - kesik, x, y + h, x + kesik, y + h, bg);
  display.fillTriangle(x + w - kesik, y + h, x + w, y + h, x + w, y + h - kesik, bg);

  int x1 = x + kesik, x2 = x + w - kesik;
  int y1 = y + kesik, y2 = y + h - kesik;
  display.drawLine(x1, y, x2, y, border);
  display.drawLine(x2, y, x + w, y1, border);
  display.drawLine(x + w, y1, x + w, y2, border);
  display.drawLine(x + w, y2, x2, y + h, border);
  display.drawLine(x2, y + h, x1, y + h, border);
  display.drawLine(x1, y + h, x, y2, border);
  display.drawLine(x, y2, x, y1, border);
  display.drawLine(x, y1, x1, y, border);
}

// ── SONUÇ KARTI: durum bazlı renk (NORMAL/DİKKAT/YÜKSEK) ───────────
// Kartın arka planı ve kenarlığı nitrat durumuna göre koyu tonlarda
// değişir; metinler her zaman beyaz kalır (yüksek kontrast, HMI hissi).
uint16_t nitrateKartArkaPlanRengi(float ppm) {
  if (ppm < NDSC_GUVENLI_ESIK) return rgb565(10, 43, 37);   // koyu yeşil
  if (ppm < NDSC_DIKKAT_ESIK)  return rgb565(58, 38, 10);   // koyu amber
  return rgb565(58, 12, 15);                                // koyu kırmızı
}

uint16_t nitrateKartKenarRengi(float ppm) {
  if (ppm < NDSC_GUVENLI_ESIK) return rgb565(28, 88, 74);
  if (ppm < NDSC_DIKKAT_ESIK)  return rgb565(120, 80, 20);
  return rgb565(120, 30, 34);
}

// Sonuç kartı içindeki "●  |  DURUM METNİ" satırını, nokta + dikey
// ayırıcı çizgi + metin üçlüsünü yatayda ortalayarak çizer.
//
// AUTOFIT: "YÜKSEK NİTRAT" gibi uzun etiketler (ve "NUMUNE BEKLENİYOR"
// gibi daha da uzun durum metinleri) kartın iç genişliğine (maxWidth)
// taşabildiği için, metin+boşluk+ikon toplam genişliği maxWidth'i
// aşarsa önce ikon-metin boşluğu, sığmazsa metin ölçeği kademeli
// olarak küçültülür. İkonun kendi boyutu (dotR/cizgi) SABİT kalır —
// yalnızca aralarındaki boşluk ve yazı boyutu daralır. Bu sayede hiçbir
// harf kırpılmaz/taşmaz ve tek satırda kalır.
void drawSonucDurumSatiri(int cx, int cy, const char* label,
                          uint16_t bg, uint16_t color, int maxWidth) {
  const int dotR = 6;
  const int cizgiW = 2, cizgiH = 20;

  display.setFont(FONT_SMALL);

  // 1) Varsayılan: metni hafifçe küçültülmüş (0.86x) ve boşluğu biraz
  //    daraltılmış (8px) olarak dene — normal uzunluktaki etiketler
  //    ("YÜKSEK NİTRAT", "GÜVENLİ", "DİKKAT") için bu yeterlidir.
  float scale = 0.86f;
  int gap = 8;
  display.setTextSize(scale);
  int16_t textW = display.textWidth(label);
  int totalW = dotR * 2 + gap + cizgiW + gap + textW;

  // 2) Hâlâ sığmıyorsa (ör. "NUMUNE BEKLENİYOR") ölçeği ve boşluğu
  //    birlikte, ikili arama ile sığana kadar küçült (alt sınır 0.6x /
  //    4px — bunun altında okunaksız olur).
  if (totalW > maxWidth) {
    const float minScale = 0.6f;
    const int minGap = 4;
    float lo = minScale, hi = 0.86f;
    for (int i = 0; i < 12; i++) {
      float mid = (lo + hi) / 2.0f;
      display.setTextSize(mid);
      int16_t w = display.textWidth(label);
      int g = minGap + (int)((8 - minGap) * ((mid - minScale) / (0.86f - minScale)));
      int tw = dotR * 2 + g + cizgiW + g + w;
      if (tw > maxWidth) hi = mid; else lo = mid;
    }
    scale = lo;
    gap = minGap + (int)((8 - minGap) * ((scale - minScale) / (0.86f - minScale)));
    display.setTextSize(scale);
    textW = display.textWidth(label);
    totalW = dotR * 2 + gap + cizgiW + gap + textW;
  }

  int startX = cx - totalW / 2;

  display.fillCircle(startX + dotR, cy, dotR, color);
  int cizgiX = startX + dotR * 2 + gap;
  display.fillRect(cizgiX, cy - cizgiH / 2, cizgiW, cizgiH, color);

  display.setTextColor(color, bg);
  display.setTextDatum(textdatum_t::middle_left);
  display.drawString(label, cizgiX + cizgiW + gap, cy);
  display.setTextDatum(textdatum_t::top_left);
  display.setTextSize(1);
}

// ── ÖLÇÜM GÜVENİ kutusu: ortalanmış başlık + büyük yüzde + kapsül bar ──
// Bar rengi guvenSkoruRengi() ile aynı 0-100 eşiklerini kullanır, yani
// güven skoru eşikleri ileride değişirse buradaki renk de otomatik
// güncellenir (ayrı bir renk mantığı tekrar yazılmadı).
void drawOlcumGuveni(int x, int y, int w, int h, float kalite, bool varMi) {
  display.fillRoundRect(x, y, w, h, 12, UI_PANEL2);
  display.drawRoundRect(x, y, w, h, 12, UI_LINE);

  const uint16_t etiketRenk = rgb565(120, 205, 255);
  int cx = x + w / 2;

  display.setFont(FONT_SMALL);
  display.setTextSize(0.78f);
  display.setTextColor(etiketRenk, UI_PANEL2);
  display.setTextDatum(textdatum_t::top_center);
  display.drawString("ÖLÇÜM GÜVENİ", cx, y + 8);
  display.setTextSize(1);

  char yuzdeBuf[8];
  uint16_t yuzdeRenk;
  if (varMi) {
    snprintf(yuzdeBuf, sizeof(yuzdeBuf), "%.0f%%", kalite);
    yuzdeRenk = UI_WHITE;
  } else {
    snprintf(yuzdeBuf, sizeof(yuzdeBuf), "--");
    yuzdeRenk = UI_MUTED;
  }
  display.setFont(FONT_MEDIUM);
  display.setTextSize(1);
  display.setTextColor(yuzdeRenk, UI_PANEL2);
  display.setTextDatum(textdatum_t::top_center);
  display.drawString(yuzdeBuf, cx, y + 24);
  display.setTextSize(1);
  display.setTextDatum(textdatum_t::top_left);

  const int padX = 16;
  int barX = x + padX, barY = y + h - 18, barW = w - padX * 2, barH = 12;
  display.fillRoundRect(barX, barY, barW, barH, barH / 2, UI_PANEL3);
  display.drawRoundRect(barX, barY, barW, barH, barH / 2, UI_LINE);
  if (varMi) {
    int doluW = (int)(barW * (kalite / 100.0f));
    if (doluW < barH) doluW = barH;
    if (doluW > barW) doluW = barW;
    display.fillRoundRect(barX, barY, doluW, barH, barH / 2, guvenSkoruRengi(kalite));
  }
}

void drawMainScreenPaneller() {
  // ── SOL KART: tek ve büyük sonuç ─────────────────────────────
  display.fillRoundRect(18, 88, 245, 384, 14, UI_PANEL);
  display.drawRoundRect(18, 88, 245, 384, 14, UI_LINE);

  // ── SONUÇ başlığı + SONUÇ KARTI: dinamik dikey yerleşim ──────────
  // ÖNEMLİ DÜZELTME: kart, başlıktan SONRA çizildiği için eskiden
  // (başlık y=106, kart y=126) ikisi arasındaki boşluk, FONT_MEDIUM'un
  // gerçek satır yüksekliğinden dar kalıyor ve kart "SONUÇ" yazısının
  // alt kısmının üzerine biniyordu. Bunu bir daha yaşamamak için sabit
  // piksel tahmini yerine display.fontHeight() ile ÖLÇÜLEN gerçek
  // başlık yüksekliği kullanılıyor; kart başlangıcı bu ölçüme göre
  // hesaplanıyor, dolayısıyla örtüşme fiziksel olarak imkânsız.
  //
  // "ÖLÇÜM GÜVENİ" kutusunun konumu (y=238) SABİT bırakıldı — kart
  // büyütülürken yalnızca ÜST kenarı yukarı doğru genişliyor, alt
  // kenarı (ve dolayısıyla altındaki kutu/butonlar) yerinden oynamıyor.
  const int panelTop      = 88;   // SOL KART'ın üst kenarı (değişmedi)
  const int baslikPadTop  = 10;   // panel üstü -> başlık boşluğu
  const int baslikKartGap = 10;   // başlık altı -> kart üstü boşluğu
  const int guvenY        = 238;  // ÖLÇÜM GÜVENİ kutusu (SABİT, değişmedi)
  const int kartBottomGap = 4;    // kart altı -> ÖLÇÜM GÜVENİ boşluğu

  display.setFont(FONT_MEDIUM);
  const int baslikY = panelTop + baslikPadTop;
  const int baslikH = display.fontHeight();
  drawCenteredText("SONUÇ", 140, baslikY, FONT_MEDIUM, UI_WHITE, UI_PANEL);

  // ── SONUÇ KARTI (durum bazlı renk) + ÖLÇÜM GÜVENİ kutusu ─────────
  // Eski tasarımda beyaz kart + ayrı durum rozeti + sığmadığı için
  // %80'e küçültülen "Güven Skoru" satırı vardı. Yeni tasarımda kartın
  // arka planı NORMAL/DİKKAT/YÜKSEK durumuna göre koyu yeşil/amber/
  // kırmızı olur, tüm metinler beyazdır; güven skoru kendi kutusunda
  // başlık + büyük yüzde + ince bar olarak gösterilir.
  // Kart eskisine (x=32, w=217) göre biraz daha geniş (x=28, w=225)
  // yapıldı; yüksekliği (kartH) ise sabit değil, başlık ile ÖLÇÜM
  // GÜVENİ arasında kalan TÜM boşluğu kullanacak şekilde hesaplanıyor
  // — yani eski karttan her zaman en az bir miktar daha yüksek olur.
  const int kartX = 28, kartW = 225;
  const int kartY = baslikY + baslikH + baslikKartGap;
  const int kartH = (guvenY - kartBottomGap) - kartY;
  uint16_t kartBg, kartKenar;
  const char* durum;

  if (!uiHasMeasurement) {
    kartBg = UI_PANEL2;
    kartKenar = UI_LINE;
    durum = "NUMUNE BEKLENİYOR";
  } else if (durumMetin.length() > 0) {
    // Özel durum metni (ör. hata) her zaman kırmızı kart ile gösterilir.
    kartBg = nitrateKartArkaPlanRengi(9999.0f);
    kartKenar = nitrateKartKenarRengi(9999.0f);
    durum = durumMetin.c_str();
  } else {
    kartBg = nitrateKartArkaPlanRengi(uiLastNitrate);
    kartKenar = nitrateKartKenarRengi(uiLastNitrate);
    durum = nitrateDurumEtiketi(uiLastNitrate);
  }

  drawChamferKart(kartX, kartY, kartW, kartH, 16, kartBg, kartKenar, UI_PANEL);

  // Kart içi dikey yerleşim: değer üstte sabit bir boşlukla, durum
  // satırı (ve ayırıcı çizgi) kartın ALT kenarına göre sabit bir
  // boşlukla konumlanıyor. Böylece kart büyüdükçe kazanılan fazladan
  // boşluk, "79.7 / ppm" ile durum satırı arasında ferah bir ara
  // boşluk olarak kendiliğinden oluşuyor (madde 9: net hiyerarşi).
  const int kartBottom = kartY + kartH;
  const int valueY = kartY + 10;
  const int ppmY   = valueY + 58;
  const int durumY = kartBottom - 16;
  const int hlineY = durumY - 20;

  char sonucBuf[20];
  snprintf(sonucBuf, sizeof(sonucBuf), "%.1f", uiHasMeasurement ? uiLastNitrate : 0.0f);
  drawCenteredValueBold(sonucBuf, 140, valueY, FONT_BIG, UI_WHITE, kartBg);
  drawCenteredText("ppm", 140, ppmY, FONT_SMALL, UI_WHITE, kartBg);
  display.drawFastHLine(kartX + 16, hlineY, kartW - 32, kartKenar);
  drawSonucDurumSatiri(140, durumY, durum, kartBg, UI_WHITE, kartW - 32);

  // sonOptikKalite, en son ölçümle (uiLastNitrate) birlikte, aynı anda
  // güncellenen 0-100 arası bir optik güven puanıdır (bkz. NDSC ölçüm
  // akışı). Bar rengi guvenSkoruRengi() ile otomatik yeşil/turuncu/
  // kırmızı arasında değişir.
  drawOlcumGuveni(32, 238, 217, 62, sonOptikKalite, uiHasMeasurement);

  // Sol menü: tüm butonlar aynı yükseklikte ve aralarındaki boşluk eşit.
  // Yükseklik 34 px, her iki buton arası 6 px.
  drawFuturisticMenuButton(32, 306, 217, 34, "Yazdır",         ICON_PRINTER,  UI_CYAN);
  drawFuturisticMenuButton(32, 346, 217, 34, "Harita",         ICON_LOCATION, UI_CYAN);
  drawFuturisticMenuButton(32, 386, 217, 34, "Buluta Gönder",  ICON_CLOUD,    UI_CYAN);
  drawFuturisticMenuButton(32, 426, 217, 34, "Ayarlar",        ICON_GEAR,     UI_CYAN);

  // ── SAĞ KART: tekrar eden nitrat başlığı/değeri tamamen kaldırıldı ──
  // Kazanılan alan doğrudan mevcut spektral grafiğe verilir.
  display.fillRoundRect(282, 88, 500, 384, 14, UI_PANEL);
  display.drawRoundRect(282, 88, 500, 384, 14, UI_LINE);

  // Grafik önceki tasarımdaki güzel spektral dolgu/renk yapısını korur,
  // yalnızca daha geniş ve daha akademik eksenlerle çizilir.
  // Panel içinde sola ve aşağı (buton üstüne kadar) tam oturacak şekilde
  // büyütüldü: sol/sağ boşluk daraltıldı, alt kenar "ÖLÇÜMÜ BAŞLAT"
  // butonunun hemen üstüne kadar uzatıldı.
  drawSpectrumGraph(286, 90, 490, 306);

  // Modern ▶ ÖLÇÜMÜ BAŞLAT butonu.
  // Panel 12px büyüdüğü için buton da 8px aşağı kaydırıldı, boyutu aynı.
  drawOlcumuBaslatButonu(304, 400, 456, 58);

  uiDrawn = true;
}

void drawMainScreen() {
  display.fillScreen(UI_BG);
  drawHeader("ÖLÇÜM");
  drawMainScreenPaneller();

  // Ana ekran tamamen çizildikten sonra NVS yazımı için 2.5 saniye bekle.
  // Bu yalnızca bir bayrak/zaman damgasıdır; burada flash yazımı yapılmaz
  // ve ekrana ek çizim yapılmaz.
  if (uiHasMeasurement) {
    pendingLocalSave = true;
    pendingLocalSaveAt = millis() + 2500UL;
  }
}

void drawSplash() {
  display.fillScreen(UI_BG);

  // Panel yuksekligi GPS satiri icin 372 olarak korundu.
  display.fillRoundRect(105, 70, 590, 372, 20, UI_PANEL);
  display.drawRoundRect(105, 70, 590, 372, 20, UI_CYAN);

  drawCenteredText("NitraCheck", 400, 105, FONT_BIG, UI_CYAN, UI_PANEL);
  drawCenteredText("GÜÇLÜ SU ANALİZ SİSTEMİ", 400, 148,
                   FONT_SMALL, UI_WHITE, UI_PANEL);
  drawCenteredText("SYSTEM CHECK", 400, 190, FONT_MEDIUM, UI_WHITE, UI_PANEL);

  drawLeftText("DISPLAY", 180, 238, FONT_SMALL,
               UI_GREEN, UI_PANEL);
  drawIcon(ICON_CHECK, 645, 247, UI_GREEN);

  drawLeftText("AS7341", 180, 270, FONT_SMALL,
               as7341TaramaBulundu ? UI_GREEN : UI_RED, UI_PANEL);
  if (as7341TaramaBulundu) drawIcon(ICON_CHECK, 645, 279, UI_GREEN);

  char gpsSplash[64];
  if (gpsKonumGecerli)
    snprintf(gpsSplash, sizeof(gpsSplash), "GPS %.2f, %.2f", gpsEnlem, gpsBoylam);
  else
    snprintf(gpsSplash, sizeof(gpsSplash), "%s", gpsDurumMetni());
  drawLeftText(gpsSplash, 180, 302, FONT_SMALL,
               gpsKonumGecerli ? UI_CYAN : UI_ORANGE, UI_PANEL);

  drawLeftText("WİFİ", 180, 334, FONT_SMALL,
               WiFi.status() == WL_CONNECTED ? UI_GREEN : UI_ORANGE, UI_PANEL);
  if (WiFi.status() == WL_CONNECTED) drawIcon(ICON_CHECK, 645, 343, UI_GREEN);

  drawLeftText("FIREBASE", 180, 366, FONT_SMALL,
               firebaseHazir ? UI_GREEN : UI_ORANGE, UI_PANEL);
  if (firebaseHazir) drawIcon(ICON_CHECK, 645, 375, UI_GREEN);

  drawCenteredText("Sistem hazırlanıyor...", 400, 396,
                   FONT_SMALL, UI_MUTED, UI_PANEL);

  uiDrawn = true;
}


// ─── WIFI UI YARDIMCILARI ──────────────────────────────────────

void wifiSatirRect(int gosterilenSatir, int &bx, int &by, int &bw, int &bh) {
  // Liste ekrani ve dokunmatik ayni koordinat kaynagini kullanir.
  bx = 60;
  by = 126 + gosterilenSatir * 47;
  bw = 620;
  bh = 40;
}

void wifiOkRect(bool yukari, int &bx, int &by, int &bw, int &bh) {
  bx = 700;
  by = yukari ? 170 : 230;
  bw = 40;
  bh = 44;
}

void wifiListeButonRect(bool tekrarTara, int &bx, int &by, int &bw, int &bh) {
  // Alt satır: TEKRAR TARA | AĞI UNUT | GERİ
  if (tekrarTara) {
    bx = 70; by = 420; bw = 210; bh = 40;
  } else {
    bx = 520; by = 420; bw = 210; bh = 40;
  }
}

void wifiAgUnutButonRect(int &bx, int &by, int &bw, int &bh) {
  bx = 295; by = 420; bw = 210; bh = 40;
}

void wifiKeyboardKeyRect(int idx, int &bx, int &by, int &bw, int &bh) {
  // Ekranin alt yarisi: 4 satir telefon tarzi klavye.
  const int topY = 260;
  const int rowH = 43;
  const int gap = 6;

  if (idx < 10) {
    bw = 66; bh = 38;
    bx = 42 + idx * (bw + gap);
    by = topY;
  } else if (idx < 19) {
    bw = 66; bh = 38;
    bx = 74 + (idx - 10) * (bw + gap);
    by = topY + rowH;
  } else if (idx < 28) {
    // 19 = SHIFT, 20..26 = z..m, 27 = SİL
    if (idx == 19) {
      bx = 38; by = topY + 2 * rowH; bw = 72; bh = 38;
    } else if (idx < 27) {
      bw = 62; bh = 38;
      bx = 116 + (idx - 20) * (bw + gap);
      by = topY + 2 * rowH;
    } else {
      bx = 636; by = topY + 2 * rowH; bw = 122; bh = 38;
    }
  } else {
    // 28 = 123/ABC, 29 = BOŞLUK, 30 = BAĞLAN
    if (idx == 28) {
      bx = 42; by = topY + 3 * rowH; bw = 100; bh = 38;
    } else if (idx == 29) {
      bx = 148; by = topY + 3 * rowH; bw = 300; bh = 38;
    } else {
      bx = 454; by = topY + 3 * rowH; bw = 304; bh = 38;
    }
  }
}

const char* wifiKlavyeTusEtiketi(int idx) {
  static const char* harfler1[10] = {"q","w","e","r","t","y","u","i","o","p"};
  static const char* harfler2[9]  = {"a","s","d","f","g","h","j","k","l"};
  static const char* harfler3[7]  = {"z","x","c","v","b","n","m"};
  // WiFi sifrelerinde sik kullanilan ASCII karakterleri de dahil.
  // 27 tus kapasitesi nedeniyle yaygin karakterler onceliklidir.
  static const char* sayilar[27] = {
    "1","2","3","4","5","6","7","8","9","0",
    "!","@","#","$","%",".","&","*","(",")",
    "-","_",":","=","+","/","?"
  };

  if (wifiKlavyeSayiModu) {
    if (idx < 27) return sayilar[idx];
    if (idx == 27) return "sil";
    if (idx == 28) return "abc";
    if (idx == 29) return "boşluk";
    return "bağlan";
  }

  if (idx < 10) return harfler1[idx];
  if (idx < 19) return harfler2[idx - 10];
  if (idx == 19) return "shift";
  if (idx < 27) return harfler3[idx - 20];
  if (idx == 27) return "sil";
  if (idx == 28) return "123";
  if (idx == 29) return "boşluk";
  return "bağlan";
}

void drawWifiSignalIcon(int x, int y, int rssi, uint16_t color) {
  int seviye = 1;
  if (rssi > -55) seviye = 4;
  else if (rssi > -70) seviye = 3;
  else if (rssi > -85) seviye = 2;

  for (int i = 0; i < 4; i++) {
    int h = 5 + i * 5;
    int bx = x + i * 7;
    int by = y + 18 - h;
    if (i < seviye) display.fillRoundRect(bx, by, 5, h, 2, color);
    else display.drawRoundRect(bx, by, 5, h, 2, UI_LINE);
  }
}

void drawWifiLockIcon(int cx, int cy, uint16_t color) {
  display.drawRoundRect(cx - 7, cy - 1, 14, 11, 2, color);
  display.drawArc(cx, cy - 1, 7, 5, 180, 360, color);
  display.fillCircle(cx, cy + 4, 2, color);
}

void wifiTaramaSonucunuIsle(int adet) {
  wifiTaramaSayisi = 0;
  wifiListeKaydirma = 0;
  wifiTaniSonKod = adet;

  if (adet <= 0) {
    Serial.printf("[WiFi] Tarama sonuc vermedi: %d\n", adet);
    WiFi.scanDelete();
    wifiTaraniyor = false;
    if (currentScreen == SCREEN_WIFI_LIST) drawWifiListScreen();
    return;
  }

  for (int i = 0; i < adet; i++) {
    String ssid = WiFi.SSID(i);
    if (ssid.length() == 0) continue;

    int mevcut = -1;
    for (int j = 0; j < wifiTaramaSayisi; j++) {
      if (wifiTaramaSSID[j] == ssid) { mevcut = j; break; }
    }

    int rssi = WiFi.RSSI(i);
    bool acik = (WiFi.encryptionType(i) == WIFI_AUTH_OPEN);
    if (mevcut >= 0) {
      if (rssi > wifiTaramaRSSI[mevcut]) {
        wifiTaramaRSSI[mevcut] = rssi;
        wifiTaramaAcik[mevcut] = acik;
      }
    } else if (wifiTaramaSayisi < WIFI_TARAMA_MAKS) {
      wifiTaramaSSID[wifiTaramaSayisi] = ssid;
      wifiTaramaRSSI[wifiTaramaSayisi] = rssi;
      wifiTaramaAcik[wifiTaramaSayisi] = acik;
      wifiTaramaSayisi++;
    }
  }

  for (int i = 0; i < wifiTaramaSayisi - 1; i++) {
    for (int j = i + 1; j < wifiTaramaSayisi; j++) {
      if (wifiTaramaRSSI[j] > wifiTaramaRSSI[i]) {
        String ssidTmp = wifiTaramaSSID[i]; wifiTaramaSSID[i] = wifiTaramaSSID[j]; wifiTaramaSSID[j] = ssidTmp;
        int rssiTmp = wifiTaramaRSSI[i]; wifiTaramaRSSI[i] = wifiTaramaRSSI[j]; wifiTaramaRSSI[j] = rssiTmp;
        bool acikTmp = wifiTaramaAcik[i]; wifiTaramaAcik[i] = wifiTaramaAcik[j]; wifiTaramaAcik[j] = acikTmp;
      }
    }
  }

  WiFi.scanDelete();
  wifiTaraniyor = false;
  Serial.printf("[WiFi] Listeye eklenen ag sayisi: %d\n", wifiTaramaSayisi);
  if (currentScreen == SCREEN_WIFI_LIST) drawWifiListScreen();
}

void wifiAglariTara() {
  wifiTaramaSayisi = 0;
  wifiListeKaydirma = 0;
  wifiTaniMod = (int)WiFi.getMode();
  wifiTaniDurum = (int)WiFi.status();
  wifiTaniDeneme = 1;
  wifiTaniSonKod = WIFI_SCAN_RUNNING;

  // Tarama artik dokunmatik olayinin icinde bekletilmez. Mevcut baglanti
  // NVS'den silinmez; kullanici AĞI UNUT demedikce kayıt korunur.
  int onceki = WiFi.scanComplete();
  if (onceki == WIFI_SCAN_RUNNING) {
    WiFi.scanDelete();
  } else if (onceki >= 0 || onceki == WIFI_SCAN_FAILED) {
    WiFi.scanDelete();
  }
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  wifiTaraniyor = true;
  wifiTaramaBaslangic = millis();
  int ret = WiFi.scanNetworks(true, true);
  if (ret < 0 && ret != WIFI_SCAN_RUNNING) {
    wifiTaniSonKod = ret;
    wifiTaraniyor = false;
    Serial.printf("[WiFi] Asenkron tarama baslatilamadi: %d\n", ret);
  }
}

void wifiTaramaGuncelle() {
  if (!wifiTaraniyor) return;
  int adet = WiFi.scanComplete();
  if (adet == WIFI_SCAN_RUNNING) {
    if (millis() - wifiTaramaBaslangic > 12000UL) {
      wifiTaniSonKod = WIFI_SCAN_FAILED;
      WiFi.scanDelete();
      wifiTaraniyor = false;
      Serial.println("[WiFi] Tarama zaman asimi.");
      if (currentScreen == SCREEN_WIFI_LIST) drawWifiListScreen();
    }
    return;
  }
  wifiTaramaSonucunuIsle(adet);
}

void drawWifiListScreen() {
  display.fillScreen(UI_BG);
  drawHeader("WİFİ AĞLARI");

  int px = 30, py = 84, pw = 740, ph = 380;
  display.fillRoundRect(px, py, pw, ph, 14, UI_PANEL);
  display.drawRoundRect(px, py, pw, ph, 14, UI_LINE);

  if (wifiTaraniyor) {
    drawCenteredText("Ağlar taranıyor...", 400, 190, FONT_MEDIUM, UI_WHITE, UI_PANEL);
    drawCenteredText("Tarama sırasında ekran kilitlenmez.", 400, 230, FONT_SMALL, UI_MUTED, UI_PANEL);
    drawCenteredText("İsterseniz taramayı iptal edip geri dönebilirsiniz.", 400, 258, FONT_SMALL, UI_MUTED, UI_PANEL);

    int bx, by, bw, bh;
    wifiListeButonRect(false, bx, by, bw, bh);
    drawButton(bx, by, bw, bh, "iptal / geri", UI_CYAN);
    return;
  }

  if (wifiTaramaSayisi == 0) {
    drawCenteredText("Ağ bulunamadı", 400, 185, FONT_MEDIUM, UI_WHITE, UI_PANEL);
    drawCenteredText("WiFi ağlarını yeniden tarayabilirsiniz.", 400, 225,
                     FONT_SMALL, UI_MUTED, UI_PANEL);

    // Serial Monitor kullanılamadığında bile radyonun durumunu görebilmek
    // için ekrana tanı bilgisi bas: mod / durum / son deneme kodu.
    char tani[80];
    snprintf(tani, sizeof(tani), "Tanı: mod=%d durum=%d kod=%d deneme=%d",
             wifiTaniMod, wifiTaniDurum, wifiTaniSonKod, wifiTaniDeneme);
    drawCenteredText(tani, 400, 255, FONT_SMALL, UI_ORANGE, UI_PANEL);

    int bx, by, bw, bh;
    wifiListeButonRect(true, bx, by, bw, bh);
    drawButton(bx, by, bw, bh, "tekrar tara", UI_CYAN, ICON_NONE, true);

    wifiAgUnutButonRect(bx, by, bw, bh);
    drawButton(bx, by, bw, bh, "ağı unut", UI_ORANGE);

    wifiListeButonRect(false, bx, by, bw, bh);
    drawButton(bx, by, bw, bh, "geri", UI_CYAN);
    return;
  }

  int gorunen = wifiTaramaSayisi > 6 ? 6 : wifiTaramaSayisi;
  if (wifiListeKaydirma > wifiTaramaSayisi - gorunen)
    wifiListeKaydirma = max(0, wifiTaramaSayisi - gorunen);

  for (int satir = 0; satir < gorunen; satir++) {
    int idx = wifiListeKaydirma + satir;
    int bx, by, bw, bh;
    wifiSatirRect(satir, bx, by, bw, bh);

    bool bagli = (WiFi.status() == WL_CONNECTED &&
                  WiFi.SSID() == wifiTaramaSSID[idx]);

    uint16_t kenar = bagli ? UI_GREEN : UI_LINE;
    uint16_t dolgu = bagli ? UI_PANEL3 : UI_PANEL2;

    display.fillRoundRect(bx, by, bw, bh, 8, dolgu);
    display.drawRoundRect(bx, by, bw, bh, 8, kenar);

    String etiket = wifiTaramaSSID[idx];
    if (etiket.length() > 28) etiket = etiket.substring(0, 28) + "...";
    drawLeftText(etiket.c_str(), bx + 16, by + 10,
                 FONT_SMALL, UI_WHITE, dolgu);

    drawWifiSignalIcon(bx + bw - 74, by + 9, wifiTaramaRSSI[idx],
                       bagli ? UI_GREEN : UI_CYAN);

    if (!wifiTaramaAcik[idx])
      drawWifiLockIcon(bx + bw - 22, by + 20, UI_ORANGE);

    if (bagli)
      drawIcon(ICON_CHECK, bx + bw - 100, by + 20, UI_GREEN);
  }

  if (wifiTaramaSayisi > 6) {
    int bx, by, bw, bh;
    wifiOkRect(true, bx, by, bw, bh);
    drawButton(bx, by, bw, bh, "^", UI_CYAN, ICON_NONE, false);
    wifiOkRect(false, bx, by, bw, bh);
    drawButton(bx, by, bw, bh, "v", UI_CYAN, ICON_NONE, false);
  }

  int bx, by, bw, bh;
  wifiListeButonRect(true, bx, by, bw, bh);
  drawButton(bx, by, bw, bh, "tekrar tara", UI_CYAN, ICON_NONE, true);

  wifiAgUnutButonRect(bx, by, bw, bh);
  drawButton(bx, by, bw, bh, "ağı unut", UI_ORANGE);

  wifiListeButonRect(false, bx, by, bw, bh);
  drawButton(bx, by, bw, bh, "geri", UI_CYAN);
}

void drawWifiConnecting(int percent, const char* status) {
  if (percent < 0) percent = 0;
  if (percent > 100) percent = 100;

  display.fillScreen(UI_BG);
  drawHeader("WİFİ BAĞLANTISI");

  int px = 70, py = 90, pw = 660, ph = 300;
  display.fillRoundRect(px, py, pw, ph, 14, UI_PANEL);
  display.drawRoundRect(px, py, pw, ph, 14, UI_LINE);

  int cx = px + pw / 2;
  int cy = py + 118;

  display.drawArc(cx, cy, 55, 39, 0, 360, UI_LINE);
  if (percent > 0)
    display.drawArc(cx, cy, 55, 39, -90,
                    -90 + (360 * percent / 100), UI_CYAN);

  char pctBuf[8];
  snprintf(pctBuf, sizeof(pctBuf), "%%%d", percent);
  drawCenteredText(pctBuf, cx, cy - 16, FONT_MEDIUM, UI_WHITE, UI_PANEL);

  String ssidBaslik = wifiSecilenSSID;
  if (ssidBaslik.length() > 32)
    ssidBaslik = ssidBaslik.substring(0, 32) + "...";

  drawCenteredText(ssidBaslik.c_str(), cx, py + 190,
                   FONT_SMALL, UI_WHITE, UI_PANEL);
  drawCenteredText(status, cx, py + 226,
                   FONT_SMALL, UI_MUTED, UI_PANEL);
}

void wifiBaglantiDene(const char* ssid, const char* sifre) {
  wifiBaglaniyor = true;
  wifiBaglantiHatasi = false;
  olcumKilitli = true;

  // Olay dinleyici sadece bir kez kaydedilsin; WiFi.onEvent aynı fonksiyonu
  // tekrar eklemeye izin verir ama gereksiz, bu yüzden statik bayrakla koruyoruz.
  static bool wifiOlayKayitli = false;
  if (!wifiOlayKayitli) {
    WiFi.onEvent(wifiOlayIsleyici, ARDUINO_EVENT_WIFI_STA_DISCONNECTED);
    wifiOlayKayitli = true;
  }
  sonWifiKopmaSebebi = 0;

  drawWifiConnecting(0, "Bağlanılıyor...");

  // Art arda disconnect()->begin() cagrilarinda ESP32 WiFi surucusu bazen
  // yeni baglanma denemesini hic baslatmadan (tek bir probe/olay uretmeden)
  // sessizce takilip kalabiliyor. Radyoyu tam kapatip acmak bu durumu
  // guvenilir sekilde sifirliyor.
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);
  delay(200);
  WiFi.mode(WIFI_STA);
  // KAL-NVS TANI: setup()'ta bir kez ayarlanan WiFi.persistent(false)
  // burada da tekrarlanıyor; WIFI_OFF->WIFI_STA döngüsünden sonra sürücü
  // bu bayrağı sıfırlarsa, WiFi kimlik bilgileri yine kalibrasyonla ayni
  // paylasilan NVS partisyonuna yazılıp fragmentasyona katkida bulunabilir.
  WiFi.persistent(false);
  delay(200);
  WiFi.begin(ssid, sifre);

  unsigned long baslangic = millis();
  unsigned long sonCizim = 0;

  while (WiFi.status() != WL_CONNECTED &&
         millis() - baslangic < 15000) {
    vTaskDelay(pdMS_TO_TICKS(200));

    unsigned long gecen = millis() - baslangic;
    int yuzde = (int)((gecen * 100UL) / 15000UL);
    if (yuzde > 95) yuzde = 95;

    if (millis() - sonCizim >= 200) {
      drawWifiConnecting(yuzde, "Bağlanılıyor...");
      sonCizim = millis();
    }
  }

  bool basarili = (WiFi.status() == WL_CONNECTED);

  if (basarili) {
    wifiPrefs.putString("ssid", wifiSecilenSSID);
    wifiPrefs.putString("pass", wifiSifreGirisi);

    drawWifiConnecting(100, "Saat ve bulut güncelleniyor...");
    wifiSonrasiServisleriBaslat();

    drawWifiConnecting(100, "BAĞLANDI");
    delay(700);

    wifiBaglantiHatasi = false;
    wifiBaglaniyor = false;
    olcumKilitli = false;

    currentScreen = SCREEN_SETTINGS;
    drawSimplePage(currentScreen);
    return;
  }

  wifiBaglantiHatasi = true;
  wifiBaglaniyor = false;
  olcumKilitli = false;

  Serial.printf("[WiFi] Baglanti basarisiz. ssid='%s' sifreUzunluk=%d status=%d kopmaSebebi=%d (%s)\n",
                ssid, (int)strlen(sifre),
                (int)WiFi.status(), (int)sonWifiKopmaSebebi,
                wifiKopmaSebebiMetni(sonWifiKopmaSebebi));

  drawWifiConnecting(100, "BAĞLANTI BAŞARISIZ");
  delay(500);

  currentScreen = SCREEN_WIFI_KEYBOARD;
  drawWifiKeyboardScreen();
}

void drawWifiKeyboardScreen() {
  display.fillScreen(UI_BG);
  drawHeader("WİFİ ŞİFRESİ");

  int px = 30, py = 84, pw = 740;
  display.fillRoundRect(px, py, pw, 160, 14, UI_PANEL);
  display.drawRoundRect(px, py, pw, 160, 14, UI_LINE);

  String baslik = "Şifre: " + wifiSecilenSSID;
  if (baslik.length() > 62)
    baslik = baslik.substring(0, 62) + "...";
  drawLeftText(baslik.c_str(), px + 20, py + 16,
               FONT_SMALL, UI_WHITE, UI_PANEL);

  int kutuX = px + 20, kutuY = py + 55, kutuW = 680, kutuH = 48;
  display.fillRoundRect(kutuX, kutuY, kutuW, kutuH, 8, UI_PANEL2);
  display.drawRoundRect(kutuX, kutuY, kutuW, kutuH, 8,
                        wifiBaglantiHatasi ? UI_RED : UI_CYAN);

  String gorunen = wifiSifreGirisi;
  if (!wifiSifreGoster) {
    gorunen = "";
    for (size_t i = 0; i < wifiSifreGirisi.length(); i++)
      gorunen += "•";
  }
  if (gorunen.length() > 42)
    gorunen = gorunen.substring(gorunen.length() - 42);

  drawLeftText(gorunen.c_str(), kutuX + 14, kutuY + 12,
               FONT_SMALL, UI_WHITE, UI_PANEL2);

  // Goz ikonu / butonu
  int gozX = kutuX + kutuW - 54;
  int gozY = kutuY + 24;
  display.drawEllipse(gozX, gozY, 15, 9, UI_CYAN);
  display.fillCircle(gozX, gozY, 4, UI_CYAN);

  if (wifiBaglantiHatasi) {
    char hataBuf[80];
    if (wifiSecilenSSID.length() == 0) {
      // Bu durum, ekrana gelen ağ adı hiç ayarlanmadan (örn. "ağı unut"
      // sonrası listeye dönmeden) şifre girilmeye çalışıldığını gösterir.
      snprintf(hataBuf, sizeof(hataBuf),
               "HATA: AG ADI BOS! Listeden agi tekrar secin");
    } else if (sonWifiKopmaSebebi != 0) {
      snprintf(hataBuf, sizeof(hataBuf), "BAŞARISIZ: %s (kod %d)",
               wifiKopmaSebebiMetni(sonWifiKopmaSebebi),
               (int)sonWifiKopmaSebebi);
    } else {
      // Kopma olayı hiç tetiklenmediyse (ör. AP hiç yanıt vermedi / SSID
      // bulunamadı) muhtemelen zaman aşımı veya ağ görünmüyor demektir.
      snprintf(hataBuf, sizeof(hataBuf),
               "BAŞARISIZ: yanıt yok (zaman aşımı / ağ bulunamadı)");
    }
    drawCenteredText(hataBuf, 400, 203, FONT_SMALL, UI_RED, UI_PANEL);
  }

  // Klavye
  for (int i = 0; i < 31; i++) {
    int bx, by, bw, bh;
    wifiKeyboardKeyRect(i, bx, by, bw, bh);

    uint16_t accent = UI_CYAN;
    if (i == 19 || i == 27 || i == 28) accent = UI_ORANGE;
    if (i == 30) accent = UI_GREEN;

    bool dolu = (i == 30);
    String etiket = wifiKlavyeTusEtiketi(i);

    if (!wifiKlavyeSayiModu && i < 28 && i != 27) {
      if (wifiKlavyeShift && etiket.length() == 1)
        etiket.toUpperCase();
    }

    drawButton(bx, by, bw, bh, etiket.c_str(), accent, ICON_NONE, dolu);
  }

  drawButton(300, 440, 200, 34, "geri", UI_CYAN);
}

// ADIM17-FIX: SCREEN_WIFI_KEYBOARD için dokunma işleyicisi eksikti; bu
// yüzden klavyedeki hiçbir tuş (harf/rakam/SİL/BAĞLAN/GERİ) tepki
// vermiyordu. Aynı koordinatlar wifiKeyboardKeyRect() ile drawWifiKeyboardScreen()
// tarafından da kullanılıyor; tek kaynak burasıdır.
void uiHandleWifiKeyboardTouch(int32_t tx, int32_t ty) {
  // GERİ -> WiFi listesine dön.
  if (tx >= 300 && tx <= 500 && ty >= 440 && ty <= 474) {
    wifiBaglantiHatasi = false;
    currentScreen = SCREEN_WIFI_LIST;
    drawWifiListScreen();
    return;
  }

  // Göz ikonu: şifreyi göster/gizle. drawWifiKeyboardScreen() ile aynı
  // px/py/kutuX/kutuY hesaplaması kullanılıyor.
  int px = 30, py = 84;
  int kutuX = px + 20, kutuY = py + 55, kutuW = 680;
  int gozX = kutuX + kutuW - 54;
  int gozY = kutuY + 24;
  if (tx >= gozX - 18 && tx <= gozX + 18 && ty >= gozY - 16 && ty <= gozY + 16) {
    wifiSifreGoster = !wifiSifreGoster;
    drawWifiKeyboardScreen();
    return;
  }

  for (int i = 0; i < 31; i++) {
    int bx, by, bw, bh;
    wifiKeyboardKeyRect(i, bx, by, bw, bh);
    if (tx < bx || tx > bx + bw || ty < by || ty > by + bh) continue;

    if (i == 30) {
      // BAĞLAN
      wifiBaglantiDene(wifiSecilenSSID.c_str(), wifiSifreGirisi.c_str());
      return;
    }

    if (i == 29) {
      // BOŞLUK
      wifiSifreGirisi += " ";
      drawWifiKeyboardScreen();
      return;
    }

    if (i == 28) {
      // 123 <-> ABC
      wifiKlavyeSayiModu = !wifiKlavyeSayiModu;
      drawWifiKeyboardScreen();
      return;
    }

    if (i == 27) {
      // SİL
      if (wifiSifreGirisi.length() > 0) {
        wifiSifreGirisi.remove(wifiSifreGirisi.length() - 1);
      }
      drawWifiKeyboardScreen();
      return;
    }

    if (!wifiKlavyeSayiModu && i == 19) {
      // SHIFT
      wifiKlavyeShift = !wifiKlavyeShift;
      drawWifiKeyboardScreen();
      return;
    }

    String etiket = wifiKlavyeTusEtiketi(i);
    if (!wifiKlavyeSayiModu && i < 28 && i != 27 && wifiKlavyeShift &&
        etiket.length() == 1) {
      etiket.toUpperCase();
    }
    if (etiket.length() == 1) {
      wifiSifreGirisi += etiket;
    }
    drawWifiKeyboardScreen();
    return;
  }
}

// ─── TAKIM SAYFASI: TEKNOFEST / #MİLLİ TEKNOLOJİ HAMLESİ / NITRACHECK
// LOGOLARI ──────────────────────────────────────────────────────────
// İSTEK ÜZERİNE: döngülü (sırayla perde-açılımlı) logo gösterimi
// kaldırıldı; üç logo artık eskisi gibi YAN YANA, SABİT olarak aynı
// anda gösteriliyor. Her logo kendi doğal en-boy oranıyla, ortak bir
// yükseklik hedefine (TAKIM_LOGO_HEDEF_H) göre ölçeklenir.
struct TeamLogoAsset {
  const uint8_t* png;
  uint32_t len;
  int w;
  int h;
};

static const TeamLogoAsset TAKIM_LOGO_DIZISI[3] = {
  { teknofestMainLogoPng,   teknofestMainLogoPngLen,   TEKNOFEST_MAIN_LOGO_W,   TEKNOFEST_MAIN_LOGO_H },
  { milliTeknolojiLogoPng,  milliTeknolojiLogoPngLen,  MILLI_TEKNOLOJI_LOGO_W,  MILLI_TEKNOLOJI_LOGO_H },
  { nitraCheckMainLogoPng,  nitraCheckMainLogoPngLen,  NITRACHECK_MAIN_LOGO_W,  NITRACHECK_MAIN_LOGO_H },
};

// NOT: TAKIM ekranında ayırıcı çizgi y=300'de, "geri" butonu y=406'da
// başlıyor; logo şeridi bu ikisinin arasına ortalanmıştır.
const int TAKIM_LOGO_SERIT_CY = 353;
const int TAKIM_LOGO_HEDEF_H  = 64;  // her logonun ölçekleneceği ortak yükseklik
const int TAKIM_LOGO_ARALIK   = 34;  // logolar arasındaki yatay boşluk

// Üç logoyu, ortak bir yükseklik hedefine göre ölçekleyip yan yana,
// yatayda ortalanmış şekilde tek seferde çizer. Döngü/animasyon yok.
void drawTakimLogoSeridi() {
  float scl[3];
  int w[3];
  int toplamGenislik = 0;
  for (int i = 0; i < 3; i++) {
    const TeamLogoAsset& a = TAKIM_LOGO_DIZISI[i];
    scl[i] = (float)TAKIM_LOGO_HEDEF_H / (float)a.h;
    w[i] = (int)(a.w * scl[i]);
    toplamGenislik += w[i];
  }
  toplamGenislik += TAKIM_LOGO_ARALIK * 2;

  int x = 400 - toplamGenislik / 2;
  int y = TAKIM_LOGO_SERIT_CY - TAKIM_LOGO_HEDEF_H / 2;

  for (int i = 0; i < 3; i++) {
    const TeamLogoAsset& a = TAKIM_LOGO_DIZISI[i];
    display.drawPng(a.png, a.len, x, y, 0, 0, 0, 0, scl[i], scl[i]);
    x += w[i] + TAKIM_LOGO_ARALIK;
  }
}

void drawSimplePage(NitraScreen page) {
  display.fillScreen(UI_BG);

  if (page == SCREEN_MAP) {
    drawHeader("HARİTA");

    const int panelX = 18;
    const int panelY = 82;
    const int panelW = HARITA_PANEL_W;
    const int panelH = HARITA_PANEL_H;
    const int mapX = panelX + 2;
    const int mapY = panelY + 2;
    const int mapW = panelW - 4;
    const int mapH = panelH - 4;

    display.fillRoundRect(panelX, panelY, panelW, panelH, 14, UI_PANEL);
    display.drawRoundRect(panelX, panelY, panelW, panelH, 14, UI_LINE);

    bool haritaOK = geoapifyHaritayiYukle(mapW, mapH);
    if (haritaOK) {
      display.drawPng(geoapifyHaritaPng, geoapifyHaritaPngLen,
                      mapX, mapY, 0, 0, 0, 0, 1.0f, 1.0f);

      int gosterilen = 0;
      for (int i = 0; i < haritaNoktaSayisi; ++i) {
        if (!firebaseHaritaNoktalari[i].gecerli) continue;
        int px = 0, py = 0;
        if (!haritaKoordinatindanPiksele(firebaseHaritaNoktalari[i].lat,
                                         firebaseHaritaNoktalari[i].lon,
                                         mapX, mapY, mapW, mapH, px, py)) continue;
        // Risk durumuna göre renkli işaretçi:
        // YESIL = normal, SARI = yuksek, KIRMIZI = tehlike.
        uint16_t noktaRengi = haritaNoktaRengi(firebaseHaritaNoktalari[i].ppm);
        // Renkli nokta net görünsün: koyu gölge + parlak renkli halka + dolu merkez.
        display.fillCircle(px + 1, py + 1, 10, UI_BG);
        display.fillCircle(px, py, 10, noktaRengi);
        display.drawCircle(px, py, 10, UI_WHITE);
        display.fillCircle(px, py, 5, UI_WHITE);
        display.fillCircle(px, py, 3, noktaRengi);
        ++gosterilen;
      }

      char bilgi[64];
      snprintf(bilgi, sizeof(bilgi), "%d gerçek ölçüm noktası", gosterilen);
      display.fillRoundRect(28, 418, 240, 38, 10, UI_PANEL2);
      drawLeftText(bilgi, 40, 428, FONT_SMALL, UI_WHITE, UI_PANEL2);

      // Harita altındaki renk açıklaması hafifçe sağa kaydırıldı: eski
      // konumda (245) DÜŞÜK dairesi/yazısı, solundaki "N gerçek ölçüm
      // noktası" bilgi kutusunun (x=28, genişlik=240 -> sağ kenarı x=268)
      // ÜSTÜNE biniyordu. Grup artık o kutunun tamamen sağında başlıyor;
      // sağdaki YÜKSEK yazısı da hâlâ GERİ butonundan (x=625) önce bitiyor.
      display.fillCircle(285, 437, 6, UI_GREEN);
      drawLeftText("DÜŞÜK", 297, 429, FONT_SMALL, UI_WHITE, UI_PANEL);

      display.fillCircle(400, 437, 6, UI_YELLOW);
      drawLeftText("ORTA", 412, 429, FONT_SMALL, UI_WHITE, UI_PANEL);

      display.fillCircle(495, 437, 6, UI_RED);
      drawLeftText("YÜKSEK", 507, 429, FONT_SMALL, UI_WHITE, UI_PANEL);
    } else {
      drawCenteredText("GERÇEK HARİTA YÜKLENEMEDİ", 400, 210,
                       FONT_MEDIUM, UI_RED, UI_PANEL);
      drawCenteredText(geoapifyHaritaHata.c_str(), 400, 252,
                       FONT_SMALL, UI_MUTED, UI_PANEL);
    }

    drawButton(625, 423, 145, 42, "geri", UI_CYAN);

  } else if (page == SCREEN_CLOUD) {
    drawHeader("BULUT");

    display.fillRoundRect(70, 95, 660, 280, 14, UI_PANEL);
    display.drawRoundRect(70, 95, 660, 280, 14, UI_LINE);

    drawCenteredText("BULUTA GÖNDER", 400, 125, FONT_BIG, UI_WHITE, UI_PANEL);

    drawCenteredText("Bekleyen ölçümler yalnızca Firebase'e gönderilir.", 400, 178,
                     FONT_SMALL, UI_MUTED, UI_PANEL);

    // Cihaz hafızası ve 20/20 kayıt bilgisi bu ekranda gösterilmiyor.
    // Bulut ekranı yalnızca bağlantı/gönderim durumunu sade biçimde gösterir.
    drawStatusPill(265, 215, 270,
                   bulutSenkronizasyonu ? "GÖNDERİLİYOR..." :
                   (firebaseHazir ? "GÜNCELLEME TAMAM" : "BULUT BAĞLANTISI YOK"),
                   bulutSenkronizasyonu ? UI_CYAN :
                   (firebaseHazir ? UI_GREEN : UI_ORANGE));

    drawButton(250, 345, 300, 48, "buluta gönder", UI_CYAN, ICON_CLOUD, true);
    drawButton(300, 410, 200, 48, "geri", UI_CYAN);

  } else if (page == SCREEN_SETTINGS) {
    drawHeader("AYARLAR");

    // Daha sade ayarlar: merkezde ikon kartlari, ayrintili teknik metinler
    // AYRINTILAR penceresine tasindi.
    display.fillRoundRect(55, 88, 690, 382, 18, UI_PANEL);
    display.drawRoundRect(55, 88, 690, 382, 18, UI_LINE);

    auto drawSettingsTile = [&](int x, int y, int w, int h,
                                IconType icon, const char* label, uint16_t accent) {
      display.fillRoundRect(x, y, w, h, 18, UI_PANEL2);
      display.drawRoundRect(x, y, w, h, 18, accent);
      display.drawCircle(x + w/2, y + 42, 24, accent);
      drawIcon(icon, x + w/2, y + 42, accent);
      drawCenteredText(label, x + w/2, y + 82, FONT_SMALL, UI_WHITE, UI_PANEL2);
    };

    const int tileW = 132, tileH = 112, gap = 18;
    const int totalW = tileW * 4 + gap * 3;
    const int x0 = (800 - totalW) / 2;
    const int y0 = 150;

    drawSettingsTile(x0 + 0*(tileW+gap), y0, tileW, tileH, ICON_CLOUD, "WİFİ", UI_CYAN);
    drawSettingsTile(x0 + 1*(tileW+gap), y0, tileW, tileH, ICON_GEAR, "KALİBRASYON", UI_ORANGE);
    drawSettingsTile(x0 + 2*(tileW+gap), y0, tileW, tileH, ICON_LOCATION, "GPS", UI_RED);
    drawSettingsTile(x0 + 3*(tileW+gap), y0, tileW, tileH, ICON_CHECK, "DURUM", UI_GREEN);
    // Ekran ayarları ayrı sayfaya taşındı; ana Ayarlar ekranı artık daha temiz.
    drawSettingsTile(284, 286, tileW, tileH, ICON_GEAR, "EKRAN", UI_CYAN);
    // TAKIM: kaptan/üye/danışman bilgileri ve proje logoları (TEKNOFEST,
    // Milli Teknoloji Hamlesi, NitraCheck) bu sayfada gösterilir.
    drawSettingsTile(434, 286, tileW, tileH, ICON_CHECK, "TAKIM", UI_GREEN);

    drawCenteredText("AYARLAR", 400, 102, FONT_MEDIUM, UI_WHITE, UI_PANEL);
    drawCenteredText("Ekran parlaklığı için EKRAN'a, ekip bilgileri için TAKIM'a dokunun", 400, 418, FONT_SMALL, UI_MUTED, UI_PANEL);

    drawButton(300, 440, 200, 40, "geri", UI_CYAN);

  } else if (page == SCREEN_DISPLAY_SETTINGS) {
    drawHeader("EKRAN");
    display.fillRoundRect(90, 92, 620, 372, 18, UI_PANEL);
    display.drawRoundRect(90, 92, 620, 372, 18, UI_LINE);

    drawCenteredText("EKRAN AYARLARI", 400, 112, FONT_MEDIUM, UI_WHITE, UI_PANEL);
    drawCenteredText("PARLAKLIK", 400, 156, FONT_MEDIUM, UI_WHITE, UI_PANEL);
    drawBrightnessSlider();

    // Donanımın mevcut RGB paneli sabit çözünürlükte çalışıyor. Kullanıcıya
    // sahte bir çözünürlük/renk kontrolü sunmak yerine gerçek durum gösteriliyor.
    display.fillRoundRect(145, 278, 510, 86, 14, UI_PANEL2);
    display.drawRoundRect(145, 278, 510, 86, 14, UI_LINE);
    drawCenteredText("ÇÖZÜNÜRLÜK: 800 x 480 (SABİT)", 400, 292, FONT_SMALL, UI_WHITE, UI_PANEL2);
    drawCenteredText("RENK: RGB565 / DONANIM PROFİLİ", 400, 328, FONT_SMALL, UI_MUTED, UI_PANEL2);

    drawCenteredText("TEMA SEÇİN", 400, 376, FONT_SMALL, UI_WHITE, UI_PANEL);
    drawButton(70, 398, 150, 34, "nitra mavi", UI_CYAN);
    drawButton(245, 398, 150, 34, "teknoloji mor", UI_ORANGE);
    drawButton(420, 398, 150, 34, "doğa yeşil", UI_GREEN);
    drawButton(595, 398, 135, 34, "kırmızı", UI_RED);
    drawButton(245, 438, 150, 34, "beyaz", UI_WHITE);
    drawButton(405, 438, 150, 34, "geri", UI_CYAN);

  } else if (page == SCREEN_GPS_INFO) {
    drawHeader("GPS");
    display.fillRoundRect(120, 110, 560, 300, 18, UI_PANEL);
    display.drawRoundRect(120, 110, 560, 300, 18, UI_RED);
    drawIcon(ICON_LOCATION, 400, 158, gpsKonumGecerli ? UI_GREEN : UI_RED);
    drawCenteredText("GPS BİLGİLERİ", 400, 205, FONT_MEDIUM, UI_WHITE, UI_PANEL);
    char gpsLine1[96], gpsLine2[96];
    snprintf(gpsLine1, sizeof(gpsLine1), "%s", gpsKonumGecerli ? "KONUM HAZIR" : (gpsHazir ? "UYDU BEKLENİYOR" : "GPS VERİSİ YOK"));
    if (gpsKonumGecerli) {
      snprintf(gpsLine2, sizeof(gpsLine2), "ENLEM: %.6f   BOYLAM: %.6f", gpsEnlem, gpsBoylam);
      drawCenteredText(gpsLine1, 400, 250, FONT_SMALL, UI_GREEN, UI_PANEL);
      drawCenteredText(gpsLine2, 400, 292, FONT_SMALL, UI_WHITE, UI_PANEL);
    } else {
      drawCenteredText(gpsLine1, 400, 270, FONT_SMALL, UI_ORANGE, UI_PANEL);
    }
    drawButton(300, 430, 200, 42, "ayarlara dön", UI_CYAN);

  } else if (page == SCREEN_SETTINGS_DETAILS) {
    drawHeader("DURUM");
    display.fillRoundRect(70, 92, 660, 372, 16, UI_PANEL);
    display.drawRoundRect(70, 92, 660, 372, 16, UI_LINE);
    drawCenteredText("CİHAZ DURUMU", 400, 112, FONT_MEDIUM, UI_WHITE, UI_PANEL);

    char as7341Tani[96];
    snprintf(as7341Tani, sizeof(as7341Tani), "AS7341   BUS:%s   BAŞLAT:%s   OKUMA:%s",
             as7341TaramaBulundu ? "VAR" : "YOK",
             as7341BeginSonucu ? "OK" : "HATA",
             as7341OkumaSonucu ? "OK" : "HATA");
    drawLeftText(as7341Tani, 120, 164, FONT_SMALL,
                 as7341OkumaSonucu ? UI_GREEN : UI_ORANGE, UI_PANEL);
    drawButton(120, 196, 250, 42, "as7341 yeniden dene", UI_CYAN, ICON_GEAR, true);

    char sht40Tani[96];
    if (sht40OkumaSonucu && isfinite(sonSicaklikC)) {
      // NOT: Buradaki font "°" karakterini desteklemediği için (bkz.
      // drawHeaderStatusIcons içindeki açıklama) bozuk görünmemesi adına
      // derece işareti olmadan "C" kullanılıyor.
      snprintf(sht40Tani, sizeof(sht40Tani), "SHT40   T:%.1fC   NEM:%.0f%%",
               sonSicaklikC, sonNemYuzde);
    } else {
      snprintf(sht40Tani, sizeof(sht40Tani), "SHT40   BUS:%s   BAŞLAT:%s   OKUMA:%s",
               sht40TaramaBulundu ? "VAR" : "YOK",
               sht40BeginSonucu ? "OK" : "HATA",
               sht40OkumaSonucu ? "OK" : "HATA");
    }
    drawLeftText(sht40Tani, 120, 260, FONT_SMALL,
                 sht40OkumaSonucu ? UI_GREEN : UI_ORANGE, UI_PANEL);
    drawButton(120, 292, 250, 42, "sht40 yeniden dene", UI_CYAN, ICON_GEAR, true);

    // GPS ayrıntıları yalnızca GPS kartında gösterilir. DURUM ekranı
    // cihazın diğer genel durumlarını tek yerde toplar.
    const char* wifiTxt = WiFi.status() == WL_CONNECTED ? "wifi: bağlı" : "wifi: bağlı değil";
    drawButton(430, 196, 250, 42, wifiTxt,
               WiFi.status() == WL_CONNECTED ? UI_GREEN : UI_ORANGE, ICON_CLOUD, true);
    const char* cloudTxt = firebaseHazir ? "firebase: hazır" : "firebase: hazır değil";
    drawButton(430, 292, 250, 42, cloudTxt,
               firebaseHazir ? UI_GREEN : UI_ORANGE, ICON_CLOUD, true);
    drawButton(300, 398, 200, 42, "ayarlara dön", UI_CYAN);

  } else if (page == SCREEN_TEAM_INFO) {
    // AYARLAR > TAKIM: ekip kaptanı / üyeleri / danışman hocası ve üç
    // logo (TEKNOFEST, #MilliTeknolojiHamlesi, NitraCheck) -- İSTEK
    // ÜZERİNE: eski dönüşümlü/animasyonlu logo gösterimi kaldırıldı;
    // logolar artık yan yana, SABİT olarak aynı anda gösteriliyor.
    drawHeader("TAKIM");
    display.fillRoundRect(55, 88, 690, 372, 18, UI_PANEL);
    display.drawRoundRect(55, 88, 690, 372, 18, UI_LINE);

    drawCenteredText("TAKIM", 400, 96, FONT_MEDIUM, UI_WHITE, UI_PANEL);

    drawCenteredText("TAKIM KAPTANI", 400, 128, FONT_SMALL, UI_MUTED, UI_PANEL);
    drawCenteredText("EYLÜL AKAN", 400, 152, FONT_SMALL, UI_CYAN, UI_PANEL);

    drawCenteredText("TAKIM ÜYELERİ", 400, 186, FONT_SMALL, UI_MUTED, UI_PANEL);
    drawCenteredText("BARAN BAYTAR   •   UTKU TANRIKULU", 400, 210, FONT_SMALL, UI_WHITE, UI_PANEL);

    drawCenteredText("PROJE DANIŞMANI", 400, 238, FONT_SMALL, UI_MUTED, UI_PANEL);
    drawCenteredText("GÜL NİHAN YİĞİT", 400, 262, FONT_MEDIUM, UI_ORANGE, UI_PANEL);

    display.drawFastHLine(85, 300, 630, UI_LINE);

    // TEKNOFEST / #MİLLİ TEKNOLOJİ HAMLESİ / NITRACHECK logoları yan
    // yana, sabit olarak tek seferde çizilir (döngü/animasyon yok).
    drawTakimLogoSeridi();

    drawButton(300, 406, 200, 40, "geri", UI_CYAN);

  }
}

// ─── NDSC-8 ÖLÇÜM FONKSİYONLARI (cokdil.ino'dan birebir) ───────

bool pcf8574Yaz(uint8_t value) {
  if (!ortakI2CHattiniBaslat()) return false;
  if (!i2cKilitle(pdMS_TO_TICKS(250))) return false;

  Wire.beginTransmission(PCF8574_ADDR);
  Wire.write(value);
  uint8_t err = Wire.endTransmission(true);

  i2cBirak();

  if (err != 0) {
    Serial.printf("[PCF8574] Yazma hatasi: err=%u\n", err);
    return false;
  }

  pcf8574State = value;
  return true;
}

bool pcf8574Baslat() {
  pcf8574Hazir = i2cCihazVar(PCF8574_ADDR);

  if (!pcf8574Hazir) {
    Serial.printf("[PCF8574] 0x%02X bulunamadi. A0=A1=A2=0 kontrol edin.\n",
                  PCF8574_ADDR);
    return false;
  }

  // Tüm pinler açılışta LOW: LED'ler kapalı, ISD1820 tetik hattı da
  // (PLAYE'nin kendi dahili pull-down'ıyla zaten uyumlu) boşta LOW.
  pcf8574State = 0x00;
  bool ok = pcf8574Yaz(pcf8574State);

  Serial.printf("[PCF8574] 0x%02X hazir: %s\n",
                PCF8574_ADDR, ok ? "OK" : "HATA");
  return ok;
}

void yesilLed(bool acik) {
  if (!pcf8574Hazir) return;

  if (acik) pcf8574State |= (1u << PCF_GREEN_PIN);
  else     pcf8574State &= ~(1u << PCF_GREEN_PIN);

  pcf8574Yaz(pcf8574State);
}

void kirmiziLed(bool acik) {
  if (!pcf8574Hazir) return;

  if (acik) pcf8574State |= (1u << PCF_RED_PIN);
  else     pcf8574State &= ~(1u << PCF_RED_PIN);

  pcf8574Yaz(pcf8574State);
}

void tumOlcumLedleriKapat() {
  if (!pcf8574Hazir) return;

  pcf8574State &= ~((1u << PCF_GREEN_PIN) | (1u << PCF_RED_PIN));
  pcf8574Yaz(pcf8574State);
}

// Eski ndscLed() çağrıları için uyumluluk: true = yeşil LED.
void ndscLed(bool acik) {
  yesilLed(acik);
}

// DÜZELTME (3. deneme): Pad'in PLAYL olduğu doğrulandı (ilk cümlede
// kesiliyordu -> PLAYL, HIGH bırakılınca hemen susuyor). Artık sabit
// bir süre BEKLEMEK yerine, sesi ölçümün GERÇEK başlangıcında açıp
// KIRMIZI LED söndüğü anda (ndscIkiRenkOlc() bittiğinde) kapatıyoruz.
// Böylece süre otomatik olarak gerçek sensör okuma süresine uyar,
// hard-coded bir milisaniye değeri tahmin etmemiz gerekmez.
void isd1820SesBaslat() {
  if (!pcf8574Hazir) {
    Serial.println("[ISD1820] PCF8574 hazir degil; ses baslatilamadi.");
    return;
  }
  pcf8574State &= ~(1u << PCF_ISD1820_PIN);  // once temiz bir LOW garanti et
  pcf8574Yaz(pcf8574State);
  vTaskDelay(pdMS_TO_TICKS(20));

  pcf8574State |= (1u << PCF_ISD1820_PIN);   // PLAYL: HIGH'a çık, ölçüm boyunca tut
  pcf8574Yaz(pcf8574State);
  Serial.println("[ISD1820] Ses baslatildi (olcum suresince HIGH tutulacak).");
}

void isd1820SesDurdur() {
  if (!pcf8574Hazir) return;
  pcf8574State &= ~(1u << PCF_ISD1820_PIN);  // PLAYL: LOW -> oynatma burada duruyor
  pcf8574Yaz(pcf8574State);
  Serial.println("[ISD1820] Ses durduruldu (kirmizi LED sondu).");
}

bool ndscOkuOrtalama(float *out, int adet, int progressStart = -1, int progressEnd = -1,
                      float *cvOut = nullptr, float *satOranOut = nullptr,
                      float *maxSapmaOut = nullptr) {
  if (!out || adet <= 0) return false;
  if (adet > NDSC_ORNEK) adet = NDSC_ORNEK;

  // Sensor acilista bulunamadiysa I2C hattina hic dokunma: dokunmatik
  // ekran (GT911) ayni fiziksel I2C hattini (GPIO15/16) paylastigi icin
  // yaniti olmayan bir sensore tekrar tekrar istek atmak hatti tikayip
  // dokunmatik ekranin donmasina yol aciyordu.
  if (!as7341Hazir) {
    Serial.println("[NDSC] AS7341 hazir degil; okuma atlaniyor.");
    return false;
  }

  // 20 tekrarın tamamını saklıyoruz. Tek bir bozuk okuma ortalamayı
  // sürüklemesin diye nihai değer MEDYAN ile alınır. Doyuma yaklaşan
  // örnekler ölçüme katılmaz.
  uint16_t ornekler[NDSC_ORNEK][NDSC_KANAL] = {{0}};
  int ok = 0;
  int saturasyon = 0;

  for (int n = 0; n < adet; n++) {
    yield();

    bool okOkuma = false;

    if (i2cKilitle(pdMS_TO_TICKS(250))) {
      okOkuma = as7341.readAllChannels(kanalDegerleri);
      i2cBirak();
    }

    // Tek I2C okuma kacarsa bir kez daha dene. Hatti yeniden baslatmiyoruz.
    if (!okOkuma) {
      vTaskDelay(pdMS_TO_TICKS(5));

      if (i2cKilitle(pdMS_TO_TICKS(250))) {
        okOkuma = as7341.readAllChannels(kanalDegerleri);
        i2cBirak();
      }
    }

    if (okOkuma) {
      bool doygun = false;
      for (int k = 0; k < NDSC_KANAL; k++) {
        if (kanalDegerleri[k] >= NDSC_SAT_ESIK) {
          doygun = true;
          break;
        }
      }

      if (doygun) {
        saturasyon++;
      } else {
        ornekler[ok][0] = kanalDegerleri[AS7341_CHANNEL_415nm_F1];
        ornekler[ok][1] = kanalDegerleri[AS7341_CHANNEL_445nm_F2];
        ornekler[ok][2] = kanalDegerleri[AS7341_CHANNEL_480nm_F3];
        ornekler[ok][3] = kanalDegerleri[AS7341_CHANNEL_515nm_F4];
        ornekler[ok][4] = kanalDegerleri[AS7341_CHANNEL_555nm_F5];
        ornekler[ok][5] = kanalDegerleri[AS7341_CHANNEL_590nm_F6];
        ornekler[ok][6] = kanalDegerleri[AS7341_CHANNEL_630nm_F7];
        ornekler[ok][7] = kanalDegerleri[AS7341_CHANNEL_680nm_F8];
        ok++;
      }
    }
    delay(20);

    // İSTEK ÜZERİNE: Ölçüm sırasında ortadaki halka animasyonu artık
    // burada, gerçek 20 örneklik okuma döngüsü boyunca, adım adım
    // ilerletiliyor. Eskiden bu döngü tamamen SESSİZ çalışıyordu; ekran
    // %10'da donmuş gibi kalıyor, döngü bitince mpAnimateTo() birden
    // %55'e "hızla" atlıyordu. Artık her örnekte -- gerçek ilerlemeyle
    // birebir eşleşecek şekilde -- halka bir sonraki yüzdeye taşınıyor.
    if (progressStart >= 0 && progressEnd > progressStart) {
      int pct = progressStart +
                (int)((long)(progressEnd - progressStart) * (n + 1) / adet);
      drawMeasuringProgressFrame(pct, "");
    }
  }

  int ndscMinGecerli = (int)(adet * NDSC_MIN_GECERLI_ORAN);
  if (ndscMinGecerli < 1) ndscMinGecerli = 1;

  if (ok < ndscMinGecerli) {
    Serial.printf("[NDSC] Gecerli ornek yetersiz: %d/%d (min %d gerekli), saturasyon=%d\n",
                  ok, adet, ndscMinGecerli, saturasyon);
    return false;
  }

  // ── TEKRARLANABİLİRLİK (repeatability): kanal başına ortalama ve
  // std sapma hesaplanır; varyasyon katsayısı (CV = std/ortalama)
  // kanallar üzerinden ortalanır. SADECE güven skoruna girdi olur,
  // aşağıdaki medyan hesabını (yani PPM'i) hiç DEĞİŞTİRMEZ.
  if (cvOut || satOranOut) {
    float cvToplam = 0.0f;
    int cvKanalSayisi = 0;
    for (int k = 0; k < NDSC_KANAL; k++) {
      float toplam = 0.0f;
      for (int i = 0; i < ok; i++) toplam += ornekler[i][k];
      float ortalamaK = toplam / ok;
      if (ortalamaK > NDSC_KANAL_GURULTU_TABANI) {  // sifira yakin/gurultulu kanali CV'ye katma
        float varyans = 0.0f;
        for (int i = 0; i < ok; i++) {
          float fark = ornekler[i][k] - ortalamaK;
          varyans += fark * fark;
        }
        varyans /= ok;
        cvToplam += (sqrtf(varyans) / ortalamaK);
        cvKanalSayisi++;
      }
    }
    if (cvOut) *cvOut = (cvKanalSayisi > 0) ? (cvToplam / cvKanalSayisi) : 0.0f;
    if (satOranOut) *satOranOut = (float)saturasyon / (float)adet;
  }

  // Her kanal icin medyan. N <= 20 oldugu icin kucuk insertion-sort yeterlidir.
  for (int k = 0; k < NDSC_KANAL; k++) {
    uint16_t sirali[NDSC_ORNEK];
    for (int i = 0; i < ok; i++) sirali[i] = ornekler[i][k];
    for (int i = 1; i < ok; i++) {
      uint16_t key = sirali[i];
      int j = i - 1;
      while (j >= 0 && sirali[j] > key) {
        sirali[j + 1] = sirali[j];
        j--;
      }
      sirali[j + 1] = key;
    }
    if (ok & 1) out[k] = sirali[ok / 2];
    else out[k] = 0.5f * (sirali[ok / 2 - 1] + sirali[ok / 2]);
  }

  // ── EN KÖTÜ TEKİL SAPMA: medyan artık hesaplandığına göre, her
  // kanalda TEK bir örneğin bile medyandan ne kadar uzaklaştığına
  // bakılır (yüzde olarak), tüm kanallardaki en kötü değer alınır.
  // Numune çekmecesi ölçüm SIRASINDA açılırsa sadece o anki birkaç
  // örnek bozulur; 20 örneğin ORTALAMASI (yukarıdaki CV) bunu
  // sulandırabilir ama bu metrik sulandırmaz -- tek kötü örnek bile
  // yakalanır. SADECE güven skoruna girer, medyanı/PPM'i değiştirmez.
  if (maxSapmaOut) {
    float enKotu = 0.0f;
    for (int k = 0; k < NDSC_KANAL; k++) {
      if (out[k] > NDSC_KANAL_GURULTU_TABANI) {
        for (int i = 0; i < ok; i++) {
          float sapma = fabsf((float)ornekler[i][k] - out[k]) / out[k];
          if (sapma > enKotu) enKotu = sapma;
        }
      }
    }
    *maxSapmaOut = enKotu;
  }

  return true;
}

bool ndscOlcumLED(float *out, int adet, int progressStart = -1, int progressEnd = -1) {
  ndscLed(true);
  bool ok = ndscOkuOrtalama(out, adet, progressStart, progressEnd);
  ndscLed(false);
  return ok;
}

float ndscWeightedIntegral(const float *a, float centerNm, float sigmaNm) {
  float num = 0.0f, den = 0.0f;
  for (int k = 0; k < NDSC_KANAL; k++) {
    float z = (NDSC_LAMBDA[k] - centerNm) / sigmaNm;
    float w = expf(-0.5f * z * z);
    num += w * a[k];
    den += w;
  }
  return (den > 0.0f) ? num / den : 0.0f;
}

float ndscSpectralScore(const float *beyazRaw, float *qualityOut) {
  float ab[NDSC_KANAL];
  float q = 100.0f;
  for (int k = 0; k < NDSC_KANAL; k++) {
    float b0 = blankBeyaz[k] - darkSpectrum[k];
    float b  = beyazRaw[k]   - darkSpectrum[k];
    if (b0 < NDSC_EPS) b0 = NDSC_EPS;
    if (b  < NDSC_EPS) b  = NDSC_EPS;
    ab[k] = logf(b0 / b);
    sonAbsBeyaz[k] = ab[k];
    // Saturasyon/negatif absorbans kaliteyi azaltir.
    if (fabsf(ab[k]) > 3.0f) q -= 1.0f;
  }

  // Analitik bant: 545 nm civarini Gaussian agirlikla temsil eder.
  float greenBand = ndscWeightedIntegral(ab, 545.0f, 42.0f);

  // Spektral sekil/curvature: F5'in komsu bantlara gore belirginlesmesini olcer.
  float shape = ab[4] - 0.5f * (ab[3] + ab[5]);

  // NOT: Onceki surumdeki ayri kirmizi (630nm) LED referans olcumu ve
  // NDSC_RED_BETA duzeltme terimi kaldirildi -- artik tek isik kaynagi
  // (PCF8574 harici yesil/kirmizi LED) kullanildigi icin ayri bir kirmizi
  // referans bandi yok.
  float score = greenBand + NDSC_SHAPE_BETA * shape;

  if (greenBand < -0.20f) q -= 5.0f;
  if (q < 0.0f) q = 0.0f;
  if (qualityOut) *qualityOut = q;
  return score;
}

// KAL-FIX-KIRMIZI-BANT: [TY]/[TK] tani logu (bkz. asagidaki ndscIkiRenkOlc)
// kesin olarak gosterdi ki kirmizi LED, yesilin analiz bandinda (F4/F5,
// 515-555nm) neredeyse hic isik uretmiyor (orn. F4=49,F5=28 iken F7=392) --
// kirmizi kendi dogal bandinda (F7, 630nm) GUCLU. ndscSpectralScore() kirmizi
// LED'in ham spektrumuna da UYGULANIRSA, "s2" fiziksel olarak anlamli bir
// kimyasal sinyal degil, buyuk olcude gurultu/artik isiktan hesaplanmis
// olurdu -- bu da hem "uyum" kontrolunu hem de PPM'e giren score=0.5*(s1+s2)
// ortalamasini bozardi.
//
// KAL-FIX-KIRMIZI-TEK-KANAL: Ilk duzeltmede F7 merkezli Gaussian bant
// (sigma=42nm, F6/F8 komsularini da agirlikli katan) + sekil terimi
// kullanilmisti. Ama kirmizi LED'in F6'daki (590nm) ve ozellikle F8'deki
// (680nm, [TK] loguna gore ~9-10 ham sayim -- gurultu tabanina yakin)
// isigi zaten cok zayif/soluk. Bu zayif komsu bantlari hesaba katmak
// (Gaussian agirlik ~%64 bile olsa) sadece gurultu eklemekteydi. Kullanici
// talebi uzerine kirmizi artik SADECE kendi kanalindan (F7, 630nm hesaba
// katilir, digerleri tamamen kapali) hesaplaniyor -- yesile dokunulmadi,
// o hala 545nm Gaussian bandini (F4/F5 agirlikli) kullanmaya devam ediyor.
float ndscSpectralScoreKirmizi(const float *beyazRaw, float *qualityOut) {
  const int F7 = 6;  // NDSC_LAMBDA[6] = 630nm, kirmizi LED'in kendi bandi
  float b0 = blankBeyaz[F7] - darkSpectrum[F7];
  float b  = beyazRaw[F7]   - darkSpectrum[F7];
  if (b0 < NDSC_EPS) b0 = NDSC_EPS;
  if (b  < NDSC_EPS) b  = NDSC_EPS;
  float redBand = logf(b0 / b);  // SADECE F7 -- komsu bantlar tamamen disarida.

  float q = 100.0f;
  if (fabsf(redBand) > 3.0f) q -= 1.0f;
  if (redBand < -0.20f) q -= 5.0f;
  if (q < 0.0f) q = 0.0f;
  if (qualityOut) *qualityOut = q;

  float score = redBand;
  return score;
}

bool ndscIkiRenkOlc(float *yesil, float *kirmizi, int progressStart = 10, int progressMid = 45, int progressEnd = 80) {
  if (!yesil || !kirmizi) return false;

  tumOlcumLedleriKapat();

  // 1) YEŞİL LED: ölçümde ilk önce bu açılır (tam 10 gerçek sensör örneği).
  // KAL-FIX-UYUM2: Kırmızı LED'e geçişte 80ms "oturma" süresi tanınıyordu
  // (asağıda), ama yeşil LED açılır açılmaz HİÇ BEKLEMEDEN ölçüm
  // başlıyordu -- LED'in fiziksel olarak tam parlaklığa ulaşması ve
  // AS7341'in önceki (karanlık) ışık seviyesinden yeni seviyeye adapte
  // olması için hiç süre tanınmamış oluyordu. Bu asimetri, tekrarlanan
  // blank ölçümlerinde YEŞİL skorunun (Y) KIRMIZI skoruna (K) göre çok
  // daha degişken çıkmasına yol açıyordu (Y: -0.6..+2.2 gibi geniş bir
  // salınım, K: 4.6..5.7 gibi dar bir bant) -- bu da "uyum" kontrolünü
  // ölçümden ölçüme farklı değerler vermeye zorluyordu. Simetri için
  // kırmızı ile AYNI 80ms bekleme burada da ekleniyor.
  float cvYesil = 0.0f, satYesil = 0.0f, sapmaYesil = 0.0f;
  yesilLed(true);
  vTaskDelay(pdMS_TO_TICKS(80));
  bool okYesil = ndscOkuOrtalama(yesil, 10, progressStart, progressMid, &cvYesil, &satYesil, &sapmaYesil);
  // TANI-LOG (gecici): yeşil LED altında ham F1-F8 -- 545nm analitik bandda
  // (F4/F5) gercekten guclu sinyal var mi diye kontrol icin. Serial calismasa
  // bile bu satir ekrandaki KALIBRASYON LOG'da da gorunur (kalLog ikisine
  // birden yaziyor).
  kalLog("[TY] F1=%.0f F2=%.0f F3=%.0f F4=%.0f F5=%.0f F6=%.0f F7=%.0f F8=%.0f",
         yesil[0], yesil[1], yesil[2], yesil[3], yesil[4], yesil[5], yesil[6], yesil[7]);

  // KIRMIZI LED, YEŞİL kapanmadan ÖNCE açılır: böylece iki ölçüm arasında
  // hiçbir an ışıksız (karanlık) kalınmaz -- yeşilden kırmızıya kesintisiz geçiş.
  kirmiziLed(true);
  yesilLed(false);

  vTaskDelay(pdMS_TO_TICKS(80));

  // 2) KIRMIZI LED açık kalmaya devam ederken tam 10 gerçek sensör örneği alınır.
  float cvKirmizi = 0.0f, satKirmizi = 0.0f, sapmaKirmizi = 0.0f;
  bool okKirmizi = ndscOkuOrtalama(kirmizi, 10, progressMid, progressEnd, &cvKirmizi, &satKirmizi, &sapmaKirmizi);
  // TANI-LOG (gecici): kirmizi LED altinda ham F1-F8 -- 545nm analitik bandda
  // (F4/F5) yesile kiyasla ne kadar zayif/guclu diye kontrol icin. Bu satir
  // da Serial calismasa bile ekrandaki KALIBRASYON LOG'da gorunur.
  kalLog("[TK] F1=%.0f F2=%.0f F3=%.0f F4=%.0f F5=%.0f F6=%.0f F7=%.0f F8=%.0f",
         kirmizi[0], kirmizi[1], kirmizi[2], kirmizi[3], kirmizi[4], kirmizi[5], kirmizi[6], kirmizi[7]);

  // KIRMIZI LED en son kapatılır: hiçbir ölçüm karanlıkta yapılmamış olur.
  kirmiziLed(false);

  tumOlcumLedleriKapat();

  // Yeşil + kırmızının ortalama tekrarlanabilirlik/saturasyon/en-kötü-sapma
  // değerleri ndscIkiRenkSkor() içindeki güven skoruna girdi olarak globale
  // yazılır. PPM'i etkilemez (score/hesaplaPPM bu değerlere hiç bakmıyor).
  if (okYesil && okKirmizi) {
    g_ndscCVOrtalama = 0.5f * (cvYesil + cvKirmizi);
    g_ndscSatOraniOrtalama = 0.5f * (satYesil + satKirmizi);
    g_ndscMaxSapmaOrtalama = fmaxf(sapmaYesil, sapmaKirmizi);
  }

  return okYesil && okKirmizi;
}

void ikiSpektrumuOrtalama(const float *a, const float *b, float *out) {
  for (int k = 0; k < NDSC_KANAL; k++)
    out[k] = 0.5f * (a[k] + b[k]);
}

float ndscIkiRenkSkor(const float *yesil,
                      const float *kirmizi,
                      float *qualityOut) {
  float q1 = 0.0f;
  float q2 = 0.0f;

  float s1 = ndscSpectralScore(yesil, &q1);
  // KAL-FIX-KIRMIZI-BANT: kirmizi artik KENDI dogal bandinda (630nm)
  // degerlendiriliyor -- eskiden burada da ndscSpectralScore() (545nm)
  // cagriliyordu, bu da kirmizi icin buyuk olcude gurultuden hesaplanmis
  // bir sayi uretiyordu (bkz. [TK] tani logu).
  float s2 = ndscSpectralScoreKirmizi(kirmizi, &q2);

  // NOT: "score" (PPM hesaplamasına giden sonNDSCScore) SADECE s1/s2'nin
  // ortalaması ile bulunur; aşağıdaki güven skoru bileşenleri bu satırı
  // hiç etkilemez.
  float score = 0.5f * (s1 + s2);

  // ── ÖLÇÜM GÜVENİ (kalite / sonOptikKalite): iki katmanlı.
  // Katman 1 (TABAN): spektral kalite (%60, baskın), uyum (%10) ve
  // saturasyon (%15) toplanır -- bunlar küçük/normal koşullardaki
  // ince farkları yansıtır.
  // Katman 2 (KAPI): tekrarlanabilirlik artık toplanan bir puan değil,
  // TABAN'ı çarpan bir kapıdır. Normal ölçümde (küçük gürültü) kapı
  // ~1.0'da kalır, TABAN'a dokunmaz -- bu sayede iyi ölçümler artık
  // sabit bir %15'lik payla 90'ın altına ÇAKILMIYOR. Ama numune
  // çekmecesi ölçüm SIRASINDA açılıp kapanınca (veya benzer ciddi bir
  // bozulmada) kapı sert şekilde 0'a yaklaşır ve KALITE'yi gerçekten
  // çöktürür -- eskiden bu durumda bile en fazla ~15 puan (88->84 gibi)
  // düşebiliyordu, çünkü tekrar sadece toplanan sabit bir ağırlıktı.
  // Eşikler (NDSC_CV_KOTU_ESIK, NDSC_MAXSAPMA_KOTU_ESIK) hâlâ GEÇİCİ
  // tahmindir -- aşağıdaki [NDSC-GUVEN] log satırından gerçek
  // cv/sapma değerleri okunup saha verisiyle daraltılmalı.

  // 1) Tekrarlanabilirlik BOZULMA GÖSTERGESİ (0=kusursuz, 1=çok kötü):
  // ortalama varyasyon (CV) ile TEK bir örneğin en kötü sapması
  // arasından hangisi daha kötüyse o alınır. Numune çekmecesi ölçüm
  // ortasında açılırsa sadece birkaç örnek bozulur; ORTALAMA CV bunu
  // sulandırabilir ama "en kötü tekil sapma" sulandırmaz.
  float cvOrani = g_ndscCVOrtalama / NDSC_CV_KOTU_ESIK;
  float sapmaOrani = g_ndscMaxSapmaOrtalama / NDSC_MAXSAPMA_KOTU_ESIK;
  float bozulmaGostergesi = fmaxf(cvOrani, sapmaOrani);
  if (bozulmaGostergesi > 1.0f) bozulmaGostergesi = 1.0f;
  if (bozulmaGostergesi < 0.0f) bozulmaGostergesi = 0.0f;
  // Küp eğrisi: küçük bozulma göstergesinde (ör. 0.2) çarpan hâlâ ~0.99,
  // TABAN'a neredeyse dokunmaz; büyük bozulmada (ör. 0.8) çarpan ~0.49'a,
  // tam bozulmada (1.0) çarpan 0'a düşer.
  float tekrarCarpani = 1.0f - powf(bozulmaGostergesi, NDSC_TEKRAR_USTEL);
  if (tekrarCarpani < 0.0f) tekrarCarpani = 0.0f;
  if (tekrarCarpani > 1.0f) tekrarCarpani = 1.0f;

  // 2) Yeşil/kırmızı uyumu: iki bağımsız skorun MUTLAK farkı, kalibrasyon
  // skor aralığına (kal_ScoreMax - kal_ScoreMin) göre ölçeklenir. Önceki
  // sürümde fark s1/s2'nin KENDİSİNE bölünüyordu; skor sıfıra yakın
  // (düşük ppm) çıktığında bu oran yapay şekilde patlayıp uyum puanını
  // gereksiz yere çöktürüyordu (61-68 sorununun ana sebeplerinden biri).
  //
  // KAL-FIX-UYUM: s1/s2 HAM haliyle karşılaştırılmaz. blankBeyaz ortak
  // (yeşil+kırmızı ORTALAMASI) bir referans olduğu için, iki farklı
  // renkli LED'in ham kanal profili farklı olduğundan s1 ile s2 arasında
  // ölçüm ne kadar kararlı olursa olsun HER ZAMAN sabit bir LED-rengi
  // ofseti bulunur (bkz. ndscBlankOlc() içindeki "ÖNEMLİ DÜZELTME" notu –
  // aynı sorun orada PPM için zaten fark edilip düzeltilmişti, ama uyum
  // kontrolüne hiç yansıtılmamıştı). Bu yüzden her kanal, kendi blank
  // taban skorundan (kal_s1Blank / kal_s2Blank) ne kadar SAPTIĞI üzerinden
  // karşılaştırılır -- sabit ofset böylece iptal olur, sadece GERÇEK
  // (numuneye özgü) sapma kalır.
  float s1Duzeltilmis = s1 - kal_s1Blank;
  float s2Duzeltilmis = s2 - kal_s2Blank;
  float kalAraligi = kal_ScoreMax - kal_ScoreMin;
  float payda = (kalAraligi > NDSC_EPS) ? kalAraligi : NDSC_EPS;
  float uyumFarki = fabsf(s1Duzeltilmis - s2Duzeltilmis) / payda;
  float uyumPuani = 100.0f * (1.0f - (uyumFarki / NDSC_UYUM_KOTU_ESIK));
  if (uyumPuani < 0.0f) uyumPuani = 0.0f;
  if (uyumPuani > 100.0f) uyumPuani = 100.0f;

  // 3) Spektral sinyal kalitesi: mevcut kanal/greenBand cezası (0-100).
  float spektralPuani = 0.5f * (q1 + q2);

  // 4) Saturasyon: doygunluğa yaklaşan örneklerin oranı.
  float saturasyonPuani = 100.0f * (1.0f - g_ndscSatOraniOrtalama);
  if (saturasyonPuani < 0.0f) saturasyonPuani = 0.0f;

  // 5) SİNYAL GÜCÜ KAPISI: "uyum" (madde 2), s1/s2 skorlarının FARKINA
  // bakıyor -- ama F7 (kırmızı, tek kanal) ya da F4/F5 (yeşil, analiz
  // bandı) gürültü tabanının (NDSC_KANAL_GURULTU_TABANI) altındaysa, o
  // kanaldan hesaplanan skor zaten anlamsız/gürültü demektir ve fark
  // tesadüfen küçük çıkıp "uyum yüksek" gibi YANILTICI bir sonuç
  // üretebilir. (07.09.2026: LED/tüp bağlantısı yapılmadan/kalibrasyon
  // öncesi alınan bir ölçümde F7=13, F8=6 gibi gürültü-altı değerler
  // görüldü.) Bu kapı, en zayıf ilgili kanal gürültü tabanının altına
  // düştükçe KALİTE'yi sert şekilde kırpar; tekrarCarpani'nden BAĞIMSIZ
  // çalışır çünkü CV/sapma orada sadece ok>NDSC_KANAL_GURULTU_TABANI
  // olan kanallardan hesaplanıyor, yani zayıf kanal CV'ye hiç girmeyip
  // sessizce atlanabiliyordu.
  float sinyalGucu = fminf(kirmizi[6], fminf(yesil[3], yesil[4]));
  float sinyalCarpani = (sinyalGucu < NDSC_KANAL_GURULTU_TABANI)
                           ? fmaxf(sinyalGucu / NDSC_KANAL_GURULTU_TABANI, 0.0f)
                           : 1.0f;

  float kalite = NDSC_AGIRLIK_UYUM     * uyumPuani
               + NDSC_AGIRLIK_SPEKTRAL * spektralPuani
               + NDSC_AGIRLIK_SATURASYON * saturasyonPuani;
  // TABAN, sadece uyum+spektral+saturasyon ağırlıklarının toplamına
  // (0.85) göre normalize edilir ki taban kendi içinde 0-100 arası kalsın.
  kalite = kalite / (NDSC_AGIRLIK_UYUM + NDSC_AGIRLIK_SPEKTRAL + NDSC_AGIRLIK_SATURASYON);
  // KAPI 1: tekrarlanabilirlik bozulma göstergesi TABAN'ı çarpar.
  kalite = kalite * tekrarCarpani;
  // KAPI 2: gürültü-altı sinyal varsa TABAN'ı ayrıca çarpar.
  kalite = kalite * sinyalCarpani;
  if (kalite < 0.0f) kalite = 0.0f;
  if (kalite > 100.0f) kalite = 100.0f;

  if (qualityOut)
    *qualityOut = kalite;

  Serial.printf(
    "[NDSC] YESIL score=%.6f kalite=%.1f | KIRMIZI score=%.6f kalite=%.1f | ORT=%.6f\n"
    "[NDSC-GUVEN] bozulma=%.2f(cv=%.4f,sapma=%.4f) carpan=%.2f | sinyal=%.0f(carpan=%.2f) | uyum=%.1f(fark=%.4f) spektral=%.1f saturasyon=%.1f(oran=%.3f) => KALITE=%.1f\n",
    s1, q1, s2, q2, score,
    bozulmaGostergesi, g_ndscCVOrtalama, g_ndscMaxSapmaOrtalama, tekrarCarpani,
    sinyalGucu, sinyalCarpani,
    uyumPuani, uyumFarki, spektralPuani, saturasyonPuani, g_ndscSatOraniOrtalama, kalite
  );

  // Serial USB her zaman güvenilir olmuyor (bkz. yukarıdaki kalLog() yorumu);
  // bu yüzden aynı güven skoru dökümü, AYARLAR > KALİBRASYON ekranındaki
  // "LOG" butonuyla (kalLogEkraniGoster()) Serial'siz de okunabilsin diye
  // ekran üzeri dairesel log arabelleğine de yazılıyor. PPM/score'u
  // etkilemez, sadece bilgi amaçlıdır.
  kalLog("[NDSC] Y=%.3f k=%.1f | K=%.3f k=%.1f | ORT=%.3f", s1, q1, s2, q2, score);
  kalLog("[GUVEN] bzlm=%.2f(cv=%.3f,sp=%.3f) x%.2f sgl=%.0f(x%.2f) uyum=%.0f(fark=%.3f/esik=%.2f) spk=%.0f sat=%.0f =>%.0f",
         bozulmaGostergesi, g_ndscCVOrtalama, g_ndscMaxSapmaOrtalama, tekrarCarpani,
         sinyalGucu, sinyalCarpani,
         uyumPuani, uyumFarki, NDSC_UYUM_KOTU_ESIK, spektralPuani, saturasyonPuani, kalite);

  return score;
}

void kalibrasyonKartiniSeriYaz() {
  Serial.println("\n================ NITRACHECK KALİBRASYON KARTI ================");
  Serial.println("DARK REFERANS (ham AS7341):");
  for (int k = 0; k < NDSC_KANAL; k++) Serial.printf("DARK_F%d=%.6f\n", k + 1, darkSpectrum[k]);
  Serial.println("BLANK REFERANS (ham AS7341):");
  for (int k = 0; k < NDSC_KANAL; k++) Serial.printf("BLANK_F%d=%.6f\n", k + 1, blankBeyaz[k]);
  Serial.println("STANDART NDSC SKORLARI:");
  Serial.printf("0 PPM = %.8f\n", kalPts[0].score);
  for (int i = 1; i < KAL_NOKTA_SAYISI; i++) {
    Serial.printf("%g PPM = %s%.8f\n", kalPts[i].hedefPPM,
                  kalPts[i].aktif ? "" : "PASIF / ", kalPts[i].score);
  }
  Serial.printf("LINEER REFERANS: PPM = %.8f * SCORE + %.8f | PARCALI KALIBRASYON AKTIF | NOKTA=%d | GECERLI=%s\n",
                kal_b, kal_d, kal_n, kalibrasyonGecerli ? "EVET" : "HAYIR");
  Serial.println("================================================================\n");
}

// ─── ÇİFT KOPYA (ping-pong) NVS SAKLAMA ────────────────────────────
// Neden: cihaz her zaman doğrudan fiş/pil çekilerek kapatılıyor. Tek
// bir NVS anahtarına yazarken tam o anda güç kesilirse o kayıt yarım
// kalıp bozulabilir ve kalibrasyon "unutulmuş" gibi görünür. Bunun
// önüne geçmek için kalibrasyon HER ZAMAN iki ayrı anahtara ("blobA",
// "blobB") sırayla, önceki geçerli kopyayı ASLA aynı anda dokunmadan
// yazılır. Güç tam yazma sırasında kesilse bile diğer slottaki bir
// önceki geçerli kalibrasyon sağlam kalır. Yükleme sırasında iki
// kopya da okunur, geçerli olan(lar) arasından "generation" sayacı
// en yüksek olan (en güncel) kullanılır.

// Bir blobun formatının/aritmetiğinin tutarlı olup olmadığını kontrol
// eder. Sadece doğrulama yapar, canlı kalibrasyona HİÇBİR ŞEY yazmaz.
// NOT: Eskiden TEK bir kanal bile (blank[k] <= dark[k]) sartini
// gecemese TUM kalibrasyon reddediliyordu, sonra bunu "en fazla N kanal
// bozuk olabilir + F5 kritik" seklinde gevsetmistik. Ama saha testinde
// GERCEK bir sensorde F5 dahil herhangi bir kanal ARA SIRA sinirda
// (blank<=dark) olabiliyor; bu durum RAM'de CANLI olcum sirasinda HICBIR
// SORUN CIKARMIYOR cunku ndscSpectralScore() b0<=NDSC_EPS durumunu zaten
// epsilon'a clamp'leyip toluere ediyor (bkz. yukarida). Yani ayni veri
// RAM'de calisirken NVS'ten geri yuklerken "GECERSIZ" sayilip
// reddediliyordu -- kullanicinin yasadigi "restart sonrasi kalibrasyon
// unutuluyor" hatasinin gercek kaynagi buydu. Artik reload dogrulamasi,
// calisma zamani matematigiyle BIREBIR TUTARLI: blank<=dark tek basina
// ARTIK REDDETME SEBEBI DEGIL (sadece bilgi amacli logland ), yalnizca
// NaN/Inf veya hicbir zaman ayarlanmamis (tum kanallar sifir) blob
// reddedilir.
static bool kalibrasyonBlobGecerliMi(const KalibrasyonBlob &blob) {
  if (blob.magic != KAL_BLOB_MAGIC || blob.version != KAL_BLOB_VERSION ||
      blob.size != sizeof(KalibrasyonBlob)) {
    kalLog("[KAL-NVS] DOGRULAMA HATASI: magic/version/size uyusmuyor");
    return false;
  }

  bool hicVeriYok = true;
  for (int k = 0; k < NDSC_KANAL; k++) {
    if (!isfinite(blob.dark[k]) || !isfinite(blob.blank[k])) {
      kalLog("[KAL-NVS] DOGRULAMA HATASI: kanal F%d sayisal degil (NaN/Inf)", k + 1);
      return false;
    }
    if (blob.dark[k] != 0.0f || blob.blank[k] != 0.0f) hicVeriYok = false;
    if (blob.blank[k] <= blob.dark[k]) {
      // Reddetmiyoruz -- calisma zamani zaten NDSC_EPS'e clamp'liyor.
      // Sadece bilgi icin logluyoruz ki hangi kanalin sinirda oldugu
      // takip edilebilsin.
      kalLog("[KAL-NVS] BILGI: kanal F%d sinirda (dark=%.4f blank=%.4f)",
             k + 1, blob.dark[k], blob.blank[k]);
    }
  }
  if (hicVeriYok) {
    kalLog("[KAL-NVS] DOGRULAMA HATASI: tum kanallar sifir (hic ayarlanmamis)");
    return false;
  }

  for (int i = 0; i < KAL_NOKTA_SAYISI; i++) {
    if (!isfinite(blob.score[i])) {
      kalLog("[KAL-NVS] DOGRULAMA HATASI: nokta %d skoru sayisal degil", i);
      return false;
    }
    if (blob.aktif[i] && !isfinite(blob.hedefPPM[i])) {
      kalLog("[KAL-NVS] DOGRULAMA HATASI: nokta %d hedefPPM sayisal degil", i);
      return false;
    }
  }
  if (!isfinite(blob.s1Blank) || !isfinite(blob.s2Blank)) {
    kalLog("[KAL-NVS] DOGRULAMA HATASI: s1Blank/s2Blank sayisal degil");
    return false;
  }
  kalLog("[KAL-NVS] DOGRULAMA BASARILI");
  return true;
}

static bool kalibrasyonBlobOku(const char *anahtar, KalibrasyonBlob &out) {
  Preferences kp;
  if (!kp.begin("nckal", true)) return false;
  size_t len = kp.getBytesLength(anahtar);
  if (len != sizeof(KalibrasyonBlob)) { kp.end(); return false; }
  size_t r = kp.getBytes(anahtar, &out, sizeof(out));
  kp.end();
  return (r == sizeof(out));
}

// KAL-NVS TANI: Preferences::putBytes() basarisiz oldugunda sadece "0 byte
// yazildi" diyor; nvs_set_blob()/nvs_commit()'in gercekte donduğu esp_err_t
// (ORT. NOT_ENOUGH_SPACE, PAGE_FULL, NO_FREE_PAGES, INVALID_STATE, vb.)
// gizleniyordu. Bu yardimci fonksiyon ham NVS API'siyle yazip gercek hata
// kodunu kalLog()'a basiyor; namespace/anahtar davranisi Preferences ile
// birebir ayni (ayni "nckal" namespace, ayni anahtar).
static bool kalibrasyonBlobYaz(const char *anahtar, const KalibrasyonBlob &blob,
                                const char *asamaEtiketi) {
  nvs_handle_t h;
  esp_err_t err = nvs_open("nckal", NVS_READWRITE, &h);
  if (err != ESP_OK) {
    kalLog("[KAL-NVS] nvs_open hatasi (%s): %s", asamaEtiketi, esp_err_to_name(err));
    return false;
  }
  err = nvs_set_blob(h, anahtar, &blob, sizeof(blob));
  if (err != ESP_OK) {
    kalLog("[KAL-NVS] nvs_set_blob hatasi (%s, slot=%s): %s",
           asamaEtiketi, anahtar, esp_err_to_name(err));
    nvs_close(h);
    return false;
  }
  err = nvs_commit(h);
  if (err != ESP_OK) {
    kalLog("[KAL-NVS] nvs_commit hatasi (%s, slot=%s): %s",
           asamaEtiketi, anahtar, esp_err_to_name(err));
    nvs_close(h);
    return false;
  }
  nvs_close(h);
  return true;
}

bool kalibrasyonuNVSyeKaydet() {
  KalibrasyonBlob blobA = {}, blobB = {};
  bool aVar = kalibrasyonBlobOku("blobA", blobA) && kalibrasyonBlobGecerliMi(blobA);
  bool bVar = kalibrasyonBlobOku("blobB", blobB) && kalibrasyonBlobGecerliMi(blobB);
  uint32_t genA = aVar ? blobA.generation : 0;
  uint32_t genB = bVar ? blobB.generation : 0;

  // En ESKİ (düşük generation) kopyanın olduğu slota yaz; diğeri (güncel,
  // sağlam kopya) bu yazma sırasında güç kesilse bile DOKUNULMADAN kalır.
  const char *hedefAnahtar = (genA <= genB) ? "blobA" : "blobB";
  uint32_t yeniGen = (genA > genB ? genA : genB) + 1;

  KalibrasyonBlob blob = {};
  blob.magic = KAL_BLOB_MAGIC;
  blob.version = KAL_BLOB_VERSION;
  blob.size = sizeof(KalibrasyonBlob);
  blob.generation = yeniGen;
  for (int k = 0; k < NDSC_KANAL; k++) {
    blob.dark[k] = darkSpectrum[k];
    blob.blank[k] = blankBeyaz[k];
  }
  for (int i = 0; i < KAL_NOKTA_SAYISI; i++) {
    blob.score[i] = kalPts[i].score;
    blob.hedefPPM[i] = kalPts[i].hedefPPM;  // KAL-DUZELTME: artik hedefPPM de kaydediliyor.
    blob.aktif[i] = kalPts[i].aktif ? 1 : 0;
  }
  blob.s1Blank = kal_s1Blank;  // KAL-FIX-UYUM
  blob.s2Blank = kal_s2Blank;  // KAL-FIX-UYUM

  // Tani: yazmadan once bu namespace'te kac "giris" (entry) bos kaldigini
  // logla (salt-okunur ayri bir Preferences oturumuyla).
  {
    Preferences kpTani;
    if (kpTani.begin("nckal", true)) {
      kalLog("[KAL-NVS] Yazmadan once serbest giris (entry): %u",
             (unsigned)kpTani.freeEntries());
      kpTani.end();
    }
  }

  bool ok = kalibrasyonBlobYaz(hedefAnahtar, blob, "1. deneme");

  if (!ok) {
    // Ilk deneme basarisiz oldu. Sadece HEDEF anahtari (digerine, yani
    // olasi SAGLAM yedek kopyaya DOKUNMADAN) silip -- namespace'i TAMAMEN
    // kapatip yeniden acarak (eski Preferences oturumunun ayni handle
    // uzerinde ust uste denemesinden farkli olarak) tek seferlik yeniden
    // deniyoruz. Bu, yarim kalmis/bozuk bir girisin temizlenip yer
    // acmasini ve NVS'nin taze bir handle ile calismasini saglar.
    kalLog("[KAL-NVS] Ilk yazma basarisiz, '%s' silinip tekrar deneniyor...",
           hedefAnahtar);
    nvs_handle_t hSil;
    esp_err_t errSil = nvs_open("nckal", NVS_READWRITE, &hSil);
    if (errSil == ESP_OK) {
      esp_err_t errErase = nvs_erase_key(hSil, hedefAnahtar);
      if (errErase != ESP_OK && errErase != ESP_ERR_NVS_NOT_FOUND) {
        kalLog("[KAL-NVS] nvs_erase_key hatasi (slot=%s): %s",
               hedefAnahtar, esp_err_to_name(errErase));
      }
      nvs_commit(hSil);
      nvs_close(hSil);
    } else {
      kalLog("[KAL-NVS] silme icin nvs_open hatasi: %s", esp_err_to_name(errSil));
    }
    ok = kalibrasyonBlobYaz(hedefAnahtar, blob, "2. deneme");
  }

  int aktifSayisi = 0;
  for (int i = 0; i < KAL_NOKTA_SAYISI; i++) if (blob.aktif[i]) aktifSayisi++;

  if (ok) {
    kalLog("[KAL-NVS] KAYIT BASARILI (slot=%s) GEN=%u AKTIF=%d",
           hedefAnahtar, (unsigned)yeniGen, aktifSayisi);
  } else {
    kalLog("[KAL-NVS] KAYIT HATASI (slot=%s): 2. denemeden sonra da basarisiz "
           "-- gercek NVS hata kodu icin yukaridaki satirlara bakin",
           hedefAnahtar);
  }
  return ok;
}

bool kalibrasyonuNVStenYukle() {
  KalibrasyonBlob blobA = {}, blobB = {};
  bool aVar = kalibrasyonBlobOku("blobA", blobA) && kalibrasyonBlobGecerliMi(blobA);
  bool bVar = kalibrasyonBlobOku("blobB", blobB) && kalibrasyonBlobGecerliMi(blobB);
  kalTaniBlobABuldu = aVar;
  kalTaniBlobBBuldu = bVar;

  const KalibrasyonBlob *secilen = nullptr;
  if (aVar && bVar) {
    secilen = (blobA.generation >= blobB.generation) ? &blobA : &blobB;
    strncpy(kalTaniSlot, (blobA.generation >= blobB.generation) ? "A" : "B", sizeof(kalTaniSlot));
  } else if (aVar) {
    secilen = &blobA;
    strncpy(kalTaniSlot, "A", sizeof(kalTaniSlot));
    kalLog("[KAL-NVS] UYARI: blobB bozuk/eksik, blobA yedeginden yuklendi.");
  } else if (bVar) {
    secilen = &blobB;
    strncpy(kalTaniSlot, "B", sizeof(kalTaniSlot));
    kalLog("[KAL-NVS] UYARI: blobA bozuk/eksik, blobB yedeginden yuklendi.");
  } else {
    strncpy(kalTaniSlot, "-", sizeof(kalTaniSlot));
    kalTaniGen = 0;
    kalLog("[KAL-NVS] Gecerli yedek bulunamadi (iki kopya da eksik/bozuk).");
    return false;
  }

  const KalibrasyonBlob &blob = *secilen;
  kalTaniGen = blob.generation;

  // ÖNCE GEÇİCİ VERİLERİ TAMAMEN DOĞRULA.
  // Böylece bozuk/yarım blob eski çalışan kalibrasyonu parça parça bozmaz.
  float tempDark[NDSC_KANAL];
  float tempBlank[NDSC_KANAL];
  KalPt tempPts[KAL_NOKTA_SAYISI];

  memcpy(tempDark, blob.dark, sizeof(tempDark));
  memcpy(tempBlank, blob.blank, sizeof(tempBlank));
  memcpy(tempPts, kalPts, sizeof(tempPts));

  for (int i = 0; i < KAL_NOKTA_SAYISI; i++) {
    tempPts[i].score = blob.score[i];
    tempPts[i].hedefPPM = blob.hedefPPM[i];  // KAL-DUZELTME: artik hedefPPM de geri yukleniyor
                                              // (eskiden varsayilan merdivende kalip skorla
                                              // eslesmiyordu).
    tempPts[i].aktif = blob.aktif[i] != 0;
  }

  // Blank noktası her zaman 0 ppm ve aktif olmalı. NOT: score alanına
  // artık DOKUNMUYORUZ -- bu, BLANK ÖLÇ sırasında GERÇEKTEN ölçülmüş
  // skor (bkz. ndscBlankOlc()); 0.0f'a zorlamak onu siler ve "hayalet"
  // PPM ofsetlerine (ör. blank 147 ppm okunması) geri döner.
  tempPts[0].hedefPPM = 0.0f;
  tempPts[0].aktif = true;

  // TÜM KONTROLLER BAŞARILI: şimdi tek adımda canlı kalibrasyona aktar.
  memcpy(darkSpectrum, tempDark, sizeof(darkSpectrum));
  memcpy(blankBeyaz, tempBlank, sizeof(blankBeyaz));
  memcpy(kalPts, tempPts, sizeof(kalPts));

  ndscBlankHazir = true;
  kal_blank_f5 = blankBeyaz[4];
  kal_s1Blank = blob.s1Blank;  // KAL-FIX-UYUM
  kal_s2Blank = blob.s2Blank;  // KAL-FIX-UYUM

  kalibrasyonGuncelle();
  kalibrasyonYedektenYuklendi = kalibrasyonGecerli;

  if (kalibrasyonGecerli) {
    kalLog("[KAL-NVS] ACILISTA KALIBRASYON YUKLENDI GEN=%u AKTIF=%d",
           (unsigned)blob.generation, kal_n);
  } else {
    kalLog("[KAL-NVS] ACILISTA YUKLENDI AMA GECERSIZ GEN=%u AKTIF=%d",
           (unsigned)blob.generation, kal_n);
  }
  kalibrasyonKartiniSeriYaz();
  return kalibrasyonGecerli;
}

void manualKalInputsHazirla() {
  for (int k = 0; k < NDSC_KANAL; k++) {
    manualKalInput[k] = String(darkSpectrum[k], 6);
    manualKalInput[8 + k] = String(blankBeyaz[k], 6);
  }
  for (int i = 1; i < KAL_NOKTA_SAYISI; i++) {
    int mi = 16 + (i - 1);
    manualKalInput[mi] = kalPts[i].aktif ? String(kalPts[i].score, 8) : "";
  }
}

bool ndscBlankOlc() {
  tumOlcumLedleriKapat();

  // Önce ışıklar kapalıyken karanlık referans.
  if (!ndscOkuOrtalama(darkSpectrum, NDSC_ORNEK)) {
    tumOlcumLedleriKapat();
    return false;
  }

  float yesil[NDSC_KANAL] = {0};
  float kirmizi[NDSC_KANAL] = {0};

  // Blank de gerçek ölçümle aynı 10 + 10 optik düzeni kullanır.
  if (!ndscIkiRenkOlc(yesil, kirmizi, -1, -1, -1)) {
    tumOlcumLedleriKapat();
    return false;
  }

  ikiSpektrumuOrtalama(yesil, kirmizi, blankBeyaz);

  tumOlcumLedleriKapat();
  ndscBlankHazir = true;
  kal_blank_f5 = blankBeyaz[4];

  // Yeni Blank optik referansı değiştiği için eski kalibrasyon noktalarını sil.
  for (int i = 0; i < KAL_NOKTA_SAYISI; i++) {
    kalPts[i].score = 0.0f;
    kalPts[i].hedefPPM = (i == 0) ? 0.0f : kalPts[i].hedefPPM;
    kalPts[i].aktif = (i == 0);
  }

  // KAL-FIX-UYUM: yeşil ve kırmızı LED'in blank tüpteki KENDİ (ham) skorlarını
  // ayrı ayrı kaydet -- ndscIkiRenkSkor() çağrısından ÖNCE, ki az aşağıdaki
  // "Gercek 0 ppm skoru" logundaki kalite de bu doğru tabana göre hesaplansın.
  // ndscIkiRenkSkor() içindeki uyum kontrolü bundan sonra s1/s2'yi bu iki
  // tabana göre karşılaştıracak (bkz. o fonksiyondaki KAL-FIX-UYUM notu).
  float qs1BlankAtilan = 0.0f, qs2BlankAtilan = 0.0f;
  kal_s1Blank = ndscSpectralScore(yesil, &qs1BlankAtilan);
  kal_s2Blank = ndscSpectralScoreKirmizi(kirmizi, &qs2BlankAtilan);
  kalLog("[BLANK] Kanal bazlari: s1Blank=%.6f s2Blank=%.6f", kal_s1Blank, kal_s2Blank);

  // ─── ÖNEMLİ DÜZELTME ────────────────────────────────────────────
  // "0 ppm noktasının skoru 0'dır" VARSAYIMI YANLIŞ: blankBeyaz, yeşil
  // ve kırmızı LED ölçümlerinin ORTALAMASI olduğu için, aynı blank
  // tüpü ndscIkiRenkSkor() ile yeniden ölçseniz bile (yeşil ve kırmızı
  // ayrı ayrı bu ortalamayla karşılaştırıldığı için) skor matematiksel
  // olarak tam 0 çıkmaz -- iki farklı renkli LED'in ham kanal
  // profilleri zaten birbirinden farklıdır. Bu yüzden 0'ı varsaymak
  // yerine, blank tüpün GERÇEK skorunu (az önce ölçtüğümüz aynı
  // yesil[]/kirmizi[] ile) hesaplayıp 0 ppm noktası olarak kaydediyoruz.
  // Böylece ileride aynı blank tekrar ölçüldüğünde skor bu gerçek
  // değere çok yakın çıkar ve PPM hesabı 0'a düşer (147 gibi hayalet
  // ofsetler oluşmaz).
  float blankKalite = 0.0f;
  float blankGercekSkor = ndscIkiRenkSkor(yesil, kirmizi, &blankKalite);
  kalPts[0].score = blankGercekSkor;
  kalLog("[BLANK] Gercek 0 ppm skoru: %.8f (kalite=%.1f)", blankGercekSkor, blankKalite);

  kal_b = 0.0f;
  kal_d = 0.0f;
  kal_R2 = -1.0f;
  kal_RMSE = -1.0f;
  kal_MAE = -1.0f;
  kal_Bias = 0.0f;
  kal_n = 0;
  kalibrasyonGecerli = false;

  // ─── ÖNEMLİ DÜZELTME ────────────────────────────────────────────
  // ESKİDEN burada kalibrasyonuNVSyeKaydet() çağrılıyordu. Bu, henüz
  // TEK BİR yeni standart bile girilmemişken (aktif nokta sayısı=0,
  // kalibrasyonGecerli=false) "boş" bir kalibrasyon durumunu ping-pong
  // NVS slotlarından birine EN GÜNCEL (en yüksek generation) kayıt
  // olarak yazıyordu. kalibrasyonBlobGecerliMi() bu boş durumu format
  // olarak GEÇERLİ sayabildiği için (dark/blank finite ve blank>dark
  // olabilir, score'lar 0), açılışta yükleme mantığı en yüksek
  // generation'ı seçtiğinde ESKİ SAĞLAM KALİBRASYON YERİNE bu boş
  // durumu geri getiriyordu -- yani kullanıcı BLANK ÖLÇ yapıp cihazı
  // kapatırsa (yeni standartları girmeden), kalibrasyon gerçekten
  // "unutuluyordu".
  //
  // ARTIK: burada NVS'ye YAZILMIYOR. Yeni blank + standartlar RAM'de
  // tutulur; kullanıcı en az blank+2 numune girip kalibrasyonGuncelle()
  // gerçekten GEÇERLİ bir regresyon ürettiğinde (bkz. numune giriş
  // akışındaki kalibrasyonuNVSyeKaydet() çağrıları) kayıt yapılır. Bu
  // sayede NVS'deki SON SAĞLAM kalibrasyon, yeni ölçüm tamamlanana
  // kadar dokunulmadan kalır: cihaz yarıda (blank ölçüldü ama yeni
  // standartlar girilmeden) kapatılıp açılırsa eski çalışan kalibrasyon
  // geri yüklenir, "kayboldu" görünmez.
  kalLog("[KAL-NVS] BLANK olculdu, standartlar bekleniyor (NVS'ye HENUZ yazilmadi)");
  kalibrasyonKartiniSeriYaz();
  return true;
}

// PPM = kal_b * NDSC_score + kal_d (kalibrasyon araligi disinda NAN doner)
float hesaplaPPM() {
  if (!ndscBlankHazir || !kalibrasyonGecerli) return NAN;
  if (!isfinite(sonNDSCScore)) return NAN;

  // ================================================================
  // NITRACHECK — ÇOK NOKTALI PARÇALI KALİBRASYON
  //
  // Eski sistem:
  //   PPM = b * SCORE + d
  //
  // Bu tek doğru (global lineer regresyon), gerçek ölçüm noktalarının
  // tamamından geçmek zorunda değildir. Özellikle senin verdiğin
  // değerlerde:
  //   BLANK  : SCORE 11.2  -> 0 ppm
  //   Nokta 1: SCORE 40.8  -> 55.438 ppm
  //   Nokta 2: SCORE 64.7  -> 67.846 ppm
  //   Nokta 3: SCORE 88.6  -> 80.668 ppm
  //
  // Bu nedenle tek regresyon kullanmak 55.438 ppm noktasını yaklaşık
  // 40 ppm civarına çekebiliyordu. Asıl sorun burada.
  //
  // Yeni sistem her iki komşu kalibrasyon noktası arasında LINEER
  // ENTERPOLASYON yapar. Böylece girilen gerçek standart değerleri
  // doğrudan referans alır ve kalibrasyon noktalarının kendisinde:
  //
  //   SCORE 11.2  -> 0.000 ppm
  //   SCORE 40.8  -> 55.438 ppm
  //   SCORE 64.7  -> 67.846 ppm
  //   SCORE 88.6  -> 80.668 ppm
  //
  // sonucu elde edilir.
  // ================================================================

  float aralik = kal_ScoreMax - kal_ScoreMin;
  float tol = fmaxf(fabsf(aralik) * 0.03f, 0.001f);

  if (sonNDSCScore < kal_ScoreMin - tol ||
      sonNDSCScore > kal_ScoreMax + tol) {
    return NAN;
  }

  // Gürültü nedeniyle uç noktadan çok az taşma varsa uç değere oturt.
  float score = sonNDSCScore;
  if (score < kal_ScoreMin) score = kal_ScoreMin;
  if (score > kal_ScoreMax) score = kal_ScoreMax;

  int onceki = -1;
  int sonraki = -1;
  float oncekiScore = -INFINITY;   // onceki icin: score'un HEMEN ALTINDAKI en yakin deger
  float sonrakiScore = INFINITY;   // sonraki icin: score'un HEMEN USTUNDEKI en yakin deger

  // ONEMLI: kalPts DIZI SIRASI, PPM/skor sirasiyla AYNI OLMAK ZORUNDA
  // DEGIL. "Numune ile kalibrasyon" akisinda kalPts[idx], kullanicinin
  // OLCUM SIRASINA gore doldurulur (bkz. numuneKalBosSlotBul()) --
  // standartlar farkli sirayla olculebilir. Bu yuzden burada dizide
  // "ilk bulunani kullan / ilk bulunca dur" mantigi KULLANILMAZ;
  // tum aktif noktalar taranip skor degerine gore GERCEKTEN en yakin
  // alt ve ust komsu bulunur.
  for (int i = 0; i < KAL_NOKTA_SAYISI; i++) {
    if (!kalPts[i].aktif) continue;
    if (!isfinite(kalPts[i].score) || !isfinite(kalPts[i].hedefPPM)) continue;

    if (fabsf(score - kalPts[i].score) <= 0.000001f) {
      float ppm = kalPts[i].hedefPPM;
      Serial.printf("[KAL-PARCALI] score=%.6f -> %.6f ppm (dogrudan kalibrasyon noktasi)\n",
                    sonNDSCScore, ppm);
      return fmaxf(ppm, 0.0f);
    }

    if (kalPts[i].score < score && kalPts[i].score > oncekiScore) {
      oncekiScore = kalPts[i].score;
      onceki = i;
    } else if (kalPts[i].score > score && kalPts[i].score < sonrakiScore) {
      sonrakiScore = kalPts[i].score;
      sonraki = i;
    }
  }

  // score, clamp sayesinde zaten [kal_ScoreMin, kal_ScoreMax] icinde;
  // dolayisiyla normalde hem onceki hem sonraki bulunur (esitlik durumu
  // yukarida dogrudan yakalanir). Yine de beklenmedik bir durumda tek
  // taraf eksikse, o taraftaki en yakin noktayi guvenli sekilde kullan.
  if (onceki < 0 && sonraki >= 0 && fabsf(score - kalPts[sonraki].score) <= tol) {
    return fmaxf(kalPts[sonraki].hedefPPM, 0.0f);
  }
  if (sonraki < 0 && onceki >= 0 && fabsf(score - kalPts[onceki].score) <= tol) {
    return fmaxf(kalPts[onceki].hedefPPM, 0.0f);
  }

  // Normal durumda iki komşu nokta arasında enterpolasyon.
  if (onceki >= 0 && sonraki >= 0) {
    float x1 = kalPts[onceki].score;
    float y1 = kalPts[onceki].hedefPPM;
    float x2 = kalPts[sonraki].score;
    float y2 = kalPts[sonraki].hedefPPM;

    float dx = x2 - x1;
    if (fabsf(dx) <= 1e-7f) return NAN;

    float oran = (score - x1) / dx;
    float ppm = y1 + oran * (y2 - y1);

    if (!isfinite(ppm)) return NAN;
    if (ppm < 0.0f) ppm = 0.0f;

    Serial.printf(
      "[KAL-PARCALI] score=%.6f | (%.6f -> %.3f ppm) "
      "(%.6f -> %.3f ppm) | sonuc=%.3f ppm\n",
      sonNDSCScore,
      x1, y1,
      x2, y2,
      ppm
    );

    return ppm;
  }

  // Aktif tek nokta / beklenmeyen kalibrasyon yapısı güvenli şekilde
  // sonuç üretmesin.
  return NAN;
}

void kalibrasyonGuncelle() {
  float sumX=0.0f, sumY=0.0f, sumXY=0.0f, sumXX=0.0f;
  int n=0;
  for (int i=0; i<KAL_NOKTA_SAYISI; i++) {
    if (!kalPts[i].aktif) continue;
    if (!isfinite(kalPts[i].score) || !isfinite(kalPts[i].hedefPPM)) continue;
    if (kalPts[i].hedefPPM < 0.0f) continue;
    sumX += kalPts[i].score;
    sumY += kalPts[i].hedefPPM;
    sumXY += kalPts[i].score * kalPts[i].hedefPPM;
    sumXX += kalPts[i].score * kalPts[i].score;
    n++;
  }

  kal_n = n;
  kalibrasyonGecerli = false;
  kal_R2 = -1.0f;
  kal_RMSE = -1.0f;
  kal_MAE = -1.0f;
  kal_Bias = 0.0f;
  kal_ScoreMin = 0.0f;
  kal_ScoreMax = 0.0f;
  kal_b = 0.0f;
  kal_d = 0.0f;

  for (int i = 0; i < KAL_NOKTA_SAYISI; ++i) {
    if (!kalPts[i].aktif) continue;
    if (!isfinite(kalPts[i].score) || !isfinite(kalPts[i].hedefPPM)) {
      kal_b = 0.0f; kal_d = 0.0f;
      kalLog("[Kal-NDSC8] GECERSIZ: NaN/Inf nokta i=%d", i);
      return;
    }
    for (int j = i + 1; j < KAL_NOKTA_SAYISI; ++j) {
      if (!kalPts[j].aktif) continue;
      if (fabsf(kalPts[i].hedefPPM - kalPts[j].hedefPPM) < 1e-6f) {
        kal_b = 0.0f; kal_d = 0.0f;
        kalLog("[Kal-NDSC8] GECERSIZ: ayni ppm iki kez kullanilmis (%.3f)", kalPts[i].hedefPPM);
        return;
      }
      if (kalPts[i].hedefPPM < kalPts[j].hedefPPM && kalPts[i].score > kalPts[j].score + 1e-5f) {
        kal_b = 0.0f; kal_d = 0.0f;
        kalLog("[Kal-NDSC8] GECERSIZ YON: %.1f>%.1f ppm ama skor tersi",
               kalPts[i].hedefPPM, kalPts[j].hedefPPM);
        return;
      }
      if (kalPts[i].hedefPPM > kalPts[j].hedefPPM && kalPts[i].score < kalPts[j].score - 1e-5f) {
        kal_b = 0.0f; kal_d = 0.0f;
        kalLog("[Kal-NDSC8] GECERSIZ YON: %.1f<%.1f ppm ama skor tersi",
               kalPts[i].hedefPPM, kalPts[j].hedefPPM);
        return;
      }
    }
  }

  if (n < 3) {
    kal_b = 0.0f;
    kal_d = 0.0f;
    kalLog("[Kal-NDSC8] YETERSIZ NOKTA n=%d (blank+2 standart gerekir)", n);
    return;
  }

  bool ilkSkor = true;
  kal_ScoreMin = 0.0f;
  kal_ScoreMax = 0.0f;
  for (int i = 0; i < KAL_NOKTA_SAYISI; ++i) {
    if (!kalPts[i].aktif) continue;
    if (ilkSkor) {
      kal_ScoreMin = kalPts[i].score;
      kal_ScoreMax = kalPts[i].score;
      ilkSkor = false;
    } else {
      if (kalPts[i].score < kal_ScoreMin) kal_ScoreMin = kalPts[i].score;
      if (kalPts[i].score > kal_ScoreMax) kal_ScoreMax = kalPts[i].score;
    }
  }

  float det = n*sumXX - sumX*sumX;
  if (!isfinite(det) || fabsf(det) <= 1e-9f) {
    kal_b = 0.0f;
    kal_d = 0.0f;
    kalLog("[Kal-NDSC8] GECERSIZ: kararsiz regresyon det=%.6g n=%d", det, n);
    return;
  }

  float b = (n*sumXY - sumX*sumY)/det;
  float d = (sumY - b*sumX)/n;

  if (!isfinite(b) || !isfinite(d) || b <= 0.0f) {
    kal_b = 0.0f;
    kal_d = 0.0f;
    kalLog("[Kal-NDSC8] GECERSIZ YON: egim b=%.6f n=%d. Tekrar olcun.", b, n);
    return;
  }

  kal_b = b;
  kal_d = d;

  // Kalibrasyon kalite metrikleri: R², RMSE, MAE ve Bias.
  // UI/raporlama eski veya anlamsız değer göstermesin diye yalnızca geçerli
  // regresyon kurulduktan sonra gerçek aktif noktalardan hesaplanır.
  float meanY = sumY / n;
  float ssRes = 0.0f;
  float ssTot = 0.0f;
  float sumAbs = 0.0f;
  float sumErr = 0.0f;

  for (int i = 0; i < KAL_NOKTA_SAYISI; ++i) {
    if (!kalPts[i].aktif) continue;
    float predicted = kal_b * kalPts[i].score + kal_d;
    float err = predicted - kalPts[i].hedefPPM;
    ssRes += err * err;
    sumAbs += fabsf(err);
    sumErr += err;

    float dy = kalPts[i].hedefPPM - meanY;
    ssTot += dy * dy;
  }

  kal_RMSE = sqrtf(ssRes / n);
  kal_MAE = sumAbs / n;
  kal_Bias = sumErr / n;

  if (ssTot > 1e-12f) {
    kal_R2 = 1.0f - (ssRes / ssTot);
  } else {
    kal_R2 = 1.0f;
  }

  if (!isfinite(kal_R2) || !isfinite(kal_RMSE) ||
      !isfinite(kal_MAE) || !isfinite(kal_Bias)) {
    kal_b = 0.0f;
    kal_d = 0.0f;
    kal_R2 = -1.0f;
    kal_RMSE = -1.0f;
    kal_MAE = -1.0f;
    kal_Bias = 0.0f;
    kalLog("[Kal-NDSC8] GECERSIZ: kalite metrikleri NaN/Inf");
    return;
  }

  kalibrasyonGecerli = true;
}

#if TEST_KALIBRASYON_AKTIF
// Kutu/LED donanımı olmadan UI + hesaplama akışını doğrulamak için
// sahte ama TUTARLI (score, ppm ile birlikte monoton artan) bir
// blank + 3 standart nokta seti yükler ve GERÇEK kalibrasyonGuncelle()
// fonksiyonunun üzerinden geçirir. Böylece regresyon, GEÇERLİ/GEÇERSİZ
// durumu ve hesaplaPPM() gerçekten test edilmiş olur.
// PPM DEĞERLERİ GERÇEK DEĞİLDİR. Gerçek kutu geldiğinde normal
// "BLANK ÖLÇ" akışı bu veriyi otomatik siler.
void testKalibrasyonUret() {
  kalLog("[TEST-KAL] Kutu/LED yokken test kalibrasyonu yukleniyor...");

  // Sahte dark/blank spektrumu: gercekci buyuklukte, sifirdan farkli.
  for (int k = 0; k < NDSC_KANAL; k++) {
    darkSpectrum[k] = 180.0f;
    blankBeyaz[k]   = 3000.0f;
  }
  ndscBlankHazir = true;
  kal_blank_f5 = blankBeyaz[4];

  // 0 ppm noktasi zaten aktif (score=0). 3 sahte standart nokta daha
  // ekliyoruz (indeks: hedefPPM dizisindeki 10, 50, 150 ppm noktalari).
  // score = ppm ile birlikte artacak sekilde uydurulmus, monotonluk
  // kontrolunu gecer.
  kalPts[0].score = 0.0f;   kalPts[0].aktif = true;   // 0 ppm
  kalPts[2].score = 0.10f;  kalPts[2].aktif = true;   // 10 ppm
  kalPts[4].score = 0.50f;  kalPts[4].aktif = true;   // 50 ppm
  kalPts[7].score = 1.50f;  kalPts[7].aktif = true;   // 150 ppm

  kalibrasyonGuncelle();

  // TEST MODU EK GUVENCE: kutu/LED yokken gercek okuma (ortam isigi)
  // uydurma noktalarin score araligina hic girmeyebilir, bu da her
  // olcumde "KALIBRASYON DISI" -> ekran hic degismez sonucunu verir.
  // Sadece test modunde araligi yapay olarak genis aciyoruz ki tam
  // akisi (PPM sayisinin degismesini) gorebilesin. Regresyonun
  // kendisi (kal_b/kal_d) degismiyor, sadece kabul araligi genisliyor.
  if (kalibrasyonGecerli) {
    kal_ScoreMin = -1000.0f;
    kal_ScoreMax = 1000.0f;
  }

  kalLog("[TEST-KAL] gecerli=%s b=%.4f d=%.4f n=%d",
             kalibrasyonGecerli ? "true" : "false", kal_b, kal_d, kal_n);
}
#endif

// ─── EKRAN GEÇİŞİ / FLICKER KORUMASI ─────────────────────────────
//
// CrowPanel 7" RGB panel tek tek çizim komutlarını anlık gösterebildiği
// için fillScreen()/çok sayıda draw* çağrısından oluşan tam sayfa
// yenilemelerde "blip" görülebilir. Burada ekranı kapatmıyoruz:
// arka ışığı kısa süre minimum seviyeye indirip yeni kareyi tamamen
// çiziyor, ardından eski parlaklığa geri dönüyoruz. Kullanıcı ara kareyi
// görmediği için geçiş kesintisiz görünür.
//
// setBacklight() uiBacklightLevel'i güncellediği için eski seviye ayrıca
// saklanır ve mutlaka geri yüklenir.
uint8_t ekranGecisBaslat() {
  uint8_t eskiSeviye = uiBacklightLevel;
  setBacklight(5);  // donanımda neredeyse minimum görünürlük
  return eskiSeviye;
}

void ekranGecisBitir(uint8_t eskiSeviye) {
  vTaskDelay(pdMS_TO_TICKS(20));
  setBacklight(eskiSeviye);
}

void drawScreenTransition(const char* baslik,
                          const char* altMetin,
                          IconType icon,
                          uint16_t accent = UI_CYAN) {
  // Geçiş ekranı zaten kullanıcıya gösterilecek opak bir ara ekran.
  // Burada backlight/I2C ile ekranı karartmak yerine doğrudan çiziyoruz.
  display.fillScreen(UI_BG);
  display.fillRoundRect(145, 72, 510, 336, 22, UI_PANEL);
  display.drawRoundRect(145, 72, 510, 336, 22, accent);
  display.fillRect(225, 72, 350, 4, accent);

  int cx = 400;
  int cy = 170;
  display.drawCircle(cx, cy, 48, accent);
  display.drawCircle(cx, cy, 40, UI_PANEL);
  drawIcon(icon, cx, cy, accent);

  drawCenteredText(baslik, cx, 238, FONT_BIG, UI_WHITE, UI_PANEL);
  drawCenteredText(altMetin, cx, 292, FONT_SMALL, UI_MUTED, UI_PANEL);
  drawCenteredText("Lütfen bekleyin...", cx, 326, FONT_SMALL, UI_CYAN, UI_PANEL);

}

// ─── ÖLÇÜM SONUCU EKRANI: ERKEN AÇILAN KABUK + GECİKMELİ DEĞER ─────
// Ölçümün TAM bitiş anında hissedilen son "blip" kaynağı şuydu:
// progress ekranından sonuç ekranına geçerken yapılan tek seferlik
// fillScreen() + tam kart çizimi, panelde donanımsal çift tamponlama
// olmadığı için görsel olarak fark ediliyordu (bkz. yukarıdaki RGB
// panel notu). Bu geçişi tamamen ortadan kaldırmak mümkün değil, ama
// kullanıcının "sonucun kendisiyle aynı anda titriyor" hissini
// vermesini engellemek mümkün: tam ekran geçiş artık sonuç sayısı
// ekrana yazılmadan ~2 saniye ÖNCE yapılıyor (kabuk + yer tutucu),
// sayı ise 2 saniye sonra sadece kendi küçük bölgesine (tam ekran
// yeniden çizim YAPILMADAN) yazılıyor. Böylece son "titreme" sonucun
// belirişinden zamanla ayrışıyor ve fark edilmiyor.

const int MC_PX = 24, MC_PY = 24, MC_PW = 752, MC_PH = 432;
const int MC_CX = 400;

// Tam ekran geçişin GERÇEKLEŞTİĞİ tek an: kart, ikon, başlık ve yer
// tutucu metinler çizilir. Sonuç sayısı burada HENÜZ yazılmaz.
void drawMeasurementCompleteShell() {
  // Burada EKranGecisBaslat()/setBacklight() KULLANILMIYOR.
  // Çünkü backlight STC8 üzerinden aynı I2C hattını paylaşır ve ölçümün
  // hemen sonundaki bu I2C işlemi kullanıcıya "blip" olarak görünebilir.
  // Bunun yerine doğrudan tek bir opak başarı ekranı çizilir.

  display.fillScreen(UI_BG);
  display.fillRoundRect(MC_PX, MC_PY, MC_PW, MC_PH, 26, UI_PANEL);
  display.drawRoundRect(MC_PX, MC_PY, MC_PW, MC_PH, 26, UI_LINE);
  display.fillRect(MC_PX + 90, MC_PY, MC_PW - 180, 5, UI_CYAN);

  display.drawCircle(MC_CX, MC_PY + 66, 44, UI_GREEN);
  drawIcon(ICON_CHECK, MC_CX, MC_PY + 66, UI_BG);

  drawCenteredText("ÖLÇÜM TAMAMLANDI", MC_CX, MC_PY + 122,
                   FONT_BIG, UI_WHITE, UI_PANEL);

  // Sonuç değeri ve durum rozeti burada değil, drawMeasurementCompleteValue()
  // içinde ve sadece kendi bölgesi yeniden boyanarak yazılır.
  drawCenteredText("Sonuç hesaplanıyor...", MC_CX, MC_PY + 230,
                   FONT_MEDIUM, UI_MUTED, UI_PANEL);

  drawCenteredText("Spektral veriler doğrulanıyor...", MC_CX, MC_PY + 396,
                   FONT_SMALL, UI_MUTED, UI_PANEL);
}

// Kabuk açıldıktan bir süre sonra çağrılır: yalnızca sayı, birim, durum
// rozeti ve alt bilgi metninin kapladığı KÜÇÜK bölgeler yeniden boyanır;
// display.fillScreen() veya kartın tamamı BİR DAHA çizilmez.
void drawMeasurementCompleteValue() {
  // Yer tutucu "Sonuç hesaplanıyor..." ve sonrasında yazılacak
  // değer+birim+rozetin kaplayacağı alanı tek seferde temizle.
  display.fillRect(MC_CX - 260, MC_PY + 170, 520, 210, UI_PANEL);

  char sonucBuf[20];
  snprintf(sonucBuf, sizeof(sonucBuf), "%.1f", uiLastNitrate);
  drawCenteredValueBold(sonucBuf, MC_CX, MC_PY + 190, FONT_BIG, UI_WHITE, UI_PANEL, 1.7f);
  drawCenteredText("ppm", MC_CX, MC_PY + 288, FONT_MEDIUM, UI_CYAN, UI_PANEL);

  const char* durum = durumMetin.length() > 0
                        ? durumMetin.c_str()
                        : nitrateDurumEtiketi(uiLastNitrate);
  uint16_t durumRenk = durumMetin.length() > 0
                         ? UI_RED
                         : nitrateDurumRengi(uiLastNitrate);
  drawStatusPill(MC_CX - 110, MC_PY + 336, 220, durum, durumRenk);

  // Alt bilgi metnini de "doğrulanıyor" yerine "hazır" mesajıyla değiştir
  // (yine sadece kendi tek satırlık bölgesi yeniden boyanır).
  drawCenteredText("Yeni ölçüme hazır", MC_CX, MC_PY + 396,
                   FONT_SMALL, UI_MUTED, UI_PANEL);
}
// ─── ÖLÇÜM SIRASINDA KİLİT + DOLAN YÜKLEME ANİMASYONU ──────────
// Bu bölüm UI katmanına aittir; NDSC-8 hesaplamasının kendisi
// değiştirilmedi, sadece yukarıdaki fonksiyonlar sırayla çağrılıp
// aradaki ilerleme ekranda gösteriliyor.

void drawLockedSideButtons() {
  // Ölçüm sırasında GÖRÜNÜŞ ana ekranla tamamen aynı kalır.
  // Sadece olcumKilitli=true olduğu için dokunuşlar işlenmez.
  drawFuturisticMenuButton(32, 306, 217, 34, "Yazdır",        ICON_PRINTER,  UI_CYAN, false);
  drawFuturisticMenuButton(32, 346, 217, 34, "Harita",        ICON_LOCATION, UI_CYAN, false);
  drawFuturisticMenuButton(32, 386, 217, 34, "Buluta Gönder", ICON_CLOUD,    UI_CYAN, false);
  drawFuturisticMenuButton(32, 426, 217, 34, "Ayarlar",       ICON_GEAR,     UI_CYAN, false);
}

// ─── ÖLÇÜM İLERLEME EKRANI: SABİT ÇERÇEVE + ANİMASYONLU GÜNCELLEME ──
// Eski davranış: her ilerleme adımında (drawMeasuringProgress) tüm panel
// (456x220) ve alt çubuk gövdesi (466x58) yeniden dolduruluyordu. Bu
// alan zaten doğru içerikle ekrandaydı; sadece yüzde/metin değiştiği
// halde her defasında komple yeniden boyanması "titreme" (flicker)
// olarak görülüyordu. Ayrıca yüzde büyük atlamalarla (10 -> 55) tek
// seferde çiziliyordu, bu da "beklerken pat diye zıplama" hissi
// veriyordu.
//
// Yeni davranış: değişmeyen çerçeve/kart/arka plan SADECE ölçüm başında
// bir kez (drawMeasuringProgressChrome) çizilir. Her ilerleme adımında
// (drawMeasuringProgressFrame) yalnızca değişen küçük alanlar -- ilerleme
// halkasının yeni dilimi, yüzde yazısı, (değiştiyse) durum satırı ve alt
// çubuğun yeni dolan kısmı -- güncellenir. mpAnimateTo ise iki yüzde
// arası farkı tek adımda değil, küçük adımlarla ve kısa gecikmelerle
// akıcı şekilde ilerleterek gerçek bir "dolma" animasyonu oluşturur.

int  mpDisplayedPercent = -1;      // -1: çerçeve henüz çizilmedi
char mpDisplayedStatus[48] = "";

// Spektral halka için sabit palet: mavi -> mor -> pembe -> kırmızı.
static uint16_t spectralProgressColor(int step) {
  const uint16_t pal[] = {
    rgb565(30, 110, 190),
    rgb565(65, 95, 200),
    rgb565(110, 80, 195),
    rgb565(165, 75, 185),
    rgb565(195, 85, 140),
    rgb565(200, 90, 95)
  };
  const int n = sizeof(pal) / sizeof(pal[0]);
  if (step < 0) step = 0;
  return pal[step % n];
}

void drawSpectralProgressParticles(int cx, int cy, int rOuter) {
  // Deterministik dijital parçacıklar: her ölçüm ekranında aynı dengeli
  // dağılım, ancak spektral renklere sahip. Yörünge yarıçapı artık
  // sabit sayılar yerine rOuter'a ORANTILI hesaplanıyor; böylece halka
  // büyütülüp küçültüldüğünde parçacık bulutu da otomatik uyum sağlar.
  for (int i = 0; i < 28; i++) {
    float a = (float)((i * 47) % 360) * 0.0174532925f;
    int r = rOuter + 16 + ((i * 19) % 36);
    int x = cx + (int)(cosf(a) * r);
    int y = cy + (int)(sinf(a) * r * 0.72f);
    uint16_t c = spectralProgressColor(i);
    if (i % 3 == 0) display.fillCircle(x, y, 2, c);
    else display.drawPixel(x, y, c);
  }
}

void drawMeasuringProgressChrome() {
  // İSTEK ÜZERİNE: panel artık üstte, boşta duran spektral grafiğin
  // kapladığı TAM alanla (294,94,476,286) birebir aynı dikdörtgeni
  // kaplıyor. Eskiden bu panel yalnızca (304,150,456,220) alanını
  // kaplıyordu; üstte kalan (y=94-150) şerit hiç temizlenmediği için
  // bir önceki "AS7341 SPEKTRAL ANALİZ" başlığı ve "Sinyal Şiddeti
  // (a.u.)" ekseni yazısı ölçüm sırasında halkanın üstünde kalıntı
  // olarak görünmeye devam ediyordu. Alt kenar (y=370) ve merkez X
  // (cx=532) bilerek AYNI bırakıldı; yalnızca üst/yanlar genişletildi,
  // bu yüzden halka/metin/parçacıkların konumu değişmedi.
  int px = 294, py = 94, pw = 476, ph = 276;
  display.fillRoundRect(px, py, pw, ph, 11, UI_PANEL2);
  display.drawRoundRect(px, py, pw, ph, 11, UI_LINE);

  // İSTEK ÜZERİNE: halka büyütüldü (72 -> 92) ve panel içinde -- "ÖLÇÜM
  // YAPILIYOR" yazısının üstünde kalan boşlukla panel üstü arasında --
  // dikeyde TAM ORTALANDI (eskiden cy=242 idi; halka küçük olduğu için
  // altında büyük bir boş alan kalıyor, halka panelin üst kısmına
  // yapışmış gibi görünüyordu).
  int cx = px + pw / 2;
  int cy = 222;
  int rOuter = 92;

  // Çok katmanlı spektral analiz halkasının sabit arka izi.
  display.drawArc(cx, cy, rOuter + 7, rOuter + 5, 0, 360, rgb565(16, 32, 52));
  display.drawArc(cx, cy, rOuter, rOuter - 14, 0, 360, UI_LINE);
  display.drawArc(cx, cy, rOuter - 18, rOuter - 20, 0, 360, rgb565(35, 44, 72));
  display.drawArc(cx, cy, rOuter - 28, rOuter - 30, 0, 360, rgb565(24, 38, 62));

  drawSpectralProgressParticles(cx, cy, rOuter);

  // Merkez tamamen sade: yüzde dışında belirsiz/ekstra metin yok.
  // Halka büyüdüğü için merkez daire de orantılı büyütüldü (38 -> 46).
  display.fillCircle(cx, cy, 46, UI_PANEL2);
  display.drawCircle(cx, cy, 46, rgb565(42, 62, 92));

  drawCenteredText("ÖLÇÜM YAPILIYOR", px + pw / 2, py + ph - 26,
                   FONT_SMALL, UI_WHITE, UI_PANEL2);

  int bx = 304, by = 392, bw = 466, bh = 58;
  display.fillRoundRect(bx, by, bw, bh, 9, UI_PANEL2);
  display.drawRoundRect(bx, by, bw, bh, 9, UI_CYAN);

  mpDisplayedPercent = 0;
  mpDisplayedStatus[0] = '\0';
}

void drawMeasuringProgressFrame(int percent, const char* status) {
  (void)status;
  if (percent < 0) percent = 0;
  if (percent > 100) percent = 100;

  int px = 294, py = 94, pw = 476, ph = 276;
  int cx = px + pw / 2;
  int cy = 222;
  int rOuter = 92;
  int prevPercent = (mpDisplayedPercent < 0) ? 0 : mpDisplayedPercent;

  // Yüzde ilerledikçe halka 6 spektral renk arasında akar.
  if (percent > prevPercent) {
    int startA = -90 + (360 * prevPercent / 100);
    int endA   = -90 + (360 * percent / 100);

    for (int a = startA; a < endA; a += 3) {
      int b = min(a + 3, endA);
      int idx = ((a + 90 + 720) / 18);
      uint16_t c = spectralProgressColor(idx);

      // İnce dış parıltı.
      uint16_t glow = blendColor565(UI_PANEL2, c, 30);
      display.drawArc(cx, cy, rOuter + 4, rOuter + 2, a, b, glow);
      // Ana halka.
      display.drawArc(cx, cy, rOuter, rOuter - 14, a, b, c);
    }

    // Dinamik dijital parçacık: ilerleme ucunun çevresinde kısa spektral iz.
    float angle = (-90.0f + 360.0f * percent / 100.0f) * 0.0174532925f;
    uint16_t head = spectralProgressColor(percent / 8);
    for (int k = 0; k < 4; k++) {
      int rr = rOuter + 12 + k * 4;
      int pxp = cx + (int)(cosf(angle + k * 0.09f) * rr);
      int pyp = cy + (int)(sinf(angle + k * 0.09f) * rr * 0.72f);
      display.fillCircle(pxp, pyp, k == 0 ? 3 : 1, head);
    }
  }

  // Merkez yüzde alanını temizle ve modern yüzdeyi çiz.
  // Halka büyüdüğü için merkez temizleme alanı da orantılı büyütüldü (30 -> 38).
  display.fillCircle(cx, cy, 38, UI_PANEL2);
  char pctBuf[8];
  snprintf(pctBuf, sizeof(pctBuf), "%%%d", percent);
  drawCenteredText(pctBuf, cx, cy - 12, FONT_MEDIUM, UI_WHITE, UI_PANEL2);

  // Alt ilerleme çubuğu.
  int bx = 304, by = 392, bw = 466, bh = 58;
  int prevFillW = (int)((float)(bw - 6) * prevPercent / 100.0f);
  int fillW = (int)((float)(bw - 6) * percent / 100.0f);
  if (fillW > prevFillW) {
    for (int x = prevFillW; x < fillW; x += 4) {
      uint8_t amt = (uint8_t)((x * 255L) / max(1, bw - 6));
      uint16_t c = blendColor565(rgb565(20, 210, 230), rgb565(30, 80, 255), amt);
      display.drawFastVLine(bx + 3 + x, by + 3, bh - 6, c);
    }
  }

  mpDisplayedPercent = percent;
}

// Görüntülenen yüzdeyi mevcut değerden hedefe kadar küçük adımlarla ve
// kısa gecikmelerle ilerletir; büyük yüzde atlamaları artık tek seferde
// "pat" diye değil, göz tarafından takip edilebilen akıcı bir dolma
// hareketi olarak gerçekleşir.
void mpAnimateTo(int target, const char* status) {
  if (target < 0) target = 0;
  if (target > 100) target = 100;

  int start = (mpDisplayedPercent < 0) ? 0 : mpDisplayedPercent;
  if (target <= start) {
    drawMeasuringProgressFrame(target, status);
    return;
  }

  for (int p = start + 1; p <= target; p++) {
    drawMeasuringProgressFrame(p, status);
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

// ─── HARİTA YÜKLEME EKRANI: TAM EKRAN BAĞLANMA/İNDİRME ANİMASYONU ──
// Eskiden HARİTA butonuna basılınca arka ışık düşürülüp (ekranGecisBaslat)
// sunucuya bağlanma + PNG indirme TAMAMEN o karartılmış pencere içinde
// yapılıyordu; kullanıcı indirme süresince yalnızca karanlık bir ekran
// görüyordu. Artık indirme öncesinde arka ışık HİÇ kısılmıyor; onun
// yerine ÖLÇÜM ilerleme halkasıyla aynı görsel dilde (bkz.
// drawMeasuringProgressChrome/Frame) tam ekran bir "bağlanılıyor /
// indiriliyor" animasyonu gösteriliyor. Harita RAM'e tamamen indikten
// SONRA -- son çizim titremesini gizlemek için -- kısa bir karartma
// penceresinde nihai harita ekranı çiziliyor (bkz. uiHandleTouch).
// ─── HARİTA YÜKLEME ANİMASYONU: İÇ HALKA → DIŞ HALKA SIRALI ──
// İlk halka tamamen dolar. Ardından dış halkaya geçilir ve o dolar.
// Yüzde geri ileri gitmez; böylece iki ayrı animasyon çakışmaz ve titreme azalır.
int hlDisplayedPercent = -1;
int hlInnerPercent = 0;
int hlOuterPercent = 0;

void drawHaritaLoadingChrome() {
  display.fillScreen(UI_BG);
  display.fillRoundRect(190, 84, 420, 312, 22, UI_PANEL);
  display.drawRoundRect(190, 84, 420, 312, 22, UI_CYAN);
  display.fillRect(270, 84, 260, 4, UI_CYAN);

  int cx = 400, cy = 220;
  // Dış halka önce boş görünür.
  display.drawArc(cx, cy, 82, 70, 0, 360, rgb565(16, 32, 52));
  // İç halka önce boş görünür.
  display.drawArc(cx, cy, 64, 52, 0, 360, UI_LINE);

  hlDisplayedPercent = -1;
  hlInnerPercent = 0;
  hlOuterPercent = 0;
}

void hlDrawArcProgress(int cx, int cy, int r1, int r2, int fromPercent, int toPercent) {
  if (toPercent <= fromPercent) return;
  int startA = -90 + (360 * fromPercent / 100);
  int endA   = -90 + (360 * toPercent / 100);
  for (int a = startA; a < endA; a += 3) {
    int b = min(a + 3, endA);
    int idx = ((a + 90 + 720) / 18);
    display.drawArc(cx, cy, r1, r2, a, b, spectralProgressColor(idx));
  }
}

// global yüzde 0..200: 0..100 iç halka, 100..200 dış halka.
void drawHaritaLoadingFrame(int percent, const char* durum) {
  if (percent < 0) percent = 0;
  if (percent > 200) percent = 200;

  int cx = 400, cy = 220;
  int yeniInner = min(percent, 100);
  int yeniOuter = max(0, percent - 100);

  // Önce iç halka tamamen dolar.
  if (yeniInner > hlInnerPercent) {
    hlDrawArcProgress(cx, cy, 64, 52, hlInnerPercent, yeniInner);
    hlInnerPercent = yeniInner;
  }

  // İç halka bittikten sonra dış halka dolmaya başlar.
  if (hlInnerPercent >= 100 && yeniOuter > hlOuterPercent) {
    hlDrawArcProgress(cx, cy, 82, 70, hlOuterPercent, yeniOuter);
    hlOuterPercent = yeniOuter;
  }

  // Yüzde sayacı ve alt durum metni her karede (18ms) değil, ~60ms'de
  // bir güncellenir (başlangıç/bitişte ve %100 sınırında mutlaka).
  // Halka her karede akıcı ilerlerken, ortadaki sayı her 18ms'de
  // silinip yeniden yazılırsa çift tamponlama olmayan bu RGB panelde
  // göz tarafından titreme olarak algılanıyordu; asıl titreme kaynağı
  // buydu.
  static unsigned long sonMetinMs = 0;
  bool metinZamaniGeldi = (millis() - sonMetinMs >= 60);
  bool sinirDegeri = (percent == 0 || percent == 100 || percent == 200);
  if (metinZamaniGeldi || sinirDegeri || hlDisplayedPercent < 0) {
    int gosterilen = (percent <= 100) ? percent : (percent - 100);
    display.fillCircle(cx, cy, 34, UI_PANEL);
    char pctBuf[8];
    snprintf(pctBuf, sizeof(pctBuf), "%%%d", gosterilen);
    drawCenteredText(pctBuf, cx, cy - 6, FONT_MEDIUM, UI_WHITE, UI_PANEL);

    display.fillRect(210, 364, 380, 26, UI_PANEL);
    drawCenteredText(durum, cx, 400, FONT_SMALL, UI_CYAN, UI_PANEL);

    sonMetinMs = millis();
  }

  hlDisplayedPercent = percent;
}

void hlAnimateTo(int target, const char* durum) {
  if (target < 0) target = 0;
  if (target > 200) target = 200;
  int start = (hlDisplayedPercent < 0) ? 0 : hlDisplayedPercent;
  if (target <= start) {
    drawHaritaLoadingFrame(start, durum);
    return;
  }
  for (int p = start + 1; p <= target; p++) {
    drawHaritaLoadingFrame(p, durum);
    vTaskDelay(pdMS_TO_TICKS(18));
  }
}

void drawHaritaLoadingHata(const char* mesaj) {
  int cx = 400, cy = 220;
  // Hata durumunda aktif dış halkayı kırmızıya tamamlamıyoruz; mevcut konumda bırakıyoruz.
  display.fillCircle(cx, cy, 34, UI_PANEL);
  drawCenteredText("HATA", cx, cy - 6, FONT_MEDIUM, UI_RED, UI_PANEL);
  display.fillRect(190, 364, 420, 26, UI_PANEL);
  drawCenteredText(mesaj, 400, 370, FONT_SMALL, UI_RED, UI_PANEL);
}

void haritaAgTask(void* pvParameters) {
  bool ok = geoapifyHaritayiYukle(HARITA_MAP_W, HARITA_MAP_H);
  if (haritaAgFirebaseYapilacak && firebaseHazir && WiFi.status() == WL_CONNECTED) {
    sonHaritaYenileme = millis();
    firebaseOku();
  }
  portENTER_CRITICAL(&haritaAgMux);
  haritaAgBasarili = ok;
  haritaAgBitti = true;
  haritaAgCalisiyor = false;
  haritaAgTaskHandle = nullptr;
  portEXIT_CRITICAL(&haritaAgMux);
  vTaskDelete(nullptr);
}

bool haritaAgBaslat() {
  if (haritaAgCalisiyor) return false;
  portENTER_CRITICAL(&haritaAgMux);
  haritaAgCalisiyor = true;
  haritaAgBitti = false;
  haritaAgBasarili = false;
  haritaAgFirebaseYapilacak = true;
  portEXIT_CRITICAL(&haritaAgMux);
  BaseType_t sonuc = xTaskCreatePinnedToCore(
    haritaAgTask, "HaritaAg", 12288, nullptr, 1, &haritaAgTaskHandle, 0);
  if (sonuc != pdPASS) {
    portENTER_CRITICAL(&haritaAgMux);
    haritaAgCalisiyor = false;
    haritaAgBitti = true;
    haritaAgBasarili = false;
    haritaAgTaskHandle = nullptr;
    portEXIT_CRITICAL(&haritaAgMux);
    geoapifyHaritaHata = "Harita task baslatilamadi";
    return false;
  }
  return true;
}

bool haritaYuklemeAnimasyonuVeBekle() {
  drawHaritaLoadingChrome();
  // 1. HALKA: Harita hazırlık aşaması. Önce tamamen dolar.
  hlAnimateTo(100, "Harita hazırlanıyor...");

  if (WiFi.status() != WL_CONNECTED) {
    geoapifyHaritaHata = "WiFi yok";
    drawHaritaLoadingHata("WiFi bağlantısı yok");
    delay(1200);
    return false;
  }
  if (!haritaAgBaslat()) {
    drawHaritaLoadingHata("Arka plan görevi başlatılamadı");
    delay(1200);
    return false;
  }

  // 2. HALKA: İç halka bittikten sonra dış halka çok yavaş dolar.
  // Ağ beklerken asla geri dönmez; süre bitse bile %95'te bekler.
  //
  // NOT: 1. halka (yukarıdaki hlAnimateTo) tamamen yerel bir animasyon;
  // henüz haritaAgBaslat() çağrılmadığı için hiçbir ağ trafiği yok.
  // 2. halka ise haritaAgTask'ın (HTTPS harita indirme + firebaseOku)
  // TAM OLARAK çalıştığı pencerede dönüyor. ESP32-S3'te PSRAM tek bir
  // paylaşımlı veri yolu üzerinden iki çekirdek tarafından da
  // kullanılıyor; framebuffer da PSRAM'de olduğundan, indirme
  // yoğunlaştıkça (akan HTTPS verisi PSRAM'e yazılırken) ekran
  // çizimleri PSRAM erişimi için bekliyor ve bu da "titreme" olarak
  // görülüyor. Çözüm ağı durdurmak değil, bu pencerede ekranı daha
  // seyrek/az yazmak: hem çizim aralığını hem de bekleme döngüsünün
  // uyanma sıklığını gevşetiyoruz ki UI PSRAM'e daha az sıklıkla,
  // daha az çakışarak dokunsun.
  int hedef = 101;
  unsigned long sonKare = millis();
  while (haritaAgCalisiyor && !haritaAgBitti) {
    if (millis() - sonKare >= 220) {
      if (hedef < 195) hedef++;
      drawHaritaLoadingFrame(hedef, "Harita yükleniyor...");
      sonKare = millis();
    }
    vTaskDelay(pdMS_TO_TICKS(25));
  }

  bool ok;
  portENTER_CRITICAL(&haritaAgMux);
  ok = haritaAgBasarili;
  portEXIT_CRITICAL(&haritaAgMux);
  if (!ok) {
    const char* msg = geoapifyHaritaHata.length() ? geoapifyHaritaHata.c_str() : "Harita indirilemedi";
    drawHaritaLoadingHata(msg);
    delay(1200);
    return false;
  }

  // Ağ gerçekten bittiğinde dış halka tamamlanır.
  hlAnimateTo(200, "Harita hazır!");
  delay(180);
  return true;
}

void nitrateOlcumCalistir() {
  olcumKilitli = true;
  drawLockedSideButtons();
  drawMeasuringProgressChrome();
  mpAnimateTo(0, "");

  // Sensorler bosta kapali/pasif duruyordu; olcumden hemen once
  // uyandirilip gercek begin() burada yapiliyor.
  mpAnimateTo(5, "");
  as7341YenidenBaslat();
  sht40YenidenBaslat();

  if (!as7341Hazir) {
    durumMetin = "AS7341 YOK";
    Serial.println("[NDSC] AS7341 hazir degil; olcum baslatilmadi.");
    mpAnimateTo(100, "");
    delay(600);
    sensorleriKapat();
    olcumKilitli = false;
    previousTouch = false;
    drawScreenTransition("ÖLÇÜM HATASI",
                         "AS7341 sensörü bulunamadı.",
                         ICON_DROP, UI_RED);
    delay(900);

    uint8_t eskiSeviye = ekranGecisBaslat();
    display.fillScreen(UI_BG);
    drawHeader("ÖLÇÜM");
    drawMainScreenPaneller();
    ekranGecisBitir(eskiSeviye);
    return;
  }

  tumOlcumLedleriKapat();

  // Ses, ölçümün GERÇEK başlangıcında açılır; ndscIkiRenkOlc() içindeki
  // yeşil+kırmızı LED taraması bitip kırmızı LED söndüğü anda kapatılır
  // (aşağıda). Böylece süre otomatik olarak gerçek sensör okuma
  // süresine uyar.
  isd1820SesBaslat();

  float yesil[NDSC_KANAL] = {0};
  float kirmizi[NDSC_KANAL] = {0};
  float ortalama[NDSC_KANAL] = {0};

  // Önce 10 YEŞİL, sonra 10 KIRMIZI ölçüm.
  drawMeasuringProgressFrame(10, "YEŞİL LED ile 10 ölçüm...");
  bool ok = ndscIkiRenkOlc(yesil, kirmizi);

  // Kırmızı LED (ndscIkiRenkOlc içinde) az önce söndü -> sesi durdur.
  isd1820SesDurdur();

  ikiSpektrumuOrtalama(yesil, kirmizi, ortalama);
  drawMeasuringProgressFrame(80, "KIRMIZI LED ile 10 ölçüm tamamlandı");

  tumOlcumLedleriKapat();

  if (ok) {
    for (int k = 0; k < NDSC_KANAL; k++)
      sonSpektrumBeyaz[k] = ortalama[k];

    sonSpektrumHazir = true;
  }

  mpAnimateTo(85, "");

  if (!ok) {
    durumMetin = "SENSOR HATASI";
    Serial.println("[NDSC] Sensor okuma hatasi.");
  } else {
    float kalite = 0.0f;
    sonNDSCScore = ndscIkiRenkSkor(yesil, kirmizi, &kalite);
    sonOptikKalite = kalite;

    if (!ndscBlankHazir) {
      sonucPPM = 0.0f;
      durumMetin = "BLANK GEREKLI";
      Serial.println("[NDSC] Blank yok; PPM hesaplanmadi.");
    } else if (!kalibrasyonGecerli) {
      sonucPPM = 0.0f;
      durumMetin = "KALIBRASYON GEREKLİ";
      Serial.println("[NDSC] Gecerli kalibrasyon yok; PPM hesaplanmadi.");
    } else {
      sonucPPM = hesaplaPPM();
      if (!isfinite(sonucPPM)) {
        sonucPPM = 0.0f;
        durumMetin = "KALIBRASYON DISI";
        Serial.printf("[NDSC] Score=%.6f kalibrasyon araligi disinda [%.6f, %.6f].\n",
                      sonNDSCScore, kal_ScoreMin, kal_ScoreMax);
      } else {
        durumMetin = "";
        uiLastNitrate = sonucPPM;
        uiHasMeasurement = true;

        // ADIM16: Ölçüm biter bitmez sonucu yalnızca RAM'e ekle.
        // Flash yazımı sonuç ekranından ve ana ekran geçişinden ayrıdır.
        yeniOlcumuRAMeEkle(sonucPPM);
        // Adres sorgusu UI/yazdırma anında bekletilmez; ölçüm sonrası arka planda hazırlanır.
        reverseGeocodeIstegi(sonOlcumLat, sonOlcumLon);
      }
    }
    Serial.printf("[NDSC] Score=%.6f OptikKalite=%.1f%% PPM=%.2f\n",
                  sonNDSCScore, sonOptikKalite, sonucPPM);
  }

  mpAnimateTo(97, "");
  // Ölçüm sonunda AS7341'e yeni bir I2C komutu gönderilmiyor.
  // Ortak GT911/STC8/AS7341 hattı sonuç ekranına kadar sessiz kalıyor.
  sensorleriKapat();

  // %100 animasyonu burada YAPILMIYOR.
  // %97'den doğrudan sonuç kabuğuna geçiyoruz. Böylece son ölçüm
  // anındaki gereksiz son progress çizimleri azaltılıyor.

  olcumKilitli = false;
  previousTouch = false;

  if (uiHasMeasurement) {
    // Tam ekran geçiş (fillScreen + kart) artık sonucun kendisi
    // yazılmadan 2 saniye ÖNCE yapılır (kabuk + "hesaplanıyor" yer
    // tutucusu). Sayı, birim ve durum rozeti 2 saniye sonra SADECE
    // kendi küçük bölgesine yazılır -- bir daha tam ekran çizim
    // yapılmaz. Böylece ölçümün tam bitişinde hissedilen son "blip",
    // sonucun ekrana gelişinden zamanla ayrışır ve fark edilmez.
    drawMeasurementCompleteShell();
    delay(2000);
    drawMeasurementCompleteValue();
    delay(2500);
  } else {
    drawScreenTransition("ÖLÇÜM HATASI",
                         durumMetin.length() ? durumMetin.c_str()
                                             : "Ölçüm tamamlanamadı.",
                         ICON_DROP, UI_RED);
    buzzerError();
    delay(900);
  }

  if (uiHasMeasurement) {
    buzzerSuccess();
  }

  // Başarı ekranından ana ekrana doğrudan dönülür.
  // Backlight/I2C geçişi yapılmaz.
  display.fillScreen(UI_BG);
  drawHeader("ÖLÇÜM");
  drawMainScreenPaneller();
}

// ─── KALİBRASYON ŞİFRE EKRANI ───────────────────────────────────
// Sadece dokunma yoluyla kalibrasyon ekranına kazara/yetkisiz
// girişi engellemek için basit bir sayısal tuş takımı. Şifre
// kaynak kodda sabit (KALIBRASYON_SIFRE) tanımlıdır.

// Tuş takımı: 3 sütun x 4 satır (1-9, SİL / 0 / GERİ).
// idx: 0-8 -> "1".."9", 9 -> "SİL", 10 -> "0", 11 -> "GERİ"
// NOT: Arduino IDE, sketch içindeki fonksiyonlar için otomatik prototip
// üretirken özel struct döndüren fonksiyonlarda struct tanımından önce
// prototip ekleyip derleme hatası verebiliyor. Bu yüzden struct yerine
// referans (&) parametrelerle (kalNoktaButonRect ile aynı desen) dönüyoruz.
void passwordKeyRect(int idx, int &kx, int &ky, int &kw, int &kh) {
  int col = idx % 3;
  int row = idx / 3;

  int startX = 249, startY = 200;
  int w = 90, h = 52, gapX = 16, gapY = 12;

  kw = w;
  kh = h;
  kx = startX + col * (w + gapX);
  ky = startY + row * (h + gapY);
}

const char* passwordKeyLabel(int idx) {
  static const char* etiketler[12] = {
    "1","2","3","4","5","6","7","8","9","sil","0","geri"
  };
  return etiketler[idx];
}

void drawCalibrationPasswordScreen() {
  display.fillScreen(UI_BG);
  drawHeader("KALİBRASYON ŞİFRESİ");

  int px = 200, py = 90, pw = 400, ph = 380;
  display.fillRoundRect(px, py, pw, ph, 14, UI_PANEL);
  display.drawRoundRect(px, py, pw, ph, 14, UI_LINE);

  drawCenteredText("KALİBRASYON ŞİFRESİNİ GİRİN", px + pw / 2, py + 18,
                   FONT_SMALL, UI_WHITE, UI_PANEL);

  // Girilen hane sayısı kadar dolu, kalanı boş nokta göster.
  int dotCount = KALIBRASYON_SIFRE_UZUNLUK;
  int dotSpacing = 34;
  int dotsStartX = px + pw / 2 - (dotCount - 1) * dotSpacing / 2;
  int dotY = py + 58;
  for (int i = 0; i < dotCount; i++) {
    int dx = dotsStartX + i * dotSpacing;
    if (i < (int)kalibrasyonSifreGirisi.length()) {
      display.fillCircle(dx, dotY, 7, UI_CYAN);
    } else {
      display.drawCircle(dx, dotY, 7, UI_LINE);
    }
  }

  drawCenteredText(kalibrasyonSifreHatali ? "YANLIŞ ŞİFRE" : "",
                   px + pw / 2, py + 84, FONT_SMALL, UI_RED, UI_PANEL);

  // Tuş takımı (0-8: 1-9, 9: SİL, 10: 0, 11: GERİ)
  for (int i = 0; i < 12; i++) {
    int rx, ry, rw, rh;
    passwordKeyRect(i, rx, ry, rw, rh);
    uint16_t accent = UI_CYAN;
    if (i == 9) accent = UI_ORANGE;   // SİL
    if (i == 11) accent = UI_RED;     // GERİ
    drawButton(rx, ry, rw, rh, passwordKeyLabel(i), accent);
  }
}

void uiHandleCalibrationPasswordTouch(int32_t tx, int32_t ty) {
  for (int i = 0; i < 12; i++) {
    int rx, ry, rw, rh;
    passwordKeyRect(i, rx, ry, rw, rh);
    if (tx < rx || tx > rx + rw || ty < ry || ty > ry + rh) continue;

    if (i == 11) {
      // GERİ -> AYARLAR
      kalibrasyonSifreGirisi = "";
      kalibrasyonSifreHatali = false;
      currentScreen = SCREEN_SETTINGS;
      drawSimplePage(currentScreen);
      return;
    }

    if (i == 9) {
      // SİL -> son haneyi sil
      if (kalibrasyonSifreGirisi.length() > 0) {
        kalibrasyonSifreGirisi.remove(kalibrasyonSifreGirisi.length() - 1);
      }
      kalibrasyonSifreHatali = false;
      drawCalibrationPasswordScreen();
      return;
    }

    // Rakam tuşu (0-8 -> '1'-'9', 10 -> '0')
    char girilenRakam = (i == 10) ? '0' : (char)('1' + i);

    if ((int)kalibrasyonSifreGirisi.length() < KALIBRASYON_SIFRE_UZUNLUK) {
      kalibrasyonSifreGirisi += girilenRakam;
      kalibrasyonSifreHatali = false;
    }

    if ((int)kalibrasyonSifreGirisi.length() == KALIBRASYON_SIFRE_UZUNLUK) {
      if (kalibrasyonSifreGirisi == KALIBRASYON_SIFRE) {
        kalibrasyonSifreGirisi = "";
        kalibrasyonSifreHatali = false;
        currentScreen = SCREEN_CALIBRATION;
        drawCalibrationScreen();
      } else {
        drawCalibrationPasswordScreen();  // son haneyi dolu göster
        delay(500);
        kalibrasyonSifreGirisi = "";
        kalibrasyonSifreHatali = true;
        drawCalibrationPasswordScreen();
      }
      return;
    }

    drawCalibrationPasswordScreen();
    return;
  }
}

// ─── KALİBRASYON EKRANI ─────────────────────────────────────────

void drawCalibrationProgress(int percent, const char* status) {
  if (percent < 0) percent = 0;
  if (percent > 100) percent = 100;

  int px = 70, py = 90, pw = 660, ph = 300;
  display.fillRoundRect(px, py, pw, ph, 14, UI_PANEL);
  display.drawRoundRect(px, py, pw, ph, 14, UI_LINE);

  int cx = px + pw / 2;
  int cy = py + 130;
  int rOuter = 55;

  display.drawArc(cx, cy, rOuter, rOuter - 16, 0, 360, UI_LINE);
  if (percent > 0) {
    display.drawArc(cx, cy, rOuter, rOuter - 16, -90, -90 + (360 * percent / 100), UI_CYAN);
  }

  char pctBuf[8];
  snprintf(pctBuf, sizeof(pctBuf), "%%%d", percent);
  drawCenteredText(pctBuf, cx, cy - 16, FONT_MEDIUM, UI_WHITE, UI_PANEL);

  drawCenteredText("KALİBRASYON", cx, py + 220, FONT_SMALL, UI_WHITE, UI_PANEL);
  drawCenteredText(status, cx, py + 248, FONT_SMALL, UI_MUTED, UI_PANEL);
}

// Kalibrasyon noktası butonlarının koordinatlarını hesaplayan yardımcı.
// 10 nokta -> 5 sütun x 2 satır grid. uiHandleTouch() bu fonksiyonun
// döndürdüğü aynı koordinatları kullanır, tek kaynak burasıdır.
void kalNoktaButonRect(int idx, int &bx, int &by, int &bw, int &bh) {
  // idx: 1..10 -> 5 sütun x 2 satır.
  // Panel: px=30, pw=740 (drawCalibrationScreen ile aynı). İç kullanılabilir
  // genişlik: 680px (her yanda 30px boşluk), 5 buton + 4 aralık bu alana sığar.
  int col = (idx - 1) % 5;
  int row = (idx - 1) / 5;

  int startX = 60;   // px(30) + 30
  int startY = 230;
  bw = 124;
  bh = 54;
  int gapX = 14;
  int gapY = 16;

  bx = startX + col * (bw + gapX);
  by = startY + row * (bh + gapY);
}

void drawCalibrationScreen() {
  display.fillScreen(UI_BG);
  drawHeader("KALİBRASYON");

  int px = 30, py = 84, pw = 740, ph = 380;
  display.fillRoundRect(px, py, pw, ph, 14, UI_PANEL);
  display.drawRoundRect(px, py, pw, ph, 14, UI_LINE);

  drawCenteredText("KALİBRASYON", px + pw / 2, py + 12, FONT_MEDIUM, UI_WHITE, UI_PANEL);

  char durum1[48];
  snprintf(durum1, sizeof(durum1), "Blank: %s", ndscBlankHazir ? "HAZIR" : "GEREKLİ");
  drawLeftText(durum1, px + 30, py + 48, FONT_SMALL,
               ndscBlankHazir ? UI_GREEN : UI_ORANGE, UI_PANEL);

  char durum2[48];
  snprintf(durum2, sizeof(durum2), "Aktif nokta: %d/%d", kal_n, KAL_NOKTA_SAYISI - 1);
  drawLeftText(durum2, px + 260, py + 48, FONT_SMALL, UI_WHITE, UI_PANEL);

  drawLeftText(kalibrasyonGecerli ? "Kalibrasyon: GEÇERLİ" : "Kalibrasyon: GEÇERSİZ",
               px + 520, py + 48, FONT_SMALL,
               kalibrasyonGecerli ? UI_GREEN : UI_RED, UI_PANEL);

  drawButton(px + 30, py + 76, pw - 60, 46, "blank ölç", UI_CYAN, ICON_DROP, true);

  // 10 standart nokta: 5 sütun x 2 satır grid.
  char etiket[20];
  for (int i = 1; i < KAL_NOKTA_SAYISI; i++) {
    int bx, by, bw, bh;
    kalNoktaButonRect(i, bx, by, bw, bh);
    snprintf(etiket, sizeof(etiket), "%g ppm", kalPts[i].hedefPPM);
    drawButton(bx, by, bw, bh, etiket, UI_CYAN, ICON_NONE, kalPts[i].aktif);
  }

  // Bilinen değerli numune(ler) ile serbest noktalı kalibrasyon.
  // (10 standart nokta grid'i y=230..354 arasında biter; bu buton
  // onun altında, alttaki "manuel giriş"/"geri" satırından önce yer alır.)
  drawButton(px + 30, 364, pw - 60, 44, "numune ile kalibrasyon", UI_GREEN, ICON_DROP);

  // Kalibrasyon yedeğini kağıttaki değerlere göre geri kurmak için manuel giriş.
  drawButton(70, 420, 220, 44, "manuel giriş", UI_ORANGE);
  // Serial güvenilir olmayabildiği için kalibrasyon log geçmişini ekranda
  // gösteren buton (kalLogEkraniGoster()).
  drawButton(300, 420, 110, 44, "LOG", UI_MUTED);
  drawButton(430, 420, 300, 44, "geri", UI_CYAN);
}

void kalibrasyonBlankCalistir() {
  olcumKilitli = true;
  drawCalibrationProgress(0, "Sensörler açılıyor...");
  as7341YenidenBaslat();
  sht40YenidenBaslat();

  bool ok = false;
  if (as7341Hazir) {
    drawCalibrationProgress(10, "Blank: 10 yeşil + 10 kırmızı ölçüm...");
    ok = ndscBlankOlc();
  }

  drawCalibrationProgress(95, "Sensörler kapatılıyor...");
  sensorleriKapat();

  drawCalibrationProgress(100, ok ? "Blank tamamlandı" : "Blank HATASI");
  delay(400);

  olcumKilitli = false;
  drawCalibrationScreen();
}

void kalibrasyonStandartOlc(int idx) {
  if (idx < 0 || idx > KAL_NOKTA_SAYISI - 1) return;

  if (!ndscBlankHazir) {
    olcumKilitli = true;
    drawCalibrationProgress(0, "ÖNCE BLANK ÖLÇÜN");
    delay(700);
    olcumKilitli = false;
    drawCalibrationScreen();
    return;
  }

  olcumKilitli = true;
  drawCalibrationProgress(0, "Sensörler açılıyor...");
  as7341YenidenBaslat();
  sht40YenidenBaslat();
  ndscLed(false);

  float yesil[NDSC_KANAL] = {0};
  float kirmizi[NDSC_KANAL] = {0};
  bool ok = false;

  if (as7341Hazir) {
    drawCalibrationProgress(15, "10 yeşil + 10 kırmızı ölçüm...");
    ok = ndscIkiRenkOlc(yesil, kirmizi, -1, -1, -1);
  }

  tumOlcumLedleriKapat();
  drawCalibrationProgress(85, "Hesaplanıyor...");

  if (ok) {
    float kalite = 0.0f;
    float score = ndscIkiRenkSkor(yesil, kirmizi, &kalite);
    kalPts[idx].score = score;
    kalPts[idx].aktif = true;
    kalibrasyonGuncelle();
    // NOT (ADIM-FIX): Eskiden burada kalibrasyonGecerli'ye bakılmadan her
    // TEK noktadan sonra kalibrasyonuNVSyeKaydet() çağrılıyordu. Regresyon
    // henüz GEÇERSİZ olsa bile (blank + 1 standart, n<3) bu "yarım" durum
    // yine de ping-pong slotlarından birine EN YÜKSEK generation olarak
    // yazılıyordu -- kalibrasyonBlobGecerliMi() artık sadece NaN/Inf/tüm-
    // sıfır kontrolü yaptığı için bu yarım kayıt "geçerli blob" sayılıp
    // açılışta eski SAĞLAM kalibrasyonun yerine seçiliyordu. Yani cihaz,
    // ikinci standart girilmeden kapatılıp açılırsa kalibrasyon "unutulmuş"
    // gibi görünüyordu. Artık NVS'ye sadece kalibrasyonGecerli==true
    // olduğunda (yeterli sayıda tutarlı nokta girildiğinde) yazılıyor;
    // eksik/tek noktalı durum yalnızca RAM'de kalır, eski geçerli kayıt
    // NVS'de dokunulmadan durur.
    bool kaydedildi = false;
    if (kalibrasyonGecerli) {
      kaydedildi = kalibrasyonuNVSyeKaydet();
      kalibrasyonKartiniSeriYaz();
    } else {
      kalLog("[KAL-NVS] Nokta RAM'de, NVS'ye HENUZ yazilmadi (n=%d)", kal_n);
    }
    drawCalibrationProgress(95, "Sensörler kapatılıyor...");
    sensorleriKapat();
    if (!kalibrasyonGecerli) {
      drawCalibrationProgress(100, "Nokta alındı (kayıt için daha fazla nokta gerekli)");
    } else if (kaydedildi) {
      drawCalibrationProgress(100, "Nokta kaydedildi");
    } else {
      drawCalibrationProgress(100, "NOKTA ALINDI AMA NVS YAZMA HATASI");
    }
  } else {
    drawCalibrationProgress(95, "Sensörler kapatılıyor...");
    sensorleriKapat();
    drawCalibrationProgress(100, "SENSÖR HATASI");
  }
  delay(400);

  olcumKilitli = false;
  drawCalibrationScreen();
}

// ADIM17-FIX: SCREEN_CALIBRATION için dokunma işleyicisi eksikti; bu
// yüzden BLANK ÖLÇ, 9 standart nokta butonu ve GERİ hiçbiri çalışmıyordu.
// Koordinatlar drawCalibrationScreen() / kalNoktaButonRect() ile birebir
// aynıdır.
void uiHandleCalibrationTouch(int32_t tx, int32_t ty) {
  int px = 30, py = 84, pw = 740;

  // BLANK ÖLÇ
  if (tx >= px + 30 && tx <= px + 30 + (pw - 60) &&
      ty >= py + 76 && ty <= py + 76 + 46) {
    kalibrasyonBlankCalistir();
    return;
  }

  // 10 standart nokta (1..KAL_NOKTA_SAYISI-1): 5 sütun x 2 satır grid.
  for (int i = 1; i < KAL_NOKTA_SAYISI; i++) {
    int bx, by, bw, bh;
    kalNoktaButonRect(i, bx, by, bw, bh);
    if (tx >= bx && tx <= bx + bw && ty >= by && ty <= by + bh) {
      kalibrasyonStandartOlc(i);
      return;
    }
  }

  // NUMUNE İLE KALİBRASYON
  if (tx >= px + 30 && tx <= px + 30 + (pw - 60) && ty >= 364 && ty <= 408) {
    numuneKalAdim = 0;
    numuneKalBekleyenIdx = -1;
    numuneKalGirisMetni = "";
    numuneKalHataMetni = "";
    currentScreen = SCREEN_CALIBRATION_NUMUNE;
    drawCalibrationNumuneScreen();
    return;
  }

  // MANUEL GİRİŞ
  if (tx >= 70 && tx <= 290 && ty >= 420 && ty <= 464) {
    manualKalPage = 0;
    manualKalSelected = -1;
    manualKalInputsHazirla();
    currentScreen = SCREEN_CALIBRATION_MANUAL;
    drawCalibrationManualScreen();
    return;
  }

  // LOG (Serial güvenilir olmayabilir diye ekran üzeri kalibrasyon logu)
  if (tx >= 300 && tx <= 410 && ty >= 420 && ty <= 464) {
    kalLogEkraniGoster();
    drawCalibrationScreen();
    return;
  }

  // GERİ -> AYARLAR
  if (tx >= 430 && tx <= 730 && ty >= 420 && ty <= 464) {
    currentScreen = SCREEN_SETTINGS;
    drawSimplePage(currentScreen);
    return;
  }
}

// ─── NUMUNE İLE KALİBRASYON (bilinen değerli numune ile serbest nokta) ──
// kalPts[1..10] arasında dolu (aktif) kaç nokta olduğunu sayar.
int numuneKalAktifSayisi() {
  int c = 0;
  for (int i = 1; i < KAL_NOKTA_SAYISI; i++) if (kalPts[i].aktif) c++;
  return c;
}

// kalPts[1..10] içinde ilk boş (henüz ölçülmemiş) indeksi döndürür, yoksa -1.
int numuneKalBosSlotBul() {
  for (int i = 1; i < KAL_NOKTA_SAYISI; i++) if (!kalPts[i].aktif) return i;
  return -1;
}

// kalibrasyonBlankCalistir() ile birebir aynı, tek farkı sonunda
// drawCalibrationScreen() yerine drawCalibrationNumuneScreen()'e dönmesi.
// ndscBlankOlc() zaten kalPts[1..10]'u otomatik sıfırladığı için, BLANK
// ÖLÇ her basıldığında numune kalibrasyonu da "sıfırdan" başlamış olur.
void kalibrasyonBlankCalistirNumune() {
  olcumKilitli = true;
  drawCalibrationProgress(0, "Sensörler açılıyor...");
  as7341YenidenBaslat();
  sht40YenidenBaslat();

  bool ok = false;
  if (as7341Hazir) {
    drawCalibrationProgress(10, "Blank: 10 yeşil + 10 kırmızı ölçüm...");
    ok = ndscBlankOlc();
  }

  drawCalibrationProgress(95, "Sensörler kapatılıyor...");
  sensorleriKapat();

  drawCalibrationProgress(100, ok ? "Blank tamamlandı" : "Blank HATASI");
  delay(400);

  numuneKalAdim = 0;
  numuneKalBekleyenIdx = -1;
  numuneKalGirisMetni = "";
  numuneKalHataMetni = ok ? "" : "BLANK HATASI, TEKRAR DENEYİN";

  olcumKilitli = false;
  drawCalibrationNumuneScreen();
}

// Numuneyi ölçer (kalibrasyonStandartOlc() ile aynı optik akış), ancak
// hedef ppm'i HENÜZ BİLİNMEDİĞİ için kalPts[idx].hedefPPM'i atamaz;
// bunun yerine skoru geçici olarak saklayıp değer giriş ekranına geçer.
void numuneKalOlcYap() {
  if (!ndscBlankHazir) {
    olcumKilitli = true;
    drawCalibrationProgress(0, "ÖNCE BLANK ÖLÇÜN");
    delay(700);
    olcumKilitli = false;
    drawCalibrationNumuneScreen();
    return;
  }

  int idx = numuneKalBosSlotBul();
  if (idx < 0) {
    numuneKalHataMetni = "EN FAZLA 10 NUMUNE GİRİLEBİLİR";
    drawCalibrationNumuneScreen();
    return;
  }

  olcumKilitli = true;
  drawCalibrationProgress(0, "Sensörler açılıyor...");
  as7341YenidenBaslat();
  sht40YenidenBaslat();
  ndscLed(false);

  float yesil[NDSC_KANAL] = {0};
  float kirmizi[NDSC_KANAL] = {0};
  bool ok = false;

  if (as7341Hazir) {
    drawCalibrationProgress(15, "10 yeşil + 10 kırmızı ölçüm...");
    ok = ndscIkiRenkOlc(yesil, kirmizi, -1, -1, -1);
  }

  tumOlcumLedleriKapat();
  drawCalibrationProgress(85, "Hesaplanıyor...");
  sensorleriKapat();

  if (ok) {
    float kalite = 0.0f;
    float score = ndscIkiRenkSkor(yesil, kirmizi, &kalite);
    // NOT: aktif=false kalır; değer girilip onaylanana kadar bu nokta
    // kalibrasyon hesabına (kalibrasyonGuncelle) dahil edilmez.
    kalPts[idx].score = score;
    numuneKalBekleyenIdx = idx;
    numuneKalGirisMetni = "";
    numuneKalHataMetni = "";
    drawCalibrationProgress(100, "Ölçüm tamam");
    delay(300);
    numuneKalAdim = 1;
  } else {
    numuneKalHataMetni = "SENSÖR HATASI, TEKRAR DENEYİN";
    drawCalibrationProgress(100, "SENSÖR HATASI");
    delay(400);
  }

  olcumKilitli = false;
  if (numuneKalAdim == 1) drawCalibrationNumuneGirisScreen();
  else drawCalibrationNumuneScreen();
}

// Klavyeden girilen ppm metnini doğrular, kalPts[idx]'e yazar ve
// kalibrasyonu (kalibrasyonGuncelle) yeniden hesaplar. Ölçüm/değer
// tutarsızsa (ör. ppm artarken skor azaldıysa) noktayı geri alır.
bool numuneKalDegerUygula() {
  if (numuneKalBekleyenIdx < 0) {
    numuneKalHataMetni = "ÖNCE NUMUNE ÖLÇÜN";
    return false;
  }

  float v = 0.0f;
  if (!manualKalParseFloat(numuneKalGirisMetni, v) || v < 0.0f) {
    numuneKalHataMetni = "GEÇERSİZ DEĞER";
    return false;
  }

  int idx = numuneKalBekleyenIdx;
  kalPts[idx].hedefPPM = v;
  kalPts[idx].aktif = true;

  kalibrasyonGuncelle();

  // n<3 (blank + <2 numune) iken GEÇERSİZ olması normaldir, henüz hata
  // değildir. Ancak >=2 numune varken hâlâ GEÇERSİZse (yön/tutarlılık
  // hatası) bu son noktayı geri alıp kullanıcıyı uyar.
  if (!kalibrasyonGecerli && numuneKalAktifSayisi() >= 2) {
    kalPts[idx].aktif = false;
    kalPts[idx].hedefPPM = 0.0f;
    kalPts[idx].score = 0.0f;
    kalibrasyonGuncelle();
    numuneKalHataMetni = "DEĞER/ÖLÇÜM TUTARSIZ (PPM ARTARKEN SKOR AZALDI). TEKRAR ÖLÇÜN.";
    numuneKalBekleyenIdx = -1;
    numuneKalGirisMetni = "";
    numuneKalAdim = 0;
    return false;
  }

  // NOT (ADIM-FIX): Aynı hata BLANK ÖLÇ'te olduğu gibi burada da vardı --
  // n<3 iken (blank + tek numune) bile kalibrasyonuNVSyeKaydet() koşulsuz
  // çağrılıyor, GEÇERSİZ regresyon durumu yine de en yüksek generation
  // olarak NVS'ye yazılıp eski SAĞLAM kalibrasyonun yerine geçiyordu.
  // Artık yalnızca regresyon gerçekten GEÇERLİ olduğunda kaydediliyor.
  if (kalibrasyonGecerli) {
    kalibrasyonuNVSyeKaydet();
    kalibrasyonKartiniSeriYaz();
  } else {
    kalLog("[KAL-NVS] Numune RAM'de, NVS'ye HENUZ yazilmadi (n=%d)", kal_n);
  }

  numuneKalBekleyenIdx = -1;
  numuneKalGirisMetni = "";
  numuneKalHataMetni = "";
  numuneKalAdim = 0;
  return true;
}

void drawCalibrationNumuneScreen() {
  display.fillScreen(UI_BG);
  drawHeader("NUMUNE İLE KALİBRASYON");

  int px = 30, py = 84, pw = 740, ph = 380;
  display.fillRoundRect(px, py, pw, ph, 14, UI_PANEL);
  display.drawRoundRect(px, py, pw, ph, 14, UI_LINE);

  drawCenteredText("BİLİNEN DEĞERLİ NUMUNE İLE KALİBRASYON", px + pw / 2, py + 10, FONT_MEDIUM, UI_WHITE, UI_PANEL);
  drawLeftText("Numuneyi ölçün, sonra bilinen (referans) ppm değerini girin.",
               px + 30, py + 40, FONT_SMALL, UI_MUTED, UI_PANEL);

  char durum1[48];
  snprintf(durum1, sizeof(durum1), "Blank: %s", ndscBlankHazir ? "HAZIR" : "GEREKLİ");
  drawLeftText(durum1, px + 30, py + 68, FONT_SMALL,
               ndscBlankHazir ? UI_GREEN : UI_ORANGE, UI_PANEL);

  int adet = numuneKalAktifSayisi();
  char durum2[48];
  snprintf(durum2, sizeof(durum2), "Numune: %d/%d", adet, NUMUNE_KAL_MAX_ADET);
  drawLeftText(durum2, px + 260, py + 68, FONT_SMALL, UI_WHITE, UI_PANEL);

  drawLeftText(kalibrasyonGecerli ? "Kalibrasyon: GEÇERLİ" : "Kalibrasyon: GEÇERSİZ",
               px + 500, py + 68, FONT_SMALL,
               kalibrasyonGecerli ? UI_GREEN : UI_RED, UI_PANEL);

  // Girilen noktaların kısa listesi: 2 sütun x 5 satır (kalPts[1..10]).
  int listY = py + 98;
  char satir[48];
  for (int i = 1; i < KAL_NOKTA_SAYISI; i++) {
    int col = (i - 1) % 2, row = (i - 1) / 2;
    int lx = px + 30 + col * 360;
    int ly = listY + row * 30;
    if (kalPts[i].aktif) {
      snprintf(satir, sizeof(satir), "%d) %.2f ppm  (skor %.4f)", i, kalPts[i].hedefPPM, kalPts[i].score);
      drawLeftText(satir, lx, ly, FONT_SMALL, UI_CYAN, UI_PANEL);
    } else {
      snprintf(satir, sizeof(satir), "%d) -", i);
      drawLeftText(satir, lx, ly, FONT_SMALL, UI_MUTED, UI_PANEL);
    }
  }

  if (numuneKalHataMetni.length()) {
    drawLeftText(numuneKalHataMetni.c_str(), px + 30, py + 258, FONT_SMALL, UI_RED, UI_PANEL);
  }

  bool blankBtnAktif = !ndscBlankHazir;
  bool numuneBtnAktif = ndscBlankHazir && (adet < NUMUNE_KAL_MAX_ADET);
  bool bitirBtnAktif = kalibrasyonGecerli;

  drawButton(px + 30, py + 286, 220, 46, "blank ölç", blankBtnAktif ? UI_CYAN : UI_MUTED, ICON_DROP, blankBtnAktif);
  drawButton(px + 270, py + 286, 220, 46, "numune ölç", numuneBtnAktif ? UI_GREEN : UI_MUTED, ICON_NONE, numuneBtnAktif);
  drawButton(px + 510, py + 286, 200, 46, "bitir", bitirBtnAktif ? UI_ORANGE : UI_MUTED, ICON_CHECK, bitirBtnAktif);

  drawButton(430, 420, 300, 44, "geri", UI_CYAN);
}

void drawCalibrationNumuneGirisScreen() {
  display.fillScreen(UI_BG);
  drawHeader("NUMUNE İLE KALİBRASYON");

  drawCenteredText("NUMUNE ÖLÇÜLDÜ", 400, 90, FONT_MEDIUM, UI_GREEN, UI_BG);
  drawCenteredText("Numunenin bilinen (referans/laboratuvar) ppm değerini girin",
                    400, 122, FONT_SMALL, UI_MUTED, UI_BG);

  int fx = 200, fy = 150, fw = 220, fh = 56;
  display.fillRoundRect(fx, fy, fw, fh, 10, UI_PANEL2);
  display.drawRoundRect(fx, fy, fw, fh, 10, UI_ORANGE);
  String v = numuneKalGirisMetni.length() ? numuneKalGirisMetni : "-";
  String vGosterim = v + " ppm";
  drawCenteredText(vGosterim.c_str(), fx + fw / 2, fy + fh / 2 - 10, FONT_MEDIUM, UI_ORANGE, UI_PANEL2);

  if (numuneKalHataMetni.length()) {
    drawCenteredText(numuneKalHataMetni.c_str(), 400, 222, FONT_SMALL, UI_RED, UI_BG);
  }

  // Sayısal tuş takımı (manuel kalibrasyon ekranıyla aynı düzen/koordinatlar).
  for (int i = 0; i < 12; i++) {
    int x, y, w, h; manualKeyRect(i, x, y, w, h);
    drawButton(x, y, w, h, manualKeyLabel(i), i == 11 ? UI_RED : UI_CYAN);
  }

  drawButton(70, 420, 300, 44, "uygula", UI_GREEN);
  drawButton(430, 420, 300, 44, "iptal", UI_RED);
}

void uiHandleCalibrationNumuneTouch(int32_t tx, int32_t ty) {
  if (numuneKalAdim == 1) {
    // ─── DEĞER GİRİŞ (KLAVYE) EKRANI ───
    for (int i = 0; i < 12; i++) {
      int x, y, w, h; manualKeyRect(i, x, y, w, h);
      if (tx < x || tx > x + w || ty < y || ty > y + h) continue;
      if (i == 11) {
        if (numuneKalGirisMetni.length()) numuneKalGirisMetni.remove(numuneKalGirisMetni.length() - 1);
      } else if (i == 9) {
        if (numuneKalGirisMetni.indexOf('.') < 0) numuneKalGirisMetni += '.';
      } else {
        char c = (i == 10) ? '0' : char('1' + i);
        if (numuneKalGirisMetni.length() < 10) numuneKalGirisMetni += c;
      }
      drawCalibrationNumuneGirisScreen();
      return;
    }

    // UYGULA
    if (tx >= 70 && tx <= 370 && ty >= 420 && ty <= 464) {
      bool ok = numuneKalDegerUygula();
      if (ok) drawCalibrationNumuneScreen();
      else drawCalibrationNumuneGirisScreen();
      return;
    }

    // İPTAL: son ölçümü at, listeye dön (nokta kaydedilmez).
    if (tx >= 430 && tx <= 730 && ty >= 420 && ty <= 464) {
      if (numuneKalBekleyenIdx >= 0) {
        kalPts[numuneKalBekleyenIdx].score = 0.0f;
        kalPts[numuneKalBekleyenIdx].aktif = false;
      }
      numuneKalBekleyenIdx = -1;
      numuneKalGirisMetni = "";
      numuneKalHataMetni = "";
      numuneKalAdim = 0;
      drawCalibrationNumuneScreen();
      return;
    }
    return;
  }

  // ─── LİSTE / ÖLÇÜM EKRANI ───
  int px = 30, py = 84;

  bool blankBtnAktif = !ndscBlankHazir;
  bool numuneBtnAktif = ndscBlankHazir && (numuneKalAktifSayisi() < NUMUNE_KAL_MAX_ADET);
  bool bitirBtnAktif = kalibrasyonGecerli;

  // BLANK ÖLÇ
  if (blankBtnAktif && tx >= px + 30 && tx <= px + 30 + 220 && ty >= py + 286 && ty <= py + 332) {
    kalibrasyonBlankCalistirNumune();
    return;
  }

  // NUMUNE ÖLÇ
  if (numuneBtnAktif && tx >= px + 270 && tx <= px + 270 + 220 && ty >= py + 286 && ty <= py + 332) {
    numuneKalOlcYap();
    return;
  }

  // BİTİR -> ana KALİBRASYON ekranına dön
  if (bitirBtnAktif && tx >= px + 510 && tx <= px + 510 + 200 && ty >= py + 286 && ty <= py + 332) {
    currentScreen = SCREEN_CALIBRATION;
    drawCalibrationScreen();
    return;
  }

  // GERİ -> ana KALİBRASYON ekranına dön (o ana kadar girilen noktalar
  // zaten her onayda NVS'ye kaydedildiği için kaybolmaz).
  if (tx >= 430 && tx <= 730 && ty >= 420 && ty <= 464) {
    currentScreen = SCREEN_CALIBRATION;
    drawCalibrationScreen();
    return;
  }
}

// ─── MANUEL KALİBRASYON GİRİŞİ ───────────────────────────────────
int manualPageItemCount() { return (manualKalPage < 2) ? 8 : 5; }
int manualInputIndex(int slot) {
  if (manualKalPage == 0) return slot;
  if (manualKalPage == 1) return 8 + slot;
  if (manualKalPage == 2) return 16 + slot;       // 5..75 ppm
  return 21 + slot;                               // 100..300 ppm
}
const char* manualPageTitle() {
  if (manualKalPage == 0) return "MANUEL: DARK REFERANS (F1-F8)";
  if (manualKalPage == 1) return "MANUEL: BLANK REFERANS (F1-F8)";
  if (manualKalPage == 2) return "MANUEL: 5-75 PPM SKORLARI";
  return "MANUEL: 100-300 PPM SKORLARI";
}
String manualFieldLabel(int slot) {
  if (manualKalPage < 2) return String(manualKalPage == 0 ? "DARK F" : "BLANK F") + String(slot + 1);
  int idx = (manualKalPage == 2) ? (1 + slot) : (6 + slot);
  return String(kalPts[idx].hedefPPM, 0) + " PPM SCORE";
}
void manualFieldRect(int slot, int &x, int &y, int &w, int &h) {
  int col = slot % 2, row = slot / 2;
  x = 45 + col * 370; y = 108 + row * 44; w = 340; h = 36;
}
void manualKeyRect(int key, int &x, int &y, int &w, int &h) {
  int col = key % 4, row = key / 4;
  x = 440 + col * 82; y = 285 + row * 38; w = 72; h = 32;
}
const char* manualKeyLabel(int key) {
  static const char* k[] = {"1","2","3","4","5","6","7","8","9",".","0","sil"};
  return k[key];
}
void drawManualRightText(const char* text, int x, int y,
                         const lgfx::v1::IFont* font,
                         uint16_t color, uint16_t bg) {
  display.setFont(font);
  display.setTextSize(1);
  display.setTextColor(color, bg);
  display.setTextDatum(textdatum_t::top_right);
  display.drawString(text, x, y);
  display.setTextDatum(textdatum_t::top_left);
}

void drawCalibrationManualScreen() {
  display.fillScreen(UI_BG);
  drawHeader("MANUEL KALİBRASYON");
  drawCenteredText(manualPageTitle(), 400, 86, FONT_SMALL, UI_ORANGE, UI_BG);
  drawCenteredText("Kağıttaki ham referansları ve NDSC skorlarını girin", 400, 468 - 20, FONT_SMALL, UI_MUTED, UI_BG);

  int count = manualPageItemCount();
  for (int slot = 0; slot < count; slot++) {
    int x,y,w,h; manualFieldRect(slot,x,y,w,h);
    int mi = manualInputIndex(slot);
    bool sel = (manualKalSelected == mi);
    display.fillRoundRect(x,y,w,h,8, sel ? UI_PANEL2 : UI_PANEL);
    display.drawRoundRect(x,y,w,h,8, sel ? UI_ORANGE : UI_LINE);
    drawLeftText(manualFieldLabel(slot).c_str(), x + 10, y + 9, FONT_SMALL, UI_WHITE, sel ? UI_PANEL2 : UI_PANEL);
    String v = manualKalInput[mi].length() ? manualKalInput[mi] : "-";
    drawManualRightText(v.c_str(), x + w - 10, y + 9, FONT_SMALL, sel ? UI_ORANGE : UI_CYAN, sel ? UI_PANEL2 : UI_PANEL);
  }

  // Sayısal tuş takımı
  for (int i=0; i<12; i++) {
    int x,y,w,h; manualKeyRect(i,x,y,w,h);
    drawButton(x,y,w,h,manualKeyLabel(i), i == 11 ? UI_RED : UI_CYAN);
  }
  drawButton(40, 402, 160, 40, "önceki", UI_CYAN);
  drawButton(220, 402, 160, 40, "sonraki", UI_CYAN);
  drawButton(400, 402, 170, 40, "uygula", UI_GREEN);
  drawButton(590, 402, 170, 40, "iptal", UI_RED);
}

// Manuel kalibrasyon alanlarında String::toFloat() yerine tam sayı doğrulaması.
// Başta/sonda boşluk kabul edilir; arada geçersiz karakter varsa reddedilir.
static bool manualKalParseFloat(const String& input, float& out) {
  String s = input;
  s.trim();
  if (s.length() == 0) return false;

  char* endPtr = nullptr;
  const char* begin = s.c_str();
  float value = strtof(begin, &endPtr);

  if (endPtr == begin || endPtr == nullptr || *endPtr != '\0' || !isfinite(value)) {
    return false;
  }
  out = value;
  return true;
}

bool manualKalibrasyonuUygula() {
  float vals[26] = {0};

  // DARK + BLANK alanlari zorunlu.
  for (int i=0; i<16; i++) {
    if (manualKalInput[i].length() == 0) {
      kalLog("[MANUEL-KAL] HATA: DARK/BLANK bos alan i=%d", i);
      return false;
    }
    if (!manualKalParseFloat(manualKalInput[i], vals[i])) {
      kalLog("[MANUEL-KAL] HATA: DARK/BLANK gecersiz sayi i=%d", i);
      return false;
    }
  }

  // BLANK, ayni kanalda DARK'tan buyuk olmali.
  for (int k=0; k<NDSC_KANAL; k++) {
    if (vals[8+k] <= vals[k]) {
      kalLog("[MANUEL-KAL] HATA: BLANK<=DARK kanal=%d dark=%.4f blank=%.4f",
             k+1, vals[k], vals[8+k]);
      return false;
    }
  }

  float oldDark[NDSC_KANAL], oldBlank[NDSC_KANAL];
  memcpy(oldDark, darkSpectrum, sizeof(oldDark));
  memcpy(oldBlank, blankBeyaz, sizeof(oldBlank));
  KalPt oldPts[KAL_NOKTA_SAYISI];
  memcpy(oldPts, kalPts, sizeof(oldPts));
  bool oldBlankReady = ndscBlankHazir;
  float oldBlankF5 = kal_blank_f5;

  for (int k=0; k<NDSC_KANAL; k++) {
    darkSpectrum[k] = vals[k];
    blankBeyaz[k] = vals[8+k];
  }
  ndscBlankHazir = true;
  kal_blank_f5 = blankBeyaz[4];
  // KAL-FIX-UYUM NOT: Bu manuel geri yükleme akışında yalnızca DARK/BLANK
  // ORTALAMA spektrumu ve puan noktaları girilir; ham yeşil/kırmızı
  // spektrumlar burada YOKTUR, bu yüzden kal_s1Blank/kal_s2Blank
  // hesaplanamaz ve önceki (varsa) değerinde kalır. Etkisi: bu yoldan
  // kalibrasyon geri yüklendiğinde "uyum" kontrolü bir sonraki gerçek
  // "BLANK ÖLÇ" yapılana kadar eski (veya sıfır) tabanla çalışır --
  // PPM hesabını etkilemez, yalnızca güven skorunun uyum bileşenini.

  // 0 ppm blank noktasi her zaman aktif. NOT: score alanina artik
  // DOKUNMUYORUZ -- BLANK ÖLÇ zaten gercek blank skorunu buraya
  // yazmisti (bkz. ndscBlankOlc()); bunu 0.0f'a zorlamak o gercek
  // olcumu siler ve blank tekrar test edildiginde "hayalet" bir PPM
  // ofseti (ör. 147 ppm) ortaya cikmasina sebep olur.
  kalPts[0].aktif = true;
  int aktifStandart = 0;
  for (int i=1; i<KAL_NOKTA_SAYISI; i++) {
    int inputIdx = 16 + (i-1);
    if (manualKalInput[inputIdx].length() == 0) {
      kalPts[i].score = 0.0f;
      kalPts[i].aktif = false;
      continue;
    }
    float v = 0.0f;
    if (!manualKalParseFloat(manualKalInput[inputIdx], v) || v < 0.0f) {
      memcpy(darkSpectrum, oldDark, sizeof(oldDark));
      memcpy(blankBeyaz, oldBlank, sizeof(oldBlank));
      memcpy(kalPts, oldPts, sizeof(oldPts));
      ndscBlankHazir = oldBlankReady;
      kal_blank_f5 = oldBlankF5;
      kalLog("[MANUEL-KAL] HATA: Gecersiz SCORE idx=%d value=%s", i, manualKalInput[inputIdx].c_str());
      return false;
    }
    kalPts[i].score = v;
    kalPts[i].aktif = true;
    aktifStandart++;
  }

  if (aktifStandart < 2) {
    memcpy(darkSpectrum, oldDark, sizeof(oldDark));
    memcpy(blankBeyaz, oldBlank, sizeof(oldBlank));
    memcpy(kalPts, oldPts, sizeof(oldPts));
    ndscBlankHazir = oldBlankReady;
    kal_blank_f5 = oldBlankF5;
    kalLog("[MANUEL-KAL] HATA: En az 2 standart PPM skoru girilmeli.");
    return false;
  }

  kalibrasyonGuncelle();
  if (!kalibrasyonGecerli) {
    memcpy(darkSpectrum, oldDark, sizeof(oldDark));
    memcpy(blankBeyaz, oldBlank, sizeof(oldBlank));
    memcpy(kalPts, oldPts, sizeof(oldPts));
    ndscBlankHazir = oldBlankReady;
    kal_blank_f5 = oldBlankF5;
    kalibrasyonGuncelle();
    kalLog("[MANUEL-KAL] HATA: Regresyon gecersiz (yon/tutarlilik).");
    return false;
  }

  kalibrasyonuNVSyeKaydet();
  kalibrasyonKartiniSeriYaz();
  kalLog("[MANUEL-KAL] BASARILI: Kalibrasyon uygulandi ve NVS'ye kaydedildi.");
  return true;
}
void uiHandleCalibrationManualTouch(int32_t tx, int32_t ty) {
  int count = manualPageItemCount();
  for (int slot=0; slot<count; slot++) {
    int x,y,w,h; manualFieldRect(slot,x,y,w,h);
    if (tx>=x && tx<=x+w && ty>=y && ty<=y+h) {
      manualKalSelected = manualInputIndex(slot);
      drawCalibrationManualScreen();
      return;
    }
  }
  for (int i=0; i<12; i++) {
    int x,y,w,h; manualKeyRect(i,x,y,w,h);
    if (tx<x || tx>x+w || ty<y || ty>y+h) continue;
    if (manualKalSelected < 0) return;
    if (i == 11) {
      if (manualKalInput[manualKalSelected].length()) manualKalInput[manualKalSelected].remove(manualKalInput[manualKalSelected].length()-1);
    } else if (i == 9) {
      if (manualKalInput[manualKalSelected].indexOf('.') < 0) manualKalInput[manualKalSelected] += '.';
    } else {
      char c = (i == 10) ? '0' : char('1' + i);
      if (manualKalInput[manualKalSelected].length() < 16) manualKalInput[manualKalSelected] += c;
    }
    drawCalibrationManualScreen();
    return;
  }
  if (tx>=40 && tx<=200 && ty>=402 && ty<=442) {
    if (manualKalPage > 0) { manualKalPage--; manualKalSelected=-1; drawCalibrationManualScreen(); }
    return;
  }
  if (tx>=220 && tx<=380 && ty>=402 && ty<=442) {
    if (manualKalPage < 3) { manualKalPage++; manualKalSelected=-1; drawCalibrationManualScreen(); }
    return;
  }
  if (tx>=400 && tx<=570 && ty>=402 && ty<=442) {
    bool ok = manualKalibrasyonuUygula();
    if (ok) { currentScreen = SCREEN_CALIBRATION; drawCalibrationScreen(); }
    else { drawCenteredText("HATA: SERIAL MONITOR DETAYINA BAKIN", 400, 452, FONT_SMALL, UI_RED, UI_BG); }
    return;
  }
  if (tx>=590 && tx<=760 && ty>=402 && ty<=442) {
    currentScreen = SCREEN_CALIBRATION;
    drawCalibrationScreen();
    return;
  }
}

// =====================================================
// FIX2: MERKEZİ UI KOORDİNAT ALTYAPISI
// Çizim ve dokunmatik alanların aynı değerleri kullanması için.
// (UIRect struct'i ve uiRectContains() dosyanin en basina tasindi - bkz. FIX3)
// =====================================================
// Tema ekranı alt satır: çizim ve touch aynı merkezî koordinatlardan.
// Boşluk intentionally bırakılmıştır; iki buton birbirine değmez.
static const UIRect UI_THEME_WHITE_RECT = {245, 432, 150, 46};
static const UIRect UI_THEME_BACK_RECT  = {405, 432, 150, 46};

void uiHandleTouch(int32_t tx, int32_t ty) {
  // Ölçüm sürerken tüm dokunuşlar kilitlenir.
  if (olcumKilitli) return;

  Serial.printf("[UI TOUCH] x=%d y=%d screen=%d\n",
                tx, ty, (int)currentScreen);

  if (currentScreen == SCREEN_MAIN) {

    if (tx >= 28 && tx <= 255 && ty >= 302 && ty <= 342) {
      Serial.println("[UI] YAZDIR butonu algilandi.");
      yazdirSonucFisi();
      buzzerPrintDone();
      return;
    }

    if (tx >= 28 && tx <= 255 && ty >= 344 && ty <= 382) {
      currentScreen = SCREEN_MAP;

      // KRİTİK DÜZELTME: HTTPS/PNG/Firebase işlemleri artık UI içinde
      // çalıştırılmıyor. Ağ ayrı FreeRTOS task'ında, bu görev ise yalnızca
      // animasyonu çiziyor. Böylece harita tuşuna basınca flip/titreme oluşmaz.
      bool haritaZatenHazir = geoapifyHaritaHazir && geoapifyHaritaPng &&
                              geoapifyHaritaPngLen > 0;
      bool indirmeBasarili = true;

      if (!haritaZatenHazir) {
        indirmeBasarili = haritaYuklemeAnimasyonuVeBekle();
      } else if (firebaseHazir && WiFi.status() == WL_CONNECTED) {
        // PNG zaten RAM'deyse ekranı bekletmeden aç; Firebase yenilemesini
        // arka planda yapmaya çalış.
        haritaAgBaslat();
      }

      // Nihai çizim artık RAM'den yapıldığı için çok hızlıdır.
      uint8_t eskiSeviye = ekranGecisBaslat();
      drawSimplePage(currentScreen);
      ekranGecisBitir(eskiSeviye);
      return;
    }

    if (tx >= 28 && tx <= 255 && ty >= 384 && ty <= 422) {
      currentScreen = SCREEN_CLOUD;
      drawSimplePage(currentScreen);
      return;
    }

    if (tx >= 28 && tx <= 255 && ty >= 424 && ty <= 462) {
      currentScreen = SCREEN_SETTINGS;
      drawSimplePage(currentScreen);
      return;
    }

    if (tx >= 299 && tx <= 765 && ty >= 395 && ty <= 463) {
      Serial.println("[UI] OLCUM YAP: UI butonu algilandi.");
      buzzerMeasureStart();
      nitrateOlcumCalistir();
      return;
    }

  } else if (currentScreen == SCREEN_SETTINGS) {
    // Merkezdeki 4 ikon karti.
    const int tileW = 132, tileH = 112, gap = 18;
    const int totalW = tileW * 4 + gap * 3;
    const int x0 = (800 - totalW) / 2;
    const int y0 = 150;

    // FIX5: Dokunmatik tolerans payı önceden +/-14 px idi. Kartlar arası
    // gerçek boşluk (gap) yalnızca 18 px olduğundan, iki komşu kartın
    // tolerans bölgeleri 14+14-18 = 10 px genişliğinde ÇAKIŞIYORDU. Bu
    // çakışma bölgesine dokunulduğunda kod her zaman İLK eşleşen (soldaki)
    // kartı tetikliyordu — örn. KALİBRASYON kartının sol kenarına yakın bir
    // dokunuş, görünürde doğru karta basılmasına rağmen WİFİ ekranını
    // açıyordu. Bu da "ayarlar tam tıklanmıyor, sanki kaymış" hissini
    // yaratan asıl teknik nedendi. Tolerans, çakışmayı önlemek için gap'in
    // yarısından (9 px) küçük tutuldu: +/-8 px.
    const int tol = 8;
    if (ty >= y0 - tol && ty <= y0 + tileH + tol) {
      if (tx >= x0 - tol && tx <= x0 + tileW + tol) {
        wifiTaramaSayisi = 0; wifiListeKaydirma = 0;
        currentScreen = SCREEN_WIFI_LIST; wifiAglariTara(); drawWifiListScreen(); return;
      }
      if (tx >= x0 + (tileW+gap) - tol && tx <= x0 + (tileW+gap) + tileW + tol) {
        kalibrasyonSifreGirisi = ""; kalibrasyonSifreHatali = false;
        currentScreen = SCREEN_CALIBRATION_PASSWORD; drawCalibrationPasswordScreen(); return;
      }
      if (tx >= x0 + 2*(tileW+gap) - tol && tx <= x0 + 2*(tileW+gap) + tileW + tol) {
        // GPS karti yalnızca GPS bilgilerini gösterir.
        currentScreen = SCREEN_GPS_INFO; drawSimplePage(currentScreen); return;
      }
      if (tx >= x0 + 3*(tileW+gap) - tol && tx <= x0 + 3*(tileW+gap) + tileW + tol) {
        currentScreen = SCREEN_SETTINGS_DETAILS; drawSimplePage(currentScreen); return;
      }
    }

    // EKRAN kartı: parlaklık ve gerçek panel bilgileri.
    if (tx >= 284 && tx <= 416 && ty >= 286 && ty <= 398) {
      currentScreen = SCREEN_DISPLAY_SETTINGS; drawSimplePage(currentScreen); return;
    }

    // TAKIM kartı: kaptan/üye/danışman bilgileri ve proje logoları.
    if (tx >= 434 && tx <= 566 && ty >= 286 && ty <= 398) {
      currentScreen = SCREEN_TEAM_INFO; drawSimplePage(currentScreen); return;
    }

    if (tx >= 280 && tx <= 520 && ty >= 430 && ty <= 480) {
      currentScreen = SCREEN_MAIN; uint8_t eskiSeviye = ekranGecisBaslat();
      display.fillScreen(UI_BG); drawMainScreen(); ekranGecisBitir(eskiSeviye); return;
    }

  } else if (currentScreen == SCREEN_DISPLAY_SETTINGS) {
    // 5 tema butonu: seçildiği anda tüm aktif ekran renkleri değişir ve NVS'e kaydedilir.
    if (ty >= 390 && ty <= 436) {
      int yeniTema = -1;
      if (tx >= 60 && tx <= 230) yeniTema = 0;
      else if (tx >= 235 && tx <= 405) yeniTema = 1;
      else if (tx >= 410 && tx <= 580) yeniTema = 2;
      else if (tx >= 585 && tx <= 740) yeniTema = 3;
      if (yeniTema >= 0) { uiTemayiUygula(yeniTema); uiTemayiKaydet(); drawSimplePage(SCREEN_DISPLAY_SETTINGS); return; }
    }
    // Alt sırada BEYAZ tema ve GERİ alanları çizim koordinatlarıyla aynı
    // kaynaktan gelir; arada çakışan dokunmatik bölge bırakılmaz.
    if (uiRectContains(UI_THEME_WHITE_RECT, tx, ty)) {
      uiTemayiUygula(4); uiTemayiKaydet(); drawSimplePage(SCREEN_DISPLAY_SETTINGS); return;
    }
    if (uiRectContains(UI_THEME_BACK_RECT, tx, ty)) {
      currentScreen = SCREEN_SETTINGS; drawSimplePage(currentScreen); return;
    }

  } else if (currentScreen == SCREEN_TEAM_INFO) {
    // TAKIM ekranındaki tek etkileşim "geri" butonu.
    if (tx >= 300 && tx <= 500 && ty >= 406 && ty <= 446) {
      currentScreen = SCREEN_SETTINGS; drawSimplePage(currentScreen); return;
    }

  } else if (currentScreen == SCREEN_WIFI_LIST) {
    // WiFi listesi için dokunmatik işlemleri ayrı tutuyoruz. Tarama asenkron
    // devam ederken bile GERI/İPTAL çalışır; böylece ekran donmuş görünmez.
    int bx, by, bw, bh;

    wifiListeButonRect(false, bx, by, bw, bh);
    if (tx >= bx && tx <= bx + bw && ty >= by && ty <= by + bh) {
      if (wifiTaraniyor) {
        WiFi.scanDelete();
        wifiTaraniyor = false;
        wifiTaniSonKod = WIFI_SCAN_FAILED;
        Serial.println("[WiFi] Kullanıcı taramayı iptal etti.");
      }
      currentScreen = SCREEN_SETTINGS;
      drawSimplePage(SCREEN_SETTINGS);
      return;
    }

    // AĞI UNUT yalnızca WiFi ekranında bulunur. Kayıtlı SSID/şifre
    // kullanıcı açıkça bu düğmeye bastığında silinir.
    if (!wifiTaraniyor) {
      wifiAgUnutButonRect(bx, by, bw, bh);
      if (tx >= bx && tx <= bx + bw && ty >= by && ty <= by + bh) {
        wifiPrefs.remove("ssid");
        wifiPrefs.remove("pass");
        WiFi.disconnect(false, false);
        wifiSecilenSSID = "";
        wifiSifreGirisi = "";
        wifiBaglantiHatasi = false;
        Serial.println("[WiFi] Ağ kaydı kullanıcı isteğiyle unutuldu.");
        drawWifiListScreen();
        return;
      }
    }

    // Tarama sürerken başka seçim yapılmaz; yalnızca iptal/geri aktiftir.
    if (wifiTaraniyor) return;

    wifiListeButonRect(true, bx, by, bw, bh);
    if (tx >= bx && tx <= bx + bw && ty >= by && ty <= by + bh) {
      wifiAglariTara();
      drawWifiListScreen();
      return;
    }

    if (wifiTaramaSayisi > 6) {
      wifiOkRect(true, bx, by, bw, bh);
      if (tx >= bx && tx <= bx + bw && ty >= by && ty <= by + bh) {
        if (wifiListeKaydirma > 0) wifiListeKaydirma--;
        drawWifiListScreen();
        return;
      }
      wifiOkRect(false, bx, by, bw, bh);
      if (tx >= bx && tx <= bx + bw && ty >= by && ty <= by + bh) {
        int gorunen = 6;
        if (wifiListeKaydirma < wifiTaramaSayisi - gorunen) wifiListeKaydirma++;
        drawWifiListScreen();
        return;
      }
    }

    int gorunen = wifiTaramaSayisi > 6 ? 6 : wifiTaramaSayisi;
    for (int satir = 0; satir < gorunen; ++satir) {
      wifiSatirRect(satir, bx, by, bw, bh);
      if (tx >= bx && tx <= bx + bw && ty >= by && ty <= by + bh) {
        int idx = wifiListeKaydirma + satir;
        if (idx < 0 || idx >= wifiTaramaSayisi) return;

        wifiSecilenSSID = wifiTaramaSSID[idx];
        wifiSifreGoster = false;
        wifiBaglantiHatasi = false;

        String kayitliSSID = wifiPrefs.getString("ssid", "");
        String kayitliSifre = wifiPrefs.getString("pass", "");

        if (wifiSecilenSSID == kayitliSSID && kayitliSifre.length() > 0) {
          wifiSifreGirisi = kayitliSifre;
          wifiBaglantiDene(wifiSecilenSSID.c_str(), kayitliSifre.c_str());
        } else if (wifiTaramaAcik[idx]) {
          wifiSifreGirisi = "";
          wifiBaglantiDene(wifiSecilenSSID.c_str(), "");
        } else {
          wifiSifreGirisi = "";
          wifiKlavyeSayiModu = false;
          wifiKlavyeShift = false;
          currentScreen = SCREEN_WIFI_KEYBOARD;
          drawWifiKeyboardScreen();
        }
        return;
      }
    }

  } else if (currentScreen == SCREEN_GPS_INFO) {
    if (tx >= 300 && tx <= 500 && ty >= 430 && ty <= 472) {
      currentScreen = SCREEN_SETTINGS; drawSimplePage(currentScreen); return;
    }

  } else if (currentScreen == SCREEN_SETTINGS_DETAILS) {
    if (tx >= 120 && tx <= 370 && ty >= 196 && ty <= 238) {
      sensorI2CHattiniBaslat(); as7341YenidenBaslat(); drawSimplePage(SCREEN_SETTINGS_DETAILS); return;
    }
    if (tx >= 120 && tx <= 370 && ty >= 292 && ty <= 334) {
      sensorI2CHattiniBaslat(); sht40YenidenBaslat(); drawSimplePage(SCREEN_SETTINGS_DETAILS); return;
    }
    // Sağdaki WİFİ/FIREBASE durum kartları bilgi amaçlıdır; burada
    // bağlantı veya kayıt silme işlemi yapılmaz. Ağ kaydı yalnızca
    // yalnızca WİFİ ekranındaki açık "AĞI UNUT" komutuyla silinir.
    if (tx >= 430 && tx <= 680 && ty >= 196 && ty <= 334) {
      return;
    }
    if (tx >= 300 && tx <= 500 && ty >= 398 && ty <= 440) {
      currentScreen = SCREEN_SETTINGS; drawSimplePage(currentScreen); return;
    }

  } else if (currentScreen == SCREEN_CALIBRATION_PASSWORD) {

    uiHandleCalibrationPasswordTouch(tx, ty);
    return;

  } else if (currentScreen == SCREEN_CALIBRATION) {

    uiHandleCalibrationTouch(tx, ty);
    return;

  } else if (currentScreen == SCREEN_CALIBRATION_MANUAL) {

    uiHandleCalibrationManualTouch(tx, ty);
    return;

  } else if (currentScreen == SCREEN_CALIBRATION_NUMUNE) {

    uiHandleCalibrationNumuneTouch(tx, ty);
    return;

  } else if (currentScreen == SCREEN_WIFI_KEYBOARD) {

    uiHandleWifiKeyboardTouch(tx, ty);
    return;

  } else if (currentScreen == SCREEN_MAP) {

    if (millis() - sonHaritaButonDokunusu < HARITA_BUTON_DEBOUNCE_MS) {
      return;
    }

    if (tx >= 615 && tx <= 780 && ty >= 410 && ty <= 479) {
      sonHaritaButonDokunusu = millis();
      currentScreen = SCREEN_MAIN;
      uint8_t eskiSeviye = ekranGecisBaslat();
      display.fillScreen(UI_BG);
      drawMainScreen();
      ekranGecisBitir(eskiSeviye);
      return;
    }

  } else if (currentScreen == SCREEN_CLOUD) {

    // BULUTA GÖNDER: yalnızca cihazdaki bekleyen ölçümleri Firebase'e gönderir.
    if (tx >= 250 && tx <= 550 && ty >= 345 && ty <= 393) {
      bulutSenkronizasyonIstegi();
      return;
    }

    if (tx >= 300 && tx <= 500 && ty >= 410 && ty <= 458) {
      currentScreen = SCREEN_MAIN;
      uint8_t eskiSeviye = ekranGecisBaslat();
      display.fillScreen(UI_BG);
      drawMainScreen();
      ekranGecisBitir(eskiSeviye);
      return;
    }
  }
}

bool sensorI2CHattiniBaslat() {
  Serial.println("[I2C SENSOR] ORTAK Wire bus: SDA=15 SCL=16 / I2C_NUM_0");

  if (!ortakI2CHattiniBaslat()) {
    Serial.println("[I2C SENSOR] ortak Wire baslatilamadi.");
    return false;
  }

  // GT911 için ayrı bir I2C taraması yapmıyoruz; Elecrow V1.4 dokümanında
  // adres 0x5D olarak belirtiliyor. Sensör adresleri doğrudan kontrol edilir.
  bool asVar = i2cCihazVar(AS7341_ADDR);
  bool blVar = i2cCihazVar(STC8_ADDR);
  bool shtVar = i2cCihazVar(SHT40_ADDR);
  as7341TaramaBulundu = asVar;
  sht40TaramaBulundu = shtVar;

  Serial.printf("[I2C SENSOR] 0x39 AS7341: %s\n", asVar ? "BULUNDU" : "YOK");
  Serial.printf("[I2C SENSOR] 0x30 STC8H  : %s\n", blVar ? "BULUNDU" : "YOK");
  Serial.printf("[I2C SENSOR] 0x44 SHT40  : %s\n", shtVar ? "BULUNDU" : "YOK");
  Serial.println("[I2C TOUCH ] 0x5D GT911: LovyanGFX tarafindan kullaniliyor");

  return asVar || blVar || shtVar;
}

// Olcum bittiginde sensorleri dusuk guc / kapali duruma alir.
// AS7341: powerEnable(false) ile PON biti kapatilir (dusuk guc bekleme).
// SHT40: zaten tek seferlik (one-shot) okuma yapiyor, surekli bir
// olcum modu yok; burada sadece "hazir degil" olarak isaretleniyor ki
// bir sonraki OLCUM BASLAT basisinda yeniden baslatilsin.
void sensorleriKapat() {
  // ÖNEMLİ: GT911 dokunmatik + STC8 backlight + AS7341 aynı I2C hattını
  // (GPIO15/16) paylaşır. Ölçümün hemen sonunda AS7341.powerEnable(false)
  // göndermek, tam ekran geçişinden hemen önce ortak bus üzerinde ekstra
  // bir I2C işlemi oluşturuyordu. Bu nedenle burada AS7341'e artık yazmıyoruz.
  //
  // AS7341 bir sonraki ölçümün başında as7341YenidenBaslat() ile yeniden
  // yapılandırılıyor. Böylece ölçüm -> sonuç ekranı geçişinde GT911/backlight
  // hattına dokunan gereksiz bir son I2C işlemi kalmıyor.
  if (as7341Hazir) {
    Serial.println("[AS7341] Olcum sonrasi I2C power-off atlandi; sonraki olcumde yeniden init edilecek.");
  }
  // AS7341 fiziksel olarak kapatilmadigi icin burada hazir bayragini
  // gereksiz yere false yapmiyoruz. Ayarlar ekraninda gercekten bagli olan
  // sensorun "BUS YOK" gibi gorunmesini onler. Bir sonraki baslatma
  // veya okuma hatasi durumunda as7341YenidenBaslat() bayragi zaten
  // kendisi gunceller.
  sht40Hazir = false;
}

bool as7341YenidenBaslat() {
  Serial.println("[AS7341] Baslatma deneniyor...");
  // Baslatma öncesi ortak hattın serbest olduğundan emin ol.
  i2cHattiToparla();
  vTaskDelay(pdMS_TO_TICKS(20));
  as7341Hazir = false;
  as7341BeginSonucu = false;
  as7341OkumaSonucu = false;

  if (!i2cKilitle(pdMS_TO_TICKS(300))) {
    Serial.println("[AS7341] Mutex alinamadi.");
    return false;
  }

  as7341Hazir = as7341.begin(AS7341_ADDR, &Wire);
  as7341BeginSonucu = as7341Hazir;

  if (as7341Hazir) {
    as7341.setATIME(100);
    as7341.setASTEP(999);
    as7341.setGain(AS7341_GAIN_128X);

    // PCF8574 harici yesil/kirmizi LED KESINLIKLE KAPALI.
    // NitraCheck olcum isigi yalnizca PCF8574 uzerindeki
    // harici yesil ve kirmizi LEDlerdir.
    as7341.enableLED(false);
  }

  i2cBirak();

  Serial.printf("[AS7341] begin(0x39, &Wire) = %s\n",
                as7341Hazir ? "OK" : "FAILED");

  if (!as7341Hazir) return false;

  vTaskDelay(pdMS_TO_TICKS(10));

  uint16_t test[12] = {0};
  bool ok = false;

  if (i2cKilitle(pdMS_TO_TICKS(500))) {
    ok = as7341.readAllChannels(test);
    i2cBirak();
  }
  as7341OkumaSonucu = ok;

  Serial.printf("[AS7341] Ilk gercek okuma = %s | F1=%u F5=%u F7=%u NIR=%u\n",
                ok ? "OK" : "FAILED",
                test[AS7341_CHANNEL_415nm_F1],
                test[AS7341_CHANNEL_555nm_F5],
                test[AS7341_CHANNEL_630nm_F7],
                test[AS7341_CHANNEL_NIR]);

  if (!ok) as7341Hazir = false;
  return as7341Hazir;
}

bool sht40YenidenBaslat() {
  Serial.println("[SHT40] Baslatma deneniyor...");
  sht40Hazir = false;
  sht40BeginSonucu = false;
  sht40OkumaSonucu = false;

  // ÖNEMLİ DÜZELTME: sht40TaramaBulundu eskiden SADECE açılışta bir kez
  // (sensorI2CHattiniBaslat() içinde) taranıyordu. O ilk tarama anında
  // SHT40 cevap vermezse (bus henüz tam oturmamışsa vb.) bu bayrak
  // false'da KİLİTLENİYOR ve bir daha hiç güncellenmiyordu — bu yüzden
  // "yeniden dene" / 5s tetikleme gibi sonraki tüm denemeler burada
  // sessizce return false yapıp begin()'e hiç ulaşamıyordu (AS7341'de
  // böyle bir kilit yok, o yüzden sadece SHT40 kendi kendine
  // açılamıyordu). Çözüm: her çağrıda adresi TAZE taramak.
  sht40TaramaBulundu = i2cCihazVar(SHT40_ADDR);

  if (!sht40TaramaBulundu) {
    Serial.println("[SHT40] 0x44 adresinde cihaz yok, begin() denenmiyor.");
    return false;
  }

  if (!i2cKilitle(pdMS_TO_TICKS(300))) {
    Serial.println("[SHT40] Mutex alinamadi.");
    return false;
  }

  sht40Hazir = sht40.begin(&Wire);
  sht40BeginSonucu = sht40Hazir;

  if (sht40Hazir) {
    sht40.setPrecision(SHT4X_MED_PRECISION);
    sht40.setHeater(SHT4X_NO_HEATER);
  }

  i2cBirak();

  Serial.printf("[SHT40] begin(&Wire) = %s\n", sht40Hazir ? "OK" : "FAILED");

  if (!sht40Hazir) return false;

  vTaskDelay(pdMS_TO_TICKS(10));

  sensors_event_t nem, sicaklik;
  bool ok = false;

  if (i2cKilitle(pdMS_TO_TICKS(500))) {
    ok = sht40.getEvent(&nem, &sicaklik);
    i2cBirak();
  }
  sht40OkumaSonucu = ok;

  if (ok) {
    sonSicaklikC = sicaklik.temperature;
    sonNemYuzde  = nem.relative_humidity;
  }

  Serial.printf("[SHT40] Ilk gercek okuma = %s | T=%.1fC RH=%.1f%%\n",
                ok ? "OK" : "FAILED", sonSicaklikC, sonNemYuzde);

  if (!ok) sht40Hazir = false;
  return sht40Hazir;
}

// ══════════════════════════════════════════════════════════════
// ─── TERMAL YAZICI (ESC/POS) — SONUÇ FİŞİ ───────────────────────
// Custom PM2 Mini Panel yazıcı (EM205 kontrol kartı), TTL/UART0-OUT
// üzerinden ESC/POS komut seti ile sürülüyor. Aşağıdaki komutlar
// Epson ESC/POS standardının yaygın olarak desteklenen alt kümesidir
// (init, hizalama, kalın, büyük punto, QR kod, kağıt besleme).
// Yazıcıda otomatik kesici (cutter) OLMAYABİLİR; bu yüzden GS V
// (kesme) komutu gönderilMİYOR, bunun yerine yeterli boş kağıt
// beslenip elle yırtma bırakılıyor.
// ══════════════════════════════════════════════════════════════

#define ESC 0x1B
#define GS  0x1D

// ESC 7 n1 n2 n3 : baski yogunlugu / isitma (heating) ayari. Yazicinin
// termal kafasi ne kadar "yaniyor" onu belirler; QR kodun neden metne
// ve bitmap'e gore daha koyu/net gorundugunun asil sebebi bu DEGIL
// (QR zaten duz siyah blok bastigi icin koyu gorunuyor) -- ama bu komut
// KAFANIN TAMAMINI (metin + bitmap + QR, fisin HER SEYINI) daha koyu
// basmaya zorluyor, cunku donanim seviyesinde calisir. Cogu ESC/POS
// klon yazicida (Adafruit Thermal Printer kutuphanesinin
// "setHeatConfig" fonksiyonuyla ayni komut) desteklenir.
//   n1 = max isitma noktasi (heating dots). Birim = 8 nokta.
//        Varsayilan ~7-9. Buyutulunce daha koyu ama daha fazla
//        akim cekilir (guc kaynagi zayifsa yazici sikinti cikarabilir).
//   n2 = isitma suresi (heating time). Birim = 10 mikrosaniye.
//        Varsayilan ~80. Buyutulunce daha koyu ama BASKI YAVASLAR.
//   n3 = isitma araligi (heating interval). Birim = 10 mikrosaniye.
//        Varsayilan ~2. Kucultulunce daha koyu/hizli ama yazici kafasi
//        asiri isinip omru kisalabilir; guvenli tarafta birakildi.
void yaziciYogunlukAyarla() {
  uint8_t n1 = 10;   // maks isitma noktasi
  uint8_t n2 = 245;  // isitma suresi - buyuk font+bosluklarla zaten daha koyu basilacagi icin dusuruldu
  uint8_t n3 = 10;    // isitma araligi - kafaya toparlanma payi icin artirildi
  YaziciSerial.write(ESC); YaziciSerial.write('7');
  YaziciSerial.write(n1); YaziciSerial.write(n2); YaziciSerial.write(n3);
}

void yaziciESCPOSBaslat() {
  // ESC @ : yazıcıyı fabrika ayarlarına sıfırla.
  YaziciSerial.write(ESC); YaziciSerial.write('@');
  delay(50);

  // Yazicinin genel isitma/yogunluk ayarini koyulastir -- bu ayar
  // sifirlanana kadar (yeniden ESC @ gonderilene ya da yazici enerjisi
  // kesilene kadar) kalici oldugu icin BURADA, baslangicta BIR KEZ
  // ayarlamak yeterli; sonraki HER fis (metin, bitmap, QR -- hepsi)
  // otomatik olarak bu ayarla basilir.
  yaziciYogunlukAyarla();
  delay(20);
}

void yaziciHizala(uint8_t hiza) {
  // hiza: 0=sol, 1=orta, 2=sağ
  YaziciSerial.write(ESC); YaziciSerial.write('a'); YaziciSerial.write(hiza);
}

// ESC E n : "emphasized" (kalin/bold) modu. Fisi SECICI olarak
// koyulastirmak icin kullanilir -- sadece basliklar/onemli satirlar
// icin acilip hemen ardindan kapatilmalidir. Fisin TAMAMINI bu modda
// birakmak "duvar yazisi" gibi gorunmesine yol acar; bkz. yazdirSonucFisi().
void yaziciKalin(bool acik) {
  YaziciSerial.write(ESC); YaziciSerial.write('E'); YaziciSerial.write(acik ? 1 : 0);
}

// ESC G n : "double-strike" (cift vurus) modu. KULLANILMIYOR:
// ESC E (emphasized) ile ayni anda acilinca cogu yazicida ekstra
// koyuluk saglamiyor, bazilarinda ise satir kaymasi/bulanikliga
// yol aciyor. Fonksiyon geriye donuk uyumluluk icin birakildi ama
// yazdirSonucFisi() artik bunu cagirmiyor; sadece yaziciKalin()
// kullaniliyor.
void yaziciCiftVurus(bool acik) {
  YaziciSerial.write(ESC); YaziciSerial.write('G'); YaziciSerial.write(acik ? 1 : 0);
}

// ESC M n : karakter fontu secimi. n=0 -> Font A (varsayilan, daha
// buyuk/okunakli), n=1 -> Font B (daha kucuk/sik). Fis icin Font A
// kullaniliyor; yaziciniz Font B'de daha net basiyorsa 1 deneyin.
void yaziciFontSec(uint8_t n) {
  YaziciSerial.write(ESC); YaziciSerial.write('M'); YaziciSerial.write(n);
}

void yaziciBoyut(uint8_t genislikKat, uint8_t yukseklikKat) {
  // GS ! n : 0x00-0x03 arti genislik/yukseklik katlari üst/alt nibble'da.
  uint8_t n = ((genislikKat & 0x07) << 4) | (yukseklikKat & 0x07);
  YaziciSerial.write(GS); YaziciSerial.write('!'); YaziciSerial.write(n);
}

void yaziciSatir(const String &metin) {
  // Türkçe karakterler için yazıcı kod sayfası garantisi olmadığından
  // (ı, ş, ğ, ç, ö, ü) yazdırılamama riski var; sorun çıkarsa aşağıdaki
  // yaziciTRAscii() ile ASCII'ye çeviren satırı kullanın.
  YaziciSerial.print(metin);
  YaziciSerial.write('\n');
}

// Türkçe karakterleri, kod sayfası desteklemeyen yazıcılarda okunaklı
// kalması için en yakın ASCII karşılığına çevirir. Yazıcı Türkçe
// karakterleri bozuk basıyorsa yaziciSatir() yerine bunu kullanın:
//   yaziciSatir(yaziciTRAscii(metin));
String yaziciTRAscii(const String &s) {
  String r = s;
  struct { const char* tr; const char* ascii; } harita[] = {
    {"ı","i"}, {"İ","I"}, {"ş","s"}, {"Ş","S"}, {"ğ","g"}, {"Ğ","G"},
    {"ç","c"}, {"Ç","C"}, {"ö","o"}, {"Ö","O"}, {"ü","u"}, {"Ü","U"}
  };
  for (auto &h : harita) {
    r.replace(h.tr, h.ascii);
  }
  return r;
}
// Kafaya ve güç kaynağına satırlar arası kısa bir toparlanma payı
// bırakır; ardışık koyu satırların üst üste binip ısı/gerilim
// birikmesini azaltır.
void yaziciBosSatir() {
  YaziciSerial.write('\n');
  delay(15);
}

void yaziciCizgi() {
  yaziciSatir("- - - - - - - - - - - - - - - -");
}

void yaziciBesle(uint8_t satir) {
  for (uint8_t i = 0; i < satir; i++) YaziciSerial.write('\n');
}

// GS ( k — Epson ESC/POS QR kod komutu (çoğu ESC/POS-uyumlu panel
// yazıcı bu alt kümeyi destekler). data en fazla ~150 karakter tutulmalı.
void yaziciQRYazdir(const String &data, uint8_t modul = 6) {
  int len = data.length() + 3;
  uint8_t pL = len & 0xFF;
  uint8_t pH = (len >> 8) & 0xFF;

  // Model seç (model 2).
  uint8_t cmd1[] = { GS, '(', 'k', 0x04, 0x00, 0x31, 0x41, 0x32, 0x00 };
  YaziciSerial.write(cmd1, sizeof(cmd1));

  // Modül boyutu (nokta boyutu, 1-16 arası; 6-8 okunabilirlik için iyi).
  uint8_t cmd2[] = { GS, '(', 'k', 0x03, 0x00, 0x31, 0x43, modul };
  YaziciSerial.write(cmd2, sizeof(cmd2));

  // Hata düzeltme seviyesi (48=L, 49=M, 50=Q, 51=H).
  uint8_t cmd3[] = { GS, '(', 'k', 0x03, 0x00, 0x31, 0x45, 49 };
  YaziciSerial.write(cmd3, sizeof(cmd3));

  // Veriyi sakla.
  YaziciSerial.write(GS); YaziciSerial.write('('); YaziciSerial.write('k');
  YaziciSerial.write(pL); YaziciSerial.write(pH);
  YaziciSerial.write('1'); YaziciSerial.write('P'); YaziciSerial.write('0');
  YaziciSerial.print(data);

  // Yazdır.
  uint8_t cmd4[] = { GS, '(', 'k', 0x03, 0x00, 0x31, 0x51, 0x30 };
  YaziciSerial.write(cmd4, sizeof(cmd4));
}

// GS v 0 — ESC/POS raster bit image komutu ile 1-bit (siyah/beyaz)
// bitmap basar. TeknofestLogo.h icindeki veriyi kullanir. Yazicinin
// kucuk seri tamponunu tasirmamak icin goruntu satir satir (chunk
// halinde) gonderilir; her chunk'tan sonra kisa bir bekleme birakilir.
//
// mod parametresi (m): 0=normal, 1=x2 genislik, 2=x2 yukseklik,
// 3=x2 genislik + x2 yukseklik (quadruple). TeknofestLogo.h YARI
// COZUNURLUKTE uretildi; mod=3 ile basilinca yazici her kaynak
// noktayi 2x2 fiziksel nokta olarak basar — QR kod karelerindeki
// gibi kalin/dolu noktalar olusur, ince tek-nokta cizgiler yerine.
// Bu sayede goruntu ayni fiziksel boyutta ama cok daha koyu/net cikar.
void yaziciBitmapYazdir(const uint8_t *bitmap, uint16_t genislikPx,
                         uint16_t yukseklikPx, uint8_t mod = 0,
                         uint8_t bayrakSatir = 32) {
  uint16_t bayrakBasiSatir = (genislikPx + 7) / 8;  // genislik (byte olarak)
  uint8_t xL = bayrakBasiSatir & 0xFF;
  uint8_t xH = (bayrakBasiSatir >> 8) & 0xFF;

  for (uint16_t y0 = 0; y0 < yukseklikPx; y0 += bayrakSatir) {
    uint16_t buChunkSatir = min((uint16_t)bayrakSatir, (uint16_t)(yukseklikPx - y0));
    uint8_t yL = buChunkSatir & 0xFF;
    uint8_t yH = (buChunkSatir >> 8) & 0xFF;

    YaziciSerial.write(GS); YaziciSerial.write('v'); YaziciSerial.write('0');
    YaziciSerial.write(mod);
    YaziciSerial.write(xL); YaziciSerial.write(xH);
    YaziciSerial.write(yL); YaziciSerial.write(yH);

    uint32_t basBayt = (uint32_t)y0 * bayrakBasiSatir;
    uint32_t toplamBayt = (uint32_t)buChunkSatir * bayrakBasiSatir;
    for (uint32_t i = 0; i < toplamBayt; i++) {
      YaziciSerial.write(pgm_read_byte(bitmap + basBayt + i));
    }
    delay(40);  // yaziciya isleme payi birak
  }
}

// GS B n : "white/black reverse" (ters baski) modu — acikken yazi
// siyah zemin uzerine beyaz basilir, gercek "dolu kutu" gorunumu verir.
// NOT: Custom/Xprinter gibi cogu tam ESC/POS uyumlu yazici destekler;
// desteklemeyen bir yazicida bu komut sessizce yok sayilir.
void yaziciTersVideo(bool acik) {
  YaziciSerial.write(GS); YaziciSerial.write('B'); YaziciSerial.write(acik ? 1 : 0);
}

// Cihaza özgü kısa, okunabilir bir ID üretir (ör. "NC-A1B2C3"),
// ESP32'nin efuse MAC'inin son 3 baytından türetilir.
void cihazIdOlustur() {
  char buf[16];
  snprintf(buf, sizeof(buf), "43001"); // Kütahya'ya özgü NitraCheck cihaz kimliği
  cihazIdMetni = String(buf);
}

// OpenStreetMap Nominatim ile ücretsiz ters coğrafi kodlama (reverse
// geocoding): koordinattan açık adres metni üretir. Yalnızca WiFi
// bağlıyken ve geçerli bir GPS fix varken çağrılmalıdır; ağ isteği
// birkaç saniye sürebileceğinden yazdırma akışını YAVAŞLATIR.
String reverseGeocodeAdres(double lat, double lon) {
  if (WiFi.status() != WL_CONNECTED) return "Adres icin WiFi gerekli";
  if (lat == 0.0 && lon == 0.0) return "Konum bilgisi yok";

  HTTPClient http;
  char url[192];
  snprintf(url, sizeof(url),
           "https://nominatim.openstreetmap.org/reverse?format=json&lat=%.6f&lon=%.6f&zoom=16&accept-language=tr",
           lat, lon);

  http.begin(url);
  http.setUserAgent("NitraCheck-ESP32S3/1.0");
  http.setTimeout(2500);

  String adres = "Adres alinamadi";
  int kod = http.GET();
  if (kod == 200) {
    String govde = http.getString();
    int i = govde.indexOf("\"display_name\":\"");
    if (i >= 0) {
      int basla = i + 17;
      int bitis = govde.indexOf("\"", basla);
      if (bitis > basla) {
        adres = govde.substring(basla, bitis);
        if (adres.length() > 90) adres = adres.substring(0, 90) + "...";
      }
    }
  } else {
    Serial.printf("[GEOCODE] HTTP hata kodu: %d\n", kod);
  }
  http.end();
  return adres;
}

// Ana ekrandaki YAZDIR butonuna basılınca çağrılır: son ölçümü
// tarih/saat, aygıt ID, koordinat, açık adres ve konum QR koduyla
// birlikte termal yazıcıdan fiş olarak basar.
//
// ── NOT (koyuluk denemeleri): Bu yazıcıda GS ! (yaziciBoyut) tek
// eksende (sadece yükseklik x2) büyütmeyi görünüşe göre desteklemiyor
// -- denendi, satırlar normal boyutta basıldı ve sadece gereksiz
// boşluk/kağıt israfına yol açtı. O yüzden geri alındı. Koyuluk artık
// SADECE kanıtlanmış çalışan ESC E (yaziciKalin) ile, seçici olarak
// (başlıklar + PPM sonucu) sağlanıyor. Genel koyuluk sorunu donanımsal
// görünüyor (güç kaynağı gerilim düşmesi veya kağıt kalitesi) --
// yazılım tarafında güvenli sınırdayız.
void yazdirSonucFisi() {
  uint8_t eskiSeviye = ekranGecisBaslat();
  drawScreenTransition("SONUC YAZDIRILIYOR",
                       "Termal yazici hazirlaniyor...",
                       ICON_PRINTER, UI_CYAN);

  bool konumVar = (sonOlcumLat != 0.0 || sonOlcumLon != 0.0);

  // ADIM19-FIX: İkinci güvenlik ağı. yeniOlcumuRAMeEkle() ölçüm anında
  // konum bulamadıysa (bkz. oradaki açıklama) bile, kullanıcı YAZDIR'a
  // bastığı bu anda GPS artık geçerli bir fix'e sahipse -- fişi tamamen
  // konumsuz/QR'sız basmak yerine -- bu güncel konumu kullan.
  if (!konumVar && gpsKonumGecerli) {
    sonOlcumLat = gpsEnlem;
    sonOlcumLon = gpsBoylam;
    konumVar = true;
    Serial.println("[YAZICI] Olcum konumsuzdu, yazdirma aninda guncel GPS fix kullanildi.");
  }

  String adres = "Konum bilgisi yok";
  if (konumVar) {
    if (!reverseGeocodeCacheAl(sonOlcumLat, sonOlcumLon, adres)) {
      adres = "Adres hazirlaniyor / alinamadi";
    }
  }

  char tarihBuf[32] = "Saat senkronize degil";
  time_t simdi = time(nullptr);
  if (simdi > 100000) {
    struct tm tmBilgi;
    localtime_r(&simdi, &tmBilgi);
    strftime(tarihBuf, sizeof(tarihBuf), "%d.%m.%Y %H:%M:%S", &tmBilgi);
  }

  const char* durum = durumMetin.length() > 0
                        ? durumMetin.c_str()
                        : nitrateDurumEtiketi(uiLastNitrate);

  yaziciFontSec(0);            // Font A

  // ── TEKNOFEST logosu -- fisin EN BASINDA basiliyor.
  yaziciHizala(1);              // orta
  yaziciBitmapYazdir(teknofestLogoBitmap, TEKNOFEST_LOGO_W,
                     TEKNOFEST_LOGO_H, 3);
  yaziciBesle(1);

  // ── NitraCheck logosu + başlık ──
  yaziciHizala(1);              // orta
  yaziciBitmapYazdir(nitraCheckLogoBitmap, NITRACHECK_LOGO_W,
                     NITRACHECK_LOGO_H, 0);

  yaziciKalin(true);
  yaziciBoyut(1, 1);
  yaziciSatir(yaziciTRAscii("NitraCheck"));
  yaziciBoyut(0, 0);
  yaziciKalin(false);

  // ── SLOGAN -- başlığın hemen altında, öne çekilmiş, kalın ──
  yaziciKalin(true);
  yaziciSatir(yaziciTRAscii("Temiz Su, Saglikli Gelecek"));
  yaziciKalin(false);
  yaziciSatir(yaziciTRAscii("Su Kalitesi Olcum Raporu"));
  yaziciCizgi();

  yaziciHizala(0);              // sol
  yaziciKalin(true);
  yaziciSatir("Tarih/Saat : " + String(tarihBuf));
  yaziciSatir("Aygit ID   : " + cihazIdMetni);
  yaziciSatir("Olcum ID   : " +
              (sonOlcumId.length() ? sonOlcumId : String("(yok)")));
  yaziciKalin(false);
  yaziciCizgi();

  // ── PPM SONUCU: çerçeveli, kalın, büyük punto ──
  yaziciHizala(0);
  yaziciSatir("+- - - - - - - - - - - - - - - +");
  yaziciSatir("|                              |");

  yaziciHizala(1);              // orta
  yaziciKalin(true);
  yaziciBoyut(1, 1);
  char ppmBuf[16];
  snprintf(ppmBuf, sizeof(ppmBuf), "%.1f ppm", uiLastNitrate);
  yaziciSatir(ppmBuf);
  yaziciBoyut(1, 0);
  yaziciSatir(yaziciTRAscii(String(durum)));
  yaziciBoyut(0, 0);
  yaziciKalin(false);

  yaziciHizala(0);
  yaziciSatir("|                              |");
  yaziciSatir("+- - - - - - - - - - - - - - - +");
  yaziciCizgi();

  // ── GÜVEN SKORU: ekrandaki SONUÇ kartında gösterilenle aynı
  // (sonOptikKalite / uiHasMeasurement). Sadece bilgi satırı eklenir,
  // yazıcı yoğunluk/hizalama ayarlarına dokunulmaz.
  yaziciHizala(0);
  if (uiHasMeasurement) {
    char guvenBuf[32];
    snprintf(guvenBuf, sizeof(guvenBuf), "Guven Skoru: %.0f/100", sonOptikKalite);
    yaziciSatir(guvenBuf);
  } else {
    yaziciSatir("Guven Skoru: --");
  }
  yaziciCizgi();

  yaziciHizala(0);
  yaziciKalin(true);
  if (konumVar) {
    char koordBuf[48];
    snprintf(koordBuf, sizeof(koordBuf), "Koordinat: %.6f, %.6f",
             sonOlcumLat, sonOlcumLon);
    yaziciSatir(koordBuf);
  } else {
    yaziciSatir("Koordinat: GPS fix yok");
  }
  yaziciSatir(yaziciTRAscii("Adres: " + adres));
  yaziciKalin(false);
  yaziciCizgi();

  if (konumVar) {
    char haritaUrl[80];
    snprintf(haritaUrl, sizeof(haritaUrl),
             "https://maps.google.com/?q=%.6f,%.6f", sonOlcumLat, sonOlcumLon);

    yaziciHizala(1);            // orta
    yaziciSatir(yaziciTRAscii("Konumu haritada acmak icin"));
    yaziciSatir(yaziciTRAscii("QR kodu okutun:"));
    yaziciQRYazdir(String(haritaUrl));
    // yaziciBitmapYazdir() gibi QR basimi da yazicinin kucuk tamponunu
    // tasirabilir; arkadan gelen metin komutlarinin QR tamamen
    // basilmadan tampona dolmasini onlemek icin burada bekleniyor.
    delay(800);
    yaziciBesle(1);
  }

  // ── Alt bilgi: sade kapanış ──
  yaziciHizala(1);              // orta
  yaziciKalin(true);
  yaziciSatir("TEKNOFEST 2026");
  yaziciKalin(false);
  yaziciSatir("NitraCheck Su Senatorleri");

  yaziciBesle(4);               // el ile yirtmak icin bosluk

  Serial.println("[YAZICI] Fis yazdirma tamamlandi.");

  display.fillScreen(UI_BG);
  drawMainScreen();
  ekranGecisBitir(eskiSeviye);
}

// ══════════════════════════════════════════════════════════════
// ─── YAZICI TANI (DIAGNOSTIC) BLOĞU ─────────────────────────────
// Mevcut yazdırma akışını (yazdirSonucFisi) DEĞİŞTİRMEZ; ölçüm
// yapmadan, sadece kablo/GND/baud/voltaj izole test etmek için
// eklendi. USB Seri Monitor'e "YAZICITEST" yazip Enter'a basınca
// loop() içindeki dinleyici bunu çalıştırır (bkz. aşağıdaki loop
// yaması).
// ══════════════════════════════════════════════════════════════

// DLE EOT n (gerçek zamanlı durum sorgusu) gönderir; yazıcının TXD
// hattı gerçekten board'un RX'ine (GPIO44) bağlıysa ve ortak GND ve
// doğru baud varsa `timeoutMs` içinde bir yanıt byte'ı döner.
// NOT: Bazı ucuz panel yazıcıları bu komutu desteklemez — yanıt
// GELMEMESİ tek başına arıza kanıtı DEĞİLDİR, sadece ek bilgidir.
bool yaziciDurumSorgula(uint8_t n, uint8_t &yanit, uint16_t timeoutMs = 300) {
  while (YaziciSerial.available()) YaziciSerial.read();  // eski/artik veriyi temizle
  YaziciSerial.write((uint8_t)0x10);  // DLE
  YaziciSerial.write((uint8_t)0x04);  // EOT
  YaziciSerial.write(n);
  unsigned long basla = millis();
  while (millis() - basla < timeoutMs) {
    if (YaziciSerial.available()) {
      yanit = (uint8_t)YaziciSerial.read();
      return true;
    }
    vTaskDelay(pdMS_TO_TICKS(5));
  }
  return false;
}

void yaziciTaniKosusu() {
  Serial.println("========================================");
  Serial.println("[YAZICI-TANI] Baslatiliyor...");
  Serial.printf("[YAZICI-TANI] UART0-OUT: RX(board)=GPIO%d TX(board)=GPIO%d baud=%d\n",
                YAZICI_RX_PIN, YAZICI_TX_PIN, YAZICI_BAUD);

  uint8_t yanit = 0;
  bool geldi = yaziciDurumSorgula(1, yanit, 300);  // n=1: yazici durumu
  if (geldi) {
    Serial.printf("[YAZICI-TANI] Durum yaniti alindi: 0x%02X -> yazici(TX)->board(RX44) hatti, "
                  "ortak GND ve baud hizi DOGRU calisiyor.\n", yanit);
  } else {
    Serial.println("[YAZICI-TANI] Durum yaniti YOK (300ms icinde). Bu tek basina kesin ariza");
    Serial.println("[YAZICI-TANI] kaniti degildir (yazici bu komutu desteklemiyor olabilir);");
    Serial.println("[YAZICI-TANI] asagidaki duz metin testinin kagida cikip cikmadigina bakin.");
  }

  // En basit olasi test: formatlama/QR olmadan duz ASCII metin.
  // Kagit cikip cikmadigini FIZIKSEL olarak gozle kontrol edin.
  YaziciSerial.write(ESC); YaziciSerial.write('@');  // reset
  delay(50);
  // ESC @ yoğunluk/ısıtma ayarını da fabrika varsayılanına döndürür --
  // tanı testi sonrası fişlerin tekrar SOLUK çıkmaması için burada
  // yeniden uygulanıyor (bkz. yaziciYogunlukAyarla() yorumu).
  yaziciYogunlukAyarla();
  delay(20);
  YaziciSerial.print("YAZICI TANI TESTI\n");
  YaziciSerial.print("123456789 ABCDEFGH\n");
  YaziciSerial.write('\n'); YaziciSerial.write('\n'); YaziciSerial.write('\n');

  Serial.println("[YAZICI-TANI] Duz ASCII test satiri gonderildi. Kagit cikti mi?");
  Serial.println("  - HAYIR ve durum yaniti da YOK -> once kablo/GND/baud/voltaj kontrol edin.");
  Serial.println("  - HAYIR ama durum yaniti VAR   -> hat/baud dogru, yazdirma modunda/kagitta sorun olabilir.");
  Serial.println("  - EVET ama karakterler bozuk   -> baud hizi veya kod sayfasi uyumsuzlugu.");
  Serial.println("========================================");
}
// ─── YAZICI TANI BLOĞU SONU ─────────────────────────────────────


// =====================================================
// FIX3: AĞ İŞLEMLERİNİ UI'DAN GERÇEKTEN AYIRMA
// Ağ istekleri yalnızca networkWorkerTask içinde yapılır. UI task'ı
// sadece istek bayrağı ve durum metnini yönetir; display çağrıları
// loop() tarafından yapılır.
// =====================================================
static volatile bool reverseGeocodeBekliyor = false;
static volatile bool firebaseSenkronBekliyor = false;
static volatile bool networkWorkerBaslatildi = false;
static volatile bool networkWorkerCalisiyor = false;
static volatile bool reverseGeocodeCalisiyor = false;
static String reverseGeocodeAdresCache;
static double reverseGeocodeLat = NAN;
static double reverseGeocodeLon = NAN;
static SemaphoreHandle_t networkMutex = nullptr;

static void reverseGeocodeIstegi(double lat, double lon) {
  if (!isfinite(lat) || !isfinite(lon) || (lat == 0.0 && lon == 0.0)) return;
  if (networkMutex && xSemaphoreTake(networkMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    // Yeni ölçümde aynı koordinat için yeniden istek gerekmez.
    if (isnan(reverseGeocodeLat) || fabs(reverseGeocodeLat - lat) > 0.000001 ||
        isnan(reverseGeocodeLon) || fabs(reverseGeocodeLon - lon) > 0.000001) {
      reverseGeocodeLat = lat;
      reverseGeocodeLon = lon;
      reverseGeocodeAdresCache = "Adres hazirlaniyor...";
      reverseGeocodeBekliyor = true;
    }
    xSemaphoreGive(networkMutex);
  }
}

static bool reverseGeocodeCacheAl(double lat, double lon, String &adres) {
  bool hazir = false;
  if (networkMutex && xSemaphoreTake(networkMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    if (isfinite(reverseGeocodeLat) && isfinite(reverseGeocodeLon) &&
        fabs(reverseGeocodeLat - lat) <= 0.000001 &&
        fabs(reverseGeocodeLon - lon) <= 0.000001 &&
        reverseGeocodeAdresCache.length() > 0) {
      adres = reverseGeocodeAdresCache;
      hazir = !reverseGeocodeBekliyor && !reverseGeocodeCalisiyor;
    }
    xSemaphoreGive(networkMutex);
  }
  return hazir;
}

static void bulutSenkronizasyonIstegi() {
  if (bulutSenkronizasyonu || firebaseSenkronBekliyor || networkWorkerCalisiyor) return;
  firebaseSenkronBekliyor = true;
  olcumKilitli = true;
  sonBulutDurumu = "Firebase siraya alindi...";
  bulutUIYenilemeIste = true;
}

static void networkWorkerTask(void* pv) {
  for (;;) {
    if (reverseGeocodeBekliyor) {
      double lat = NAN, lon = NAN;
      if (networkMutex && xSemaphoreTake(networkMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
        lat = reverseGeocodeLat;
        lon = reverseGeocodeLon;
        reverseGeocodeBekliyor = false;
        reverseGeocodeCalisiyor = true;
        networkWorkerCalisiyor = true;
        xSemaphoreGive(networkMutex);
      }

      if (isfinite(lat) && isfinite(lon)) {
        String adres = reverseGeocodeAdres(lat, lon);
        if (networkMutex && xSemaphoreTake(networkMutex, pdMS_TO_TICKS(200)) == pdTRUE) {
          // İstek sırasında yeni ölçüm geldiyse eski sonucu yeni koordinatın
          // üzerine yazma.
          if (fabs(reverseGeocodeLat - lat) <= 0.000001 &&
              fabs(reverseGeocodeLon - lon) <= 0.000001) {
            reverseGeocodeAdresCache = adres;
          }
          reverseGeocodeCalisiyor = false;
          networkWorkerCalisiyor = false;
          xSemaphoreGive(networkMutex);
        }
      }
    }

    if (firebaseSenkronBekliyor) {
      firebaseSenkronBekliyor = false;
      networkWorkerCalisiyor = true;
      bulutSenkronizeEtArkaPlanIslem();
      networkWorkerCalisiyor = false;
      bulutUIYenilemeIste = true;
    }

    vTaskDelay(pdMS_TO_TICKS(25));
  }
}

static void networkWorkerBaslat() {
  if (networkWorkerBaslatildi) return;
  networkMutex = xSemaphoreCreateMutex();
  if (networkMutex == nullptr) {
    Serial.println("[NET] Mutex olusturulamadi.");
    return;
  }
  BaseType_t ok = xTaskCreatePinnedToCore(
      networkWorkerTask, "networkWorker", 12288, nullptr, 1, nullptr, 0);
  if (ok != pdPASS) {
    Serial.println("[NET] Worker task olusturulamadi.");
    vSemaphoreDelete(networkMutex);
    networkMutex = nullptr;
    return;
  }
  networkWorkerBaslatildi = true;
}


void setup() {
  // ================================================================
  // ISD1820 ACILIS SESI FIX (yazilim, donanima dokunmadan):
  // PCF8574 guc aldigi anda tum register'i "1" (HIGH) ile reset olur;
  // P3/PLAYL bu yuzden bizim pcf8574Yaz(0x00) komutumuz I2C'den
  // gidene kadar HIGH kalir. Bu pencereyi en aza indirmek icin I2C
  // hattini ve PCF8574'u, Serial.begin/delay(500)/GPS/yazici init'ten
  // bile ONCE, setup()'in ILK ISI olarak baslatiyoruz. Asagidaki
  // Serial.printf'ler henuz Serial.begin() cagrilmadigi icin ekrana
  // basilmaz (zararsizdir); tani amacli tekrar pcf8574Baslat() cagrisi
  // asagida (eski yerinde) Serial hazir olduktan sonra yine calisiyor.
  ortakI2CHattiniBaslat();
  pcf8574Baslat();   // PCF8574 P3/PLAYL'i mumkun olan en erken anda LOW yapar

  networkWorkerBaslat();
  uiTemayiYukle(); // Kaydedilen arayüz temasını açılışta uygula

  Serial.begin(115200);
  // NOT: Dahili USB-CDC (Hardware CDC and JTAG) donanımı, host (Windows)
  // tarafından reset sonrası yeniden tanınması için sabit 500ms bazen
  // yetersiz kalabiliyor -- bu pencerede kaybolan ilk Serial.print
  // satırları "hiçbir şey yazdırmıyor" izlenimine yol açar. Burada
  // gerçekten bağlantı kurulana kadar (en fazla 3 saniye) bekliyoruz;
  // host bağlı değilse (örn. sadece pilden çalışırken) sonsuza kadar
  // takılıp kalmamak için üst sınır koyuyoruz.
  {
    uint32_t usbBekleBaslangic = millis();
    while (!Serial && (millis() - usbBekleBaslangic) < 3000) {
      delay(10);
    }
  }
  delay(200);

  Serial.println();
  Serial.println("=== NitraCheck / CrowPanel Advance 7 V1.4 UI POLISHED ===");

  // KAL-FIX-SURUM-ISARETI: Bu satir, ekrandaki KALIBRASYON LOG'un EN BASINDA
  // her acilista görünür. Amac: hangi firmware surumunun cihazda calistigini
  // Serial olmadan da (dokunmatik ekrandan) kesin olarak dogrulayabilmek --
  // önceki turlarda hangi .ino'nun gercekten yuklendigi konusunda belirsizlik
  // yasandigi icin eklendi. Bu satiri gormüyorsaniz, cihazda BU dosya DEGIL,
  // eski bir surum calisiyor demektir.
  kalLog("[SURUM] TANI-DIAG-3: KIRMIZI-SADECE-F7 + KAL-FIX-UYUM2 + GURULTU-TABANI");

  // ISD1820 PLAYE artık PCF8574/P3 üzerinden tetikleniyor; ayrı bir
  // pinMode()/digitalWrite() gerekmiyor. pcf8574Baslat() (aşağıda)
  // açılışta tüm PCF8574 pinlerini (P3 dahil) LOW yapıyor. (Bu ikinci
  // çağrı artık sadece tanı/log amaçlı; asıl susturma yukarıda oldu.)

  // NOT: Harici yeşil/kırmızı ölçüm LED'leri kaldırıldı. Ölçüm ışığı
  // artık AS7341 üzerindeki dahili beyaz LED; bu LED bir GPIO değil,
  // I2C üzerinden (as7341.enableLED()) kontrol edildiği için burada
  // pinMode()/digitalWrite() gerekmiyor.

  // ADIM18: GPS artık UART0-OUT'ta (GPIO43/44, Serial0), termal yazıcı
  // ise UART1-OUT'ta (GPIO19/20, bağımsız HardwareSerial(1)). "USB CDC
  // On Boot" bilerek DISABLED bırakıldı ki GPIO19/20 native USB'ye
  // kilitlenmesin ve yazıcı orada temiz çalışsın; bunun bedeli olarak
  // USB Serial Monitor artık ayrı bir kanal değil (Serial0/GPS ile
  // aynı fiziksel pinler), yani bu Serial.printf çağrıları GPS
  // portuna karışır (donanımsal olarak zararsızdır, çoğu GPS modülü
  // anlamadığı baytları yok sayar).
  GpsSerial.begin(GPS_BAUD, SERIAL_8N1, GPS_RX_PIN, GPS_TX_PIN);
  GpsSerial.setTimeout(20);
  gpsUartBaslatildi = true;
  gpsUartBaslangicMs = millis();
  Serial.printf("[GPS] UART0-OUT baslatildi: RX=%d TX=%d baud=%d\n",
                GPS_RX_PIN, GPS_TX_PIN, GPS_BAUD);

  YaziciSerial.begin(YAZICI_BAUD, SERIAL_8N1, YAZICI_RX_PIN, YAZICI_TX_PIN);
  yaziciESCPOSBaslat();
  cihazIdOlustur();
  Serial.printf("[YAZICI] UART1-OUT baslatildi: RX=%d TX=%d baud=%d\n",
                YAZICI_RX_PIN, YAZICI_TX_PIN, YAZICI_BAUD);
  Serial.println("[YAZICI-TANI] Test icin USB Seri Monitor'e YAZICITEST yazip Enter'a basin.");

  // ================================================================
  // TEK I2C BUS SIRASI
  // 1) Mutex oluştur
  // 2) Wire/I2C_NUM_0'u yalnızca bir kez başlat
  // 3) LovyanGFX + GT911'i aynı Wire pinlerine bağla
  // 4) AS7341/STC8'i aynı Wire üzerinden kullan
  // ================================================================
  if (!ortakI2CHattiniBaslat()) {
    Serial.println("[I2C] KRITIK: ortak I2C bus baslatilamadi!");
  }

  // PCF8574: A0=A1=A2=0 -> 0x20. P0/P1 çıkış olarak kullanılır.
  pcf8574Baslat();
  tumOlcumLedleriKapat();

  Serial.println("Display init...");
  bool ok = display.init();
  Serial.printf("display.init() = %s\n", ok ? "OK" : "FAILED");
  display.setRotation(0);

  // ÖNEMLİ: display.init() panelin RGB DMA çıkışını hemen başlatır;
  // PSRAM'deki kare tamponu bu noktada henüz temizlenmemiş (rastgele/
  // "çöp" veri) olabilir. Donanımda backlight, STC8 üzerinden yazılımla
  // AÇILMADAN ÖNCE bile fiziksel olarak zaten yanık gelebiliyor; bu da
  // sensörleri başlatırken geçen ~1-2 saniyelik sürede ekranda kısa bir
  // "çöp kare" / rastgele renkli yanıp sönme (backlight'ın arkaplanda
  // çöp veriyi göstermesi) olarak görülüyordu. Çözüm: kare tamponunu
  // backlightOn() çağrılmadan ÖNCE, mümkün olan en erken noktada
  // UI_BG (koyu lacivert) ile doldur; böylece backlight ne zaman
  // fiilen yanarsa yansın, gösterecek "çöp" değil düzgün arkaplan olur.
  display.fillScreen(UI_BG);

  // AS7341 modulu ve ortak I2C hatti, ESP32 + ekran/dokunmatik
  // baslangicindan hemen sonra bazen henuz kararlı cevap vermiyor.
  // Kullanici "YENIDEN DENE" dediginde calismasinin nedeni genellikle
  // bu ek baslangic suresinin gecmis olmasi. Bu nedenle ilk taramadan
  // once otomatik stabilizasyon beklemesi ekliyoruz.
  // ÖNEMLİ: AS7341'i cihaz açılır açılmaz aramıyoruz.
  // ESP32, ekran ve GT911 önce tamamen açılsın; AS7341'e daha sonra
  // ilk kez erişerek sensörün besleme ve iç başlatma süresini tamamlamasına
  // fırsat veriyoruz.
  const uint32_t AS7341_ACILIS_GECIKME_MS = 4000;

  Serial.printf(
    "[AS7341] Ilk erisim %lu ms geciktiriliyor; diger cihazlar oturuyor...\n",
    (unsigned long)AS7341_ACILIS_GECIKME_MS
  );

  vTaskDelay(pdMS_TO_TICKS(AS7341_ACILIS_GECIKME_MS));

  // AS7341 ilk kez aranmeden hemen önce ortak I2C hattını temizle/toparla.
  i2cHattiToparla();
  vTaskDelay(pdMS_TO_TICKS(100));

  Serial.println("[AS7341] 4 saniye sonrasi ilk I2C kontrolu...");
  bool sensorBusVar = sensorI2CHattiniBaslat();

  if (!sensorBusVar) {
    Serial.println("[I2C SENSOR] 0x39 / 0x30 bulunamadi.");
  }

  // ── SAĞLAM AÇILIŞ: sensörleri hız değil güvenilirlik öncelikli
  // başlat. as7341YenidenBaslat()/sht40YenidenBaslat() zaten begin()
  // + gerçek bir doğrulama okuması yapıyor (bkz. tanımları); burada
  // sadece açılışta birkaç deneme hakkıyla çağırıyoruz ki gevşek/yavaş
  // kalkan bir sensör yüzünden cihaz gereksiz yere "hazır değil"
  // görünmesin. Ölçüm sırasında ve Ayarlar > YENİDEN DENE akışı
  // AYNEN korunuyor; bu sadece açılıştaki ilk durumu iyileştiriyor.
  as7341Hazir = false;
  sht40Hazir = false;

  // AS7341 ilk taramada gec cevap verebiliyor. Bu nedenle ilk BUS
  // sonucuna bagli kalmadan 6 kez yeniden tarama + baslatma deniyoruz.
  // Her turda adres tekrar kontrol edilir; bulunduysa begin + gercek
  // okuma dogrulamasi yapilir.
  const int AS7341_ACILIS_MAX_DENEME = 10;
  for (int deneme = 1; deneme <= AS7341_ACILIS_MAX_DENEME && !as7341Hazir; deneme++) {
    // Her denemede önce ortak I2C hattını toparla; özellikle açılışta
    // GT911 ile AS7341'in ilk erişim zamanlaması çakışmışsa bu adım
    // kullanıcı müdahalesi olmadan hattı yeniden kullanılabilir hale getirir.
    i2cHattiToparla();
    vTaskDelay(pdMS_TO_TICKS(30));

    as7341TaramaBulundu = i2cCihazVar(AS7341_ADDR);

    Serial.printf("[AS7341] Acilis denemesi %d/%d | BUS: %s\n",
                  deneme, AS7341_ACILIS_MAX_DENEME,
                  as7341TaramaBulundu ? "VAR" : "YOK");

    // as7341YenidenBaslat() kendi begin() + gercek okuma dogrulamasini yapar.
    // BUS gec cevap verse bile sonraki turda yeniden taranir.
    as7341YenidenBaslat();

    if (!as7341Hazir) {
      vTaskDelay(pdMS_TO_TICKS(350));
    }
  }

  // NOT: Burada artik sht40TaramaBulundu'ya bakip kapida beklemiyoruz;
  // sht40YenidenBaslat() her cagrida adresi TAZE tarayip kendi karar
  // veriyor (bkz. fonksiyon ici not). Ilk taramada sensor gec cevap
  // verdiyse bile bu 3 denemeden biri onu yakalayabilir.
  for (int deneme = 1; deneme <= 3 && !sht40Hazir; deneme++) {
    Serial.printf("[SHT40] Acilis baslatma denemesi %d/3...\n", deneme);
    sht40YenidenBaslat();
    if (!sht40Hazir) vTaskDelay(pdMS_TO_TICKS(200));
  }

  Serial.printf("[BOOT] AS7341: %s | SHT40: %s\n",
                as7341Hazir ? "HAZIR" : "ARIZALI/YOK",
                sht40Hazir  ? "HAZIR" : "ARIZALI/YOK");

  // Önce gerçek kullanıcı kalibrasyon yedeğini yükle.
  bool kalYedekOK = kalibrasyonuNVStenYukle();
#if TEST_KALIBRASYON_AKTIF
  // Test verisi sadece gerçek bir yedek bulunamadığında devreye girer.
  if (!kalYedekOK) testKalibrasyonUret();
#else
  (void)kalYedekOK;
#endif

  // Kayıtlı ekran parlaklığını backlightOn()'dan ÖNCE yükle ki açılışta
  // doğrudan kullanıcının son ayarladığı parlaklıkla açılsın.
  uiPrefs.begin("ui", false);
  uiBacklightLevel = (uint8_t)uiPrefs.getUInt("parlaklik", uiBacklightLevel);
  Serial.printf("[UI] Kayitli parlaklik yuklendi: %u/255\n", uiBacklightLevel);

  Serial.println("Backlight aciliyor...");
  backlightOn();

  // ─── KALİBRASYON TANI/LOG EKRANI KALDIRILDI ──────────────────────
  // NVS "NOT_ENOUGH_SPACE" sorunu teşhis edilip kalıcı olarak çözüldüğü
  // için (bkz. eskiOlcumAnahtarlariniTemizle() ve kalibrasyonBlobYaz()),
  // açılışta zorla gösterilen "KALIBRASYON TANI" ekranı ve ardından
  // gelen tam ekran "KALIBRASYON LOG" ekranı artık gereksiz ve normal
  // kullanımda kafa karıştırıyordu; kaldırıldı. Açılış artık burada
  // beklemeden doğrudan devam eder.
  //
  // NOT: kalLog() sistemi (RAM'deki dairesel arabellek) hâlâ çalışıyor
  // ve kalibrasyon ekranındaki "LOG" butonuyla istenirse hâlâ manuel
  // açılabiliyor (bkz. uiHandleCalibrationTouch() içindeki LOG butonu).
  // Bu arabellek zaten kendiliğinden dönüyor (en eski satır otomatik
  // düşer) ve hiçbir zaman flash'a yazılmıyor; reboot'ta sıfırlanır --
  // yani "eskilerin silinmesi" için ekstra bir işlem gerekmiyor.

  // Fontu daha ilk UI ciziminden once sec.
  display.setFont(FONT_SMALL);
  display.setTextSize(1);

  display.fillScreen(UI_BG);
  drawLeftText("NitraCheck başlatılıyor...", 40, 40,
               FONT_MEDIUM, UI_WHITE, UI_BG);
  drawLeftText("Ağ ve bulut bağlantısı kontrol ediliyor.",
               40, 78, FONT_SMALL, UI_MUTED, UI_BG);

  WiFi.mode(WIFI_STA);
  WiFi.persistent(false);
  WiFi.setSleep(false);

  wifiPrefs.begin("wifi", false);
  cloudPrefs.begin("cloud", false);
  yerelOlcumYukle();

  String kayitliSSID = wifiPrefs.getString("ssid", "");
  String kayitliSifre = wifiPrefs.getString("pass", "");

  if (kayitliSSID.length() > 0) {
    Serial.printf("[WiFi] Kayitli ag kullaniliyor: %s\\n", kayitliSSID.c_str());
    WiFi.begin(kayitliSSID.c_str(), kayitliSifre.c_str());
  } else {
    Serial.printf("[WiFi] Varsayilan ag kullaniliyor: %s\\n", WIFI_SSID);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  }

  unsigned long wifiBaslangic = millis();
  while (WiFi.status() != WL_CONNECTED &&
         millis() - wifiBaslangic < 15000) {
    vTaskDelay(pdMS_TO_TICKS(300));
    Serial.print(".");
  }
  Serial.println();

  bool wifiVar = (WiFi.status() == WL_CONNECTED);
  Serial.printf("WiFi durumu: %s\n",
                wifiVar ? "BAGLANDI" : "BAGLANAMADI");

  if (wifiVar) {
    // Başlangıçta kayıtlı bilgilerle bağlanılmışsa zaten kayıtlıdır.
    // Ancak ilk açılışta WIFI_SSID/WIFI_PASSWORD ile bağlanıldıysa da
    // aynı bilgileri NVS'ye yaz; böylece cihaz sonraki açılışta unutmaz.
    if (kayitliSSID.length() == 0) {
      wifiPrefs.putString("ssid", WIFI_SSID);
      wifiPrefs.putString("pass", WIFI_PASSWORD);
      Serial.println("[WiFi] Varsayılan WiFi bilgileri NVS'ye kaydedildi.");
    }
    wifiSonrasiServisleriBaslat();
  }

  drawSplash();
  splashStart = millis();
  splashFinished = false;

  Serial.println("UI hazir. 2 saniye sonra ana ekran.");
}

void loop() {
  // ── YAZICITEST DİNLEYİCİSİ KALDIRILDI (ADIM18) ──
  // Bu blok eskiden USB Serial'den ("Serial") "YAZICITEST" komutunu
  // okuyordu. ADIM18'de GPS, Serial0'a (CDC kapalıyken "Serial" ile
  // birebir aynı nesne/buffer) taşındığı için bu dinleyici artık
  // GpsSerial ile aynı UART buffer'ını okuyup GPS'in NMEA baytlarını
  // çalardı. USB CDC kapalı olduğu sürece zaten ayrı bir USB Serial
  // Monitor kanalı da kalmadığından bu özellik güvenli şekilde
  // kaldırıldı. Yazıcı tanısı gerekirse doğrudan yaziciTaniKosusu()
  // çağrılabilir (örn. dokunmatik ekrana geçici bir test butonu
  // eklenerek) ya da GPS geçici olarak söküp bu blok geri açılabilir.

  gpsGuncelle();
  wifiTaramaGuncelle();

  // Ağ worker'ı display'e doğrudan dokunmaz. İstenen sayfa yenilemesi
  // yalnızca ana loop/UI bağlamında yapılır.
  if (bulutUIYenilemeIste && currentScreen == SCREEN_CLOUD) {
    bulutUIYenilemeIste = false;
    drawSimplePage(SCREEN_CLOUD);
  }

  if (firebaseHazir && WiFi.status() == WL_CONNECTED &&
      !networkWorkerCalisiyor && !firebaseSenkronBekliyor && !bulutSenkronizasyonu &&
      currentScreen == SCREEN_MAP &&
      millis() - sonHaritaYenileme >= HARITA_YENILEME_MS) {
    sonHaritaYenileme = millis();
    // Arka planda veri yenilenir; tam ekran yeniden cizim yapilmaz.
    // Bir sonraki HARITA girisinde guncel koordinatlar tek seferde cizilir.
    firebaseOku();
  }

  if (!splashFinished) {
    if (millis() - splashStart >= 2000UL) {
      splashFinished = true;
      currentScreen = SCREEN_MAIN;
      drawMainScreen();
      Serial.println("[UI] Ana olcum ekrani acildi.");
    }
    vTaskDelay(pdMS_TO_TICKS(10));
    return;
  }

  // ── AÇILIŞTAN 5 SANİYE SONRA AS7341 + SHT40 EK TETİKLEME ──
  // setup() içinde açılışta zaten birkaç deneme yapılıyor; ancak I2C
  // hattı/GT911/backlight sırası tam oturmadan yapılan bu ilk deneme
  // bazen erken kalabiliyor. Burada, açılıştan (millis()=0) itibaren
  // TAM OLARAK bir kez, 5. saniyede, henüz hazır olmayan sensörler
  // için yeniden başlatma deneniyor. Sensör zaten hazırsa dokunulmuyor
  // (gereksiz I2C reset/gürültü olmasın diye).
  static bool sensor5sTetikGecti = false;
  if (!sensor5sTetikGecti && millis() >= 5000UL) {
    sensor5sTetikGecti = true;
    Serial.println("[BOOT+5s] AS7341/SHT40 ek tetikleme calisiyor...");

    if (!as7341Hazir) {
      // Ilk acilista BUS YOK kalmis olsa bile eski tarama sonucuna
      // takilma: adresi TAZE kontrol et ve begin() + okuma denemesini yap.
      as7341TaramaBulundu = i2cCihazVar(AS7341_ADDR);
      Serial.printf("[BOOT+5s] AS7341 taze BUS kontrolu: %s\n",
                    as7341TaramaBulundu ? "VAR" : "YOK");
      as7341YenidenBaslat();
    }
    // SHT40 icin artik eski taramaya guvenmiyoruz; sht40YenidenBaslat()
    // adresi kendi icinde taze tarayip karar veriyor.
    if (!sht40Hazir) {
      sht40YenidenBaslat();
    }

    Serial.printf("[BOOT+5s] AS7341: %s | SHT40: %s\n",
                  as7341Hazir ? "HAZIR" : "ARIZALI/YOK",
                  sht40Hazir  ? "HAZIR" : "ARIZALI/YOK");

    // Üst bardaki sıcaklık/nem/GPS sembollerini taze değerlerle güncelle.
    drawHeaderStatusIcons(false);
  }

  // Ilk otomatik deneme + 5 saniye yetmezse, kullanicinin butona
  // basmasini gerektirmeden 8/11/14. saniyelerde taze birer deneme yap.
  static uint8_t as7341GecikmeliDeneme = 0;
  const uint32_t as7341GecikmeliZamanlar[] = {8000UL, 11000UL, 14000UL};
  if (!as7341Hazir && as7341GecikmeliDeneme < 3 &&
      millis() >= as7341GecikmeliZamanlar[as7341GecikmeliDeneme]) {
    uint8_t n = as7341GecikmeliDeneme + 1;
    Serial.printf("[AS7341 AUTO] Gecikmeli deneme %u/3...\n", n);
    as7341TaramaBulundu = i2cCihazVar(AS7341_ADDR);
    as7341YenidenBaslat();
    as7341GecikmeliDeneme++;
  }

  // ── SHT40 İÇİN ARKA PLAN OTOMATİK KURTARMA ──
  // sensorleriKapat() her ölçüm SONUNDA sht40Hazir'i bilerek false
  // yapıyor (bkz. fonksiyon içindeki not) — bir dahaki ÖLÇÜM BAŞLAT'a
  // kadar SHT40 kendiliğinden geri gelmiyordu (GPS'in aksine, o ayrı
  // bir UART üzerinden sürekli kendi kendini güncelliyor). Burada, ana
  // ekranda ve ölçüm sürmüyorken, SHT40 hazır değilse belirli aralıkla
  // sessizce yeniden denenir. AS7341'e BİLEREK dokunulmuyor; o GT911
  // dokunmatikle aynı I2C hattını paylaşıyor ve ölçüm dışında
  // tetiklenmemesi bilerek tercih edilmiş (yukarıdaki not).
  static unsigned long sonSht40OtoDeneme = 0;
  if (!sht40Hazir && !olcumKilitli && currentScreen == SCREEN_MAIN &&
      millis() - sonSht40OtoDeneme >= 8000UL) {
    sonSht40OtoDeneme = millis();
    Serial.println("[SHT40] Arka plan otomatik yeniden baslatma deneniyor...");
    sht40YenidenBaslat();
    drawHeaderStatusIcons(false);
  }

  // ── ÜST BAR SEMBOLLERİNİ (sıcaklık/nem/GPS) PERİYODİK TAZELE ──
  // Ekran geçişi olmadan da (kullanıcı dokunmasa bile) değerler canlı
  // kalsın diye; ana çizim akışına dokunmadan sadece o küçük alanı
  // yeniden çizer. force=false: değer GERÇEKTEN değişmediyse hiçbir
  // şey çizilmez -- eskiden burası koşulsuz her 4 saniyede bir
  // temizleyip yeniden çizdiği için ekranda periyodik titreme/flap
  // oluşuyordu.
  static unsigned long sonHeaderIkonYenileme = 0;
  if (millis() - sonHeaderIkonYenileme >= 4000UL) {
    sonHeaderIkonYenileme = millis();
    drawHeaderStatusIcons(false);
  }

  // Üstteki test tüpü ikonu her ~120ms'de bir yeniden çizilerek dolum
  // seviyesini (5 saniyelik döngüye göre) güncel tutar; bu da göz ile
  // net takip edilebilen akıcı bir "dolma" animasyonu verir.
  static unsigned long sonOlcumRozetHareket = 0;
  if (currentScreen == SCREEN_MAIN &&
      millis() - sonOlcumRozetHareket >= 120UL) {
    sonOlcumRozetHareket = millis();
    drawMeasurementBadgeMotion();
  }

  // NOT: Rozet artık dönen halka içermediği için (bkz. yukarıdaki
  // drawHeaderTitleBadgeFrame) periyodik yeniden çizime gerek kalmadı;
  // ikon zaten sayfa açıldığında drawHeader() ile bir kez çiziliyor.
  // Bu, her 150ms'de gereksiz PNG çözme maliyetini de ortadan kaldırdı.

  int32_t tx, ty;
  bool touched = display.getTouch(&tx, &ty);

  // ADIM16: Ana ekran çizildikten 2.5 saniye sonra, kullanıcı dokunmuyorsa
  // tek NVS blob yazımı. Bloklamaz ve hiçbir UI yeniden çizimi yapmaz.
  if (pendingLocalSave &&
      currentScreen == SCREEN_MAIN &&
      !olcumKilitli &&
      !touched &&
      (long)(millis() - pendingLocalSaveAt) >= 0) {
    pendingLocalSave = false;
    yerelOlcumKaydet();
    Serial.println("[NDSC] Ertelenmis tek blob hafiza kaydi tamamlandi.");
  }

  // ---- TANI (DEBUG) BLOGU: sorun cozulunce kaldirilabilir ----
  static unsigned long sonHeartbeat = 0;
  static unsigned long sonBasariliDokunmaMs = 0;
  static bool ilkDokunmaGoruldu = false;

  if (touched) {
    sonBasariliDokunmaMs = millis();
    ilkDokunmaGoruldu = true;
  }

  if (millis() - sonHeartbeat >= 2000) {
    sonHeartbeat = millis();
    unsigned long sonDokunmadanBeriGecen =
        ilkDokunmaGoruldu ? (millis() - sonBasariliDokunmaMs) : 0;
    Serial.printf(
        "[HEARTBEAT] t=%lu screen=%d touched=%d sonBasariliDokunmadanBeriMs=%lu\n",
        millis(), (int)currentScreen, (int)touched, sonDokunmadanBeriGecen);
  }
  // ---- TANI BLOGU SONU ----

  if (touched && !previousTouch) {
    buzzerClick();
    uiHandleTouch(tx, ty);
  }

  // Parlaklık sürgüsü: parmak basılı kaldığı SÜRECE her karede çağrılır
  // ki sürükleme akıcı olsun (uiHandleTouch yalnızca ilk temas anında
  // çalışır, sürüklemeyi takip etmez).
  if (touched && currentScreen == SCREEN_DISPLAY_SETTINGS) {
    uiHandleBrightnessSliderDrag(tx, ty);
  }

  // Parmak kaldırıldığında (sürükleme bitince) son parlaklık değerini
  // NVS'e KALICI olarak kaydet. Sürükleme SIRASINDA değil, sadece
  // gerçekten bir değişiklik olduysa ve bırakıldığında yazılır ki
  // flash'a gereksiz sık/alakasız yazım olmasın.
  if (!touched && previousTouch && parlaklikKaydiBekliyor) {
    parlaklikKaydiBekliyor = false;
    uiPrefs.putUInt("parlaklik", uiBacklightLevel);
    Serial.printf("[UI] Parlaklik NVS'e kaydedildi: %u/255\n", uiBacklightLevel);
  }

  previousTouch = touched;

  vTaskDelay(pdMS_TO_TICKS(20));
}


// ── 3 SEÇENEKLİ TÜM ARAYÜZ TEMASI ─────────────────────────────
// 0 = Nitra Mavi, 1 = Teknoloji Mor, 2 = Doğa Yeşili, 3 = Kırmızı, 4 = Beyaz
uint8_t uiTheme = 0;

void uiTemayiUygula(uint8_t tema) {
  uiTheme = (tema > 4) ? 0 : tema;
  if (uiTheme == 0) {
    UI_BG=rgb565(8,16,35); UI_HEADER=rgb565(12,24,48); UI_PANEL=rgb565(16,30,58); UI_PANEL2=rgb565(10,21,43); UI_PANEL3=rgb565(24,42,76); UI_CYAN=rgb565(35,85,180); UI_ORANGE=rgb565(255,184,52);
  } else if (uiTheme == 1) {
    UI_BG=rgb565(24,10,42); UI_HEADER=rgb565(38,16,64); UI_PANEL=rgb565(49,24,78); UI_PANEL2=rgb565(31,14,55); UI_PANEL3=rgb565(68,38,104); UI_CYAN=rgb565(186,104,255); UI_ORANGE=rgb565(255,100,190);
  } else if (uiTheme == 2) {
    UI_BG=rgb565(8,31,27); UI_HEADER=rgb565(12,50,42); UI_PANEL=rgb565(17,66,56); UI_PANEL2=rgb565(10,43,37); UI_PANEL3=rgb565(28,88,74); UI_CYAN=rgb565(38,220,165); UI_ORANGE=rgb565(160,230,65);
  } else if (uiTheme == 3) {
    UI_BG=rgb565(42,8,10); UI_HEADER=rgb565(72,12,16); UI_PANEL=rgb565(92,20,24); UI_PANEL2=rgb565(58,12,15); UI_PANEL3=rgb565(120,30,34); UI_CYAN=rgb565(255,92,92); UI_ORANGE=rgb565(255,180,72);
  } else {
    UI_BG=rgb565(242,245,248); UI_HEADER=rgb565(28,42,58); UI_PANEL=rgb565(52,68,84); UI_PANEL2=rgb565(72,88,104); UI_PANEL3=rgb565(98,114,130); UI_CYAN=rgb565(0,132,210); UI_ORANGE=rgb565(230,130,0);
  }
}

const char* uiTemaAdi() { switch(uiTheme) { case 0:return "NITRA MAVİ"; case 1:return "TEKNOLOJİ MOR"; case 2:return "DOĞA YEŞİL"; case 3:return "KIRMIZI"; default:return "BEYAZ"; } }
void uiTemayiKaydet() { Preferences tp; tp.begin("uiTheme", false); tp.putUChar("tema", uiTheme); tp.end(); }
void uiTemayiYukle() { Preferences tp; tp.begin("uiTheme", true); uint8_t t=tp.getUChar("tema",0); tp.end(); uiTemayiUygula(t); }
